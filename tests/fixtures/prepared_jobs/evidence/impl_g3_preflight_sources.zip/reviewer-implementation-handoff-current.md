# Implementation handoff — maintained in place

## Current: job129 model-preflight repair, awaiting re-review (20 Oct 2026)

Independent review rejected the first software batch's model preflight: a replacement
model and stale saved identity could reach12 loads before offline rejection. Decisions
73-77 below close that dispatch gap. The active job129 wrapper now binds NEW frozen
g3-evidence-2 rules, SHA256
17feb7d76046ba4036f99606ef2bc20db9299e2f31ea320749a7ba8d534ba94f.
The v1 rules, wrapper copy, source package, checks and independent review evidence stay
preserved. Same handoff, no new handoff. No hardware run/approval, commit, push or queue
movement. Software/protocol acceptance and hardware approval remain pending.

## Previous: software evidence capture and prepared G3 follow-up (20 Oct 2026)

Job128 results and their limited interpretation were independently accepted. The
owner's subsequent "go ahead" authorizes the software batch documented at decisions
64 onward below: per-load logs/mapped-file evidence, retained data-folder maps, and
a focused G3 follow-up prepared for review. It authorizes NO additional hardware
run. Job129 remains in later; job128 records/rules/wrapper remain unchanged. The
same handoff is maintained in place; no second handoff has been created.

## Job128 owner-authorized hardware run (20 Oct 2026; completed)

Both models completed with wrapper exit 0 in 65 minutes. All 270 engine loads recorded
clean release; all 540 power checks were AC. Model hashes matched. Data-folder
preservation relies on the runner's recorded comparison; the original maps were not
retained, so the new software does not retroactively strengthen that evidence.
Gemma's native regression is reproduced, but G3 is not interpretable and no default
or production configuration changes follow. Full evidence and limits are below.

The owner independently accepted the repair batch over 9e29ba8 and committed it.
At launch the working tree was clean on 3314c86. All 509 source/test/script Python
hashes and the prepared job128 wrapper/frozen rules matched the accepted package.
The owner then explicitly instructed "run it". This supersedes earlier historical
statements that job128 has not run or lacks hardware authorization; it does not
approve any production default change, tuning run or extra hardware experiment.

62. **Execute the reviewed study without changing its scientific plan.** The
    unchanged wrapper runs directly from later, with no parameter overrides:
    three native blocks, normal power checks, context 4096, saved setups read only,
    Gemma default and --swa-full variants, Llama default control, and the matched
    chat study. The frozen v8 SHA-256 remains
    `4a80891cb9f607da6d341f27d0da090148292a199d389d4101b6038b8e293734`.
    No job was moved into the queue. The ignored `impl_job128_launch.ps1` supplies
    only a Windows system-awake hold, fresh console/started/done files, and the
    wrapper's exit status. Its finally block releases that wake hold. It adds no
    engine cleanup owner, retry, scientific setting, power bypass or inference
    request. The existing backend remains the sole engine/credential cleanup owner.
    The scheduled 600-second inter-model rest is preserved. Monitoring reads only
    checkpoint files/logs; no concurrent tests, benchmarks or engine probes run.

Launch: **19:52:01 IST**, run ID `79da9758-5324-4a21-8730-e50dd7fb8ee5`.
Console/launch bookkeeping prefix:
`_jobs/out/128_owner_20261020_195200_dce18a03`.
Raw scientific results use `128_correctness_<model>_20261020_195201_79da9758.json`.
The helper source and raw console output are retained; originals are not overwritten.

Gemma finalized with status done at 20:17 IST: 108 native trials, 18 chat blocks /
54 chat loads, 162 clean unloads, 324 AC checks, unchanged model/data-folder bytes.
The read-only `impl_job128_audit.py` recomputes both stored summaries using the
unchanged frozen-version functions, checks underlying cleanup/power/validity evidence,
and writes a separate audit; it never changes raw results or contacts an engine.
Gemma raw SHA-256:
`e78a5f44a21493a7ba85d4ce962e509cbabcce846e7e009cc9eaf5a280bde105`.

Gemma interpretation recorded when that model finished (final Llama control below):

- G1: the exact regression pair reproduces the native failure in 3/3 blocks:
  fresh states 57 correctly; partial reuse refuses the answer. This remains one
  prompt pair, not a general failure rate.
- G2: 0 of 7 additional scored pairs show wrong partial-reuse evidence; the eighth
  additional pair (filters) is uninformative because fresh answers are wrong too.
- G3: no mitigation claim is permitted. The --swa-full request gave right answers
  on the regression pair, but the required per-load effective cache states are not
  verified: default is labelled no sliding-window cache on all 54 loads; full has
  no cache-size evidence on all 54. The stored comparison is interpretable=False.
  The command-line association is descriptive, not proof of a verified fix/cause.
- G5: six informative chat pairs have right client answers after partial reuse;
  three pairs (pressure, bloom and the regression pair) have wrong matched fresh
  answers as well and establish no reuse-attributed exposure. They are not counted
  as safe or exposed. G4 and the overall run were pending Llama at this stage.

The completed control/results and final provenance are recorded below. No source,
judge, rule, saved setup, production default or
acceptance threshold has been changed during the study. No commit/push is requested.

## Fourth independent-review correction: release preserves halt permission (20 Oct 2026)

The independent reviewer accepted the stop/rollback and serving-admission repairs,
then reproduced an adapter halt being erased by unload/cleanup. An older native
resume could clear the backend flag after a newer halt. The adapter correctly
returned False for that stale resume, but release had already replaced its shared
publication/permission token, so a subsequent load bypassed the halt. The real
restoration verifier's finally-unload reproduced the same defect after correctly
refusing its probe. No bypass of the workload's separate cancellation flag was
reported. This adapter contract violation is accepted and repaired here.

61. **Keep start permission independent of publication ownership.** The adapter now
    owns a separate `_stop_intent`, protected by its existing request lock. Halt
    creates/revises this intent and cancels pending work as before. Admission reads
    this intent; unload and cleanup still cancel old work and rotate the publication
    generation, but cannot erase permission. Resume captures the permission intent
    and revision, asks the existing backend owner to confirm restartability outside
    the metadata lock, then lifts only that still-current intent. A new halt or a
    reentrant halt from the final cancellation predicate invalidates an older resume.
    Release alone does not invalidate a legitimate current resume: it is resource
    cleanup, not a new stop request. A refused, interrupted or failed resume leaves
    permission closed; its existing unresolved-exit diagnostic also survives release.
    A later successful current resume opens permission. Cleanup after that success
    does not invent a new halt.

    The publication token remains separate and authoritative for clearing model,
    params and application evidence, and for rejecting stale reload publication or
    rollback. In particular, release must not preserve that publication token merely
    to retain permission: that alternative could allow stale results to repopulate
    released metadata. No process/PID/credential decision moves to the adapter, no
    extra native lock or cross-lock callback is introduced, and old request Events
    remain permanently canceled. The native backend, workload and verifier require
    no product edits in this round. Runtime/history/result formats, optimization
    policy, frozen job128 rules and its direct-backend runner are unchanged.

Before product edits, the preceding 13-file dirty snapshot was archived as
`impl_halt_permission_before.zip`. All 509 entry Python hashes matched the previous
sealed package. **311 unique preceding delivery/review artifacts** were verified
and recorded in `impl_halt_permission_preserved.json`; no original was overwritten.
Fresh direct and public-verifier probe copies reproduce the supplied defect before
repair and reject every post-halt load after repair. The original six-case outputs
remain intact; new outputs use the `impl_halt_permission_` prefix.

**26 new regressions fail on the entry adapter and pass after repair.** They use
the production adapter/backend/verifier with scripted engine/client resources:
16 timed/user schedules across unload, cleanup, verifier verify/capture and
current/stale resumes; eight false/error/interrupt/cancellation-predicate refusal
cases across both release methods; two reentrant newer-halt/release schedules in
resume's final predicate. They also check cleared publication evidence, removed
credentials, no unpermitted process start, preserved original exception objects,
and working explicit future resumes/loads. Existing regressions remain intact.
Final broad/type/parity/simulation gates and package hashes will be appended after
completion. The earlier access violation remains unexplained and is not erased by
later passing runs. Job128 stays in later; no hardware/model run, queue move,
saved-owner-setup change, commit or push is part of this correction.

## Third independent-review correction: stop intent and delayed rollback (19 Oct 2026)

The independent reviewer accepted the preceding publication/PID fixes and one-shot
logging, then reproduced a delayed ordinary startup failure restarting the prior
engine after `ResidentActiveWorkload.stop()` returned. A failed start had already
unwound to idle, so workload cleanup correctly skipped unload; temporary backend
halt state was subsequently resumed while the old adapter generation remained
valid. Stop and cancel-then-allow-restart reproduced it for both configuration
changes and forced restarts; plain cancellation was a passing control. This is an
accepted resource-ownership defect. It is not waived by deterministic tune parity.

The entry remains uncommitted on owner `9e29ba85dc810641d3a13307f678420ff730bcc4`.
Before edits, the 12 Git-changed files plus the sole handoff (13 package entries) were preserved in `impl_stop_intent_before.zip`, SHA-256
`97730723a3d900d3fd09adcaa61d20aa8c2360c0a0949b90108ee61065de3f5d`.
Previous delivery and reviewer artifacts are retained; this is the same maintained
handoff, not a replacement document or a new preregistration.

57. **Separate cancellation of old work from permission for future work.** Each
    adapter request now holds a private cancellation Event. Halt records a stop
    intent and cancels the pending request before invoking the backend, including
    when startup cleanup has already left it idle. Clearing the pending slot admits
    a genuinely new request after an explicit successful resume; it never clears
    the old request's Event. Both current-token and cancellation checks protect
    dispatch and publication. The stop intent retains user-versus-timed cause across
    backend resume, so legacy cancellation reasons remain honest. A late failure
    can record a canceled application only while its stop intent is still current;
    it cannot overwrite a replacement's model/params/application or restore into
    it. The original exception remains the cause of the cancellation report; if
    another request superseded it, the original failure propagates without a new
    stale report. Ordinary reload failures without a stop keep their prior restore
    attempt. Merely consulting backend.halted was rejected because normal stop
    resumes that flag before delayed Python failures necessarily return.

58. **Guard engine admission at the resource owner's existing lock.** The concrete
    resident backend exposes start_if_current/stop_if_current. They delegate to the
    same start/stop implementation with a private predicate checked under the
    lifecycle lock immediately before claiming a start/stop. A start also checks
    before preparation, so already-canceled work cannot wait for an unrelated ready
    replacement to unload. The final locked check remains essential: an adapter
    check followed by an unlocked backend call alone has a scheduling gap. The
    predicate reads only the request Event; it never acquires the adapter metadata
    lock under the backend lifecycle lock. Backend process waits and loads remain
    outside the metadata lock. There is still one process/credential cleanup owner,
    no retry scheduler and no added measurement. Existing preparation/exit waits
    keep their bounded contracts; cancellation during an already-entered wait is
    refused again before admission. A global mutex across a whole load was rejected
    because it would block the stop that must interrupt that load.
    Production uses these guarded methods. Legacy injected doubles/custom backends
    with only the older protocol retain the pre-call and publication checks; they
    do not acquire the native backend's atomic admission guarantee by assertion.
    Direct raw-backend callers keep the existing default behavior. No lifecycle
    measurement, RuntimeParams, tune request, history or result schema changes.

59. **A late resume cannot undo a newer halt.** The adapter's stop group has a
    revision and an admission gate. Resume may release that gate only when the
    backend confirms restartability, the stop group/revision is unchanged, and the
    owner's cancellation predicate allows it. Repeated halts retain a user stop's
    priority; a new stop invalidates an older resume even if the latter clears the
    backend flag afterwards. Empty/in-place parameter updates cannot erase that
    gate. Offline desired configuration still belongs to the workload and is
    applied by its next explicit start. A failed backend resume's unresolved-exit
    message is retained as a diagnostic for that stop group, preserving the prior
    physical-exit refusal rather than hiding it behind a generic cancellation
    message. This cached text is not new exit verification; a new resume asks the
    backend again, and a new halt or successful resume clears the cached problem.
    No PID check or cleanup decision was moved into the adapter.

60. **Make serving-thread admission atomic with pause/stop.** A further controlled
    caller probe blocked request-ID preparation after the serve loop read accepting.
    Pause returned True with no in-flight request; releasing preparation then produced
    a request anyway (0 -> 1 recorded requests). This was a separate existing gap in
    the same caller boundary, not a change to the tuning planner. The real serving
    thread now rechecks running/accepting under the workload lock at the same point
    it marks the request in flight. Pause either drains an already-admitted request
    or excludes the prepared request. Stop/cancel similarly exclude it without a
    late recovery, inference or invented failure record. Deliberate synchronous
    helper calls retain their existing contract; the guard identifies the owned
    serving thread rather than globally banning that helper. Three forced schedules
    (pause, stop, cancel) all fail before and pass after; the pause case also checks
    that a synchronous helper request still works. The stop-only source and then-
    current documentation are preserved in `impl_stop_intent_before_pause.zip`.

Regression scope: 60 real-caller schedules (configuration/restart; stop/cancel/
cancel-then-allow; delayed failed start, start admission, restore admission, stop
admission and failed restore; with/without a new explicit replacement). They start
and pause the real serving thread and use the production adapter/backend/workload;
only the engine process and client are scripted. Assertions cover engine starts,
request counts, live process instances, credentials/release evidence, captured target
state, current settings/application, no stale rollback and working explicit future
starts. Two further schedules race an older resume against a new timed/user halt
and verify that neither load nor an empty/in-place update bypasses the gate.

The initial 60-case entry run gives **42 failures / 18 passing controls**. The final
62-case selection, with preserved entry classes injected only into an isolated pytest
process, gives **44 failures / 18 controls** (`impl_stop_intent_negative2.xml`).
The six reviewer schedules are replayed with public workload start/pause and fresh
paths (`impl_stop_intent_before_probe.json` / `impl_stop_intent_after_probe.json`):
all six now remain idle after the delayed error, with no third engine start.
The first production guard checked after preparation only; 12 replacement cases
showed canceled calls unnecessarily waiting for that replacement to unload. The
preparation preflight fixes this; the locked admission check is retained. Another
intermediate test failure showed the new gate hiding the backend's unconfirmed-exit
error; retaining the failed resume's diagnostic fixes that without weakening exit
proof. Those failed intermediate outputs and faulthandler stacks are preserved.
The first focused run was also not one final-source snapshot (two resume cases were
added after its collection); it is diagnostic evidence only. The final focused
selection passes **333 tests, 1 host-restricted folder-link skip**, with mypy clean on
**461 files**. Its counts overlap the broad suite; they are not additional tests.

The expanded final entry-code selection includes the three serving-admission
cases and injects the archived backend, adapter and workload classes only into an
isolated pytest process. It gives **47 failures / 18 passing controls** over 65 cases
(`impl_stop_intent_negative3.xml`). Final focused coverage is **336 passed / 1
host-restricted folder-link skip**; mypy remains clean on 461 files. These supersede
this round's smaller 62-case/333-pass counts, which remain valid intermediate evidence.

The first broad run added a 60-second faulthandler timer for diagnosis. During an
unchanged long Unicode-summary judge test it emitted a timeout stack dump, then
terminated with Windows access violation `-1073741819` (0xC0000005). That is a failed
validation run, not a pass; no final XML was produced. The log is preserved as
`impl_stop_intent_broad.txt`. Judge source is byte-identical to the entry archive
(hash/platform/interpreter recorded in `impl_stop_intent_dump_environment.json`).
The same long judge case with that timer subsequently **passed alone in 91.33 s**,
including a successful timeout stack dump (`impl_stop_intent_dump_control.xml/.txt`).
This does not establish the crash's cause or prove an interpreter defect. The final
full gate uses the owner's standard command without the added diagnostic timer.
The native diagnostic crash remains explicitly disclosed for independent review;
no reference or test was removed to hide it. No product stack-dump timer was added.
The final snapshot is `impl_stop_intent_validation2_inputs.json`.

All prior immutable artifact groups were verified before completion (92 earlier
entries, 61 preceding delivery artifacts and 44 artifacts from this independent
review, counted per manifest, with overlap possible). No previous package, reference,
comparator exclusion, scenario population or original result was replaced. Final
broad/parity/simulation/source hashes and commands are recorded below on completion.
Job128's direct-backend runner remains software-ready per independent review and
stays in later for separate owner authorization. No hardware/model run, queue move,
saved-owner-setup change, commit or push is authorized in this repair.

## Second independent-review corrections (19 Oct 2026)

The owner supplied a fresh independent request-changes verdict against the prior
uncommitted repairs on `9e29ba85dc810641d3a13307f678420ff730bcc4`. The original three
findings were accepted after fresh reproductions. Two follow-ups were accepted as
real defects: delayed load/reload publication and a host-dependent recovery fake.
The independent broad run had **3,120 passed, 1 failed, 3 skipped, 1 deselected**;
that failure was the fake PID collision. The prior successful 3,121-pass run remains
valid as an observed run, but did not prove that fixture independent of host state.
No old report, artifact, reference, exclusion or scenario population was replaced.

Entry changed files and this sole handoff are preserved in
`_jobs/out/impl_publication_before.zip`, SHA-256
`ae2f36d3d5984974cfe1b32440aaef146a5e3e85d3500061e19824f6781d0e8e` (11 files).
The then-unchanged recovery test was not in that changed-file package; its exact
committed source is separately preserved as `impl_publication_recovery_before.py`.
An initial diagnostic incorrectly looked for it in the ZIP; that error output is
retained. The corrected forced-collision probe is `impl_publication_fixture_probe2.txt`
and its JSON. No source was checked out over the working tree.

54. **Claim adapter operations before dispatch; publish only current evidence.**
    The prior generation token was issued after `start()` returned. That protected
    a replacement from a late release, but not from a late load/reload completion.
    Each load, reload and restart now claims a pending operation under the metadata
    lock before backend calls. Unload/cleanup invalidate that intent before release.
    Successful publication requires the same token and that start's own load record,
    PID, identity and readiness, rather than a later process's liveness. Failed and
    restored paths check the token too: a superseded failure propagates without a
    rollback start or metadata write, and a failed start with an active backend
    never attempts to restore into it. A late completion's finally clears only its
    own pending marker, so it cannot admit competing work during a newer request.
    Deliberate same-value/empty parameter requests and competing loads/restarts are
    refused while an operation is pending; the unpublished setup cannot justify a
    no-op. There is no retry queue, second selected setup, cleanup owner or persisted
    generation field. Model/params/application publication is one short locked step;
    backend start/stop calls and process waits run outside that lock so cancellation
    still works. One-shot log-level publication uses the same metadata lock.
    Ordinary non-racing reload failure retains the existing restore attempt and
    report; user and timed cancellation retain their existing reasons. Raw backend
    access remains the resource owner's interface, not a second adapter scheduler:
    mismatch detection refuses stale verification; it does not infer the bypassing
    caller's requested configuration or coordinate arbitrary multiple controllers.

55. **Fake process evidence must describe the fake, not host PID occupancy.**
    The identity-aware recovery fake now records allocated synthetic PIDs and can
    answer whether its current synthetic process exists. A scoped pytest fixture
    routes only those registered PIDs to that evidence. Unknown PIDs still call the
    original conservative host query. Existing recovery cases use this fixture.
    Regressions force every host PID to appear occupied and separately force host
    query errors; both recover the dead fake with `orphan_free=True` and both still
    refuse to call an unknown PID orphan-free. The production `process_exists()`
    and `_no_orphan()` implementations are unchanged. Choosing a different unlikely
    integer would merely move the collision, so that approach was rejected.

The new adapter regression matrix covers load/reload/restart success, failure,
restoration success and restoration failure, both unload and cleanup replacement
routes, pending-request conflicts, and backend replacement without a new adapter
token. It checks the original exception, no stale rollback attempt, replacement
PID/setup/application preservation, a real subsequent parameter change, and fresh
restart. There are **29 new adapter cases**: preserved entry code fails **26** and
passes **3 controls** (`impl_publication_negative2.xml/.txt`). The original smaller
matrix's **21 failures / 2 controls** is kept as `impl_publication_before.xml/.txt`.
Two new recovery controls cover occupied and unknown host evidence. The original
reviewer's delayed-publication script is replayed with only fresh output paths and
its r2 command/restart diagnostics: `impl_publication_before_probe.json` and
`impl_publication_after_probe.json`. The after probe retains adapter/backend threads
5 and command `-t 5`, rejects the delayed call, and performs a real reload when 3 is
subsequently requested. The forced-collision fixture probe fails the original
`orphan_free` assertion and passes the repaired fixture, retaining conservative
unknown-PID evidence.

Preliminary validation: **125 focused tests passed**, including the repaired
late-release cases and legacy user/timed cancellation; a separate overlapping
recovery/audit selection passed 153 tests. Mypy is clean on 461 files. Final broad,
parity, simulation and provenance results will be recorded below when complete.
All earlier test artifacts and failed explorations are kept. The first smaller
focused run (106 passed) precedes the backend-evidence controls and is not the
final source gate.

56. **Retain one-shot debug logging until a start is attempted.** The first
    new-source broad run completed with 3,151 passed, 1 failed, 3 skipped and
    1 deselected (754.47 s). Its sole failure was the old one-shot-log test's
    deliberately minimal backend returning no load/identity evidence. That double
    is now based on the shared `FakeResidentBackend`, preserving its original
    [4, 5, 4] log-level assertion and adding a failed-stop case. It uses pytest's
    temporary model path instead of an unremoved NamedTemporaryFile. The added
    case exposed a regression in the first repair: claiming an operation had
    consumed the next-start debug override before stop succeeded. Consumption is
    moved back to the actual start boundary after stop and generation validation,
    under the metadata lock. A failed stop propagates its original exception and
    leaves the override for the next start attempt. Before this adjustment, the
    normal control passes and the failed-stop variant fails
    (`impl_publication_debug_before.xml/.txt`); the entry implementation already
    preserved that behavior, so this is explicitly a repair of our intermediate
    regression, not an additional defect attributed to the reviewer baseline.
    The first broad run and its source/hash snapshot remain preserved; final
    gates restart against `impl_publication_validation2_inputs.json`. The
    intermediate adapter, old debug fixture and then-current documentation are
    in `impl_publication_intermediate.zip`. Production's evidence requirement is
    not weakened to accommodate the incomplete double. Final packaging includes
    the changed debug fixture as well as the original two reported repairs.

The independent reviewer explicitly cleared job128's original software blockers
and classified its frozen runner (raw backend, not this adapter) software-ready.
It remains in `later` for a separately owner-authorized hardware run. Whole-project
acceptance awaits re-review of these repairs. No hardware/model run, saved setup
change, queue movement, commit or push is part of this correction.

## Independent review corrections — implemented (19 Oct 2026)

Owner commit `9e29ba85dc810641d3a13307f678420ff730bcc4` contains the previous audit.
The owner supplied an independent request-changes verdict: a concurrent stop/cleanup
can orphan a replacement; whole-line answer trimming erases standalone operators;
resident recovery and rollback checkpoint recovery still miss changed observed
defaults. These are accepted defects, not dismissed as existing design limitations.
The entry was clean. Before edits, all 508 Python files plus this handoff, roadmap,
job128 and frozen v8 rules were preserved in
`_jobs/out/impl_independent_fixes_before.zip` (SHA-256
`7bf72d255bf5da92b4dbf63dccb53d526213ce90efda95a21bd311f509c8f465`).
Original reviewer artifacts are retained unchanged. No hardware or Git mutation is
authorized. This remains the only maintained handoff.

51. **One completion owner per ready-process stop.** Both public `stop()` and
    `cleanup()` claim the same captured stop operation under the lifecycle lock.
    Concurrent callers wait on that operation's own bounded event, not a later
    generation's shared idle event; timing out never publishes idle. Process waits
    occur outside the lifecycle lock. Finalization targets only captured process
    and credential paths and publishes idle after bookkeeping, even on failure.
    A failed stop retains its process owner/PID for cleanup retry. Startup cleanup
    preserves its earlier non-waiting cancellation contract (callbacks cannot wait
    on their own starter); process termination is serialized separately, without
    holding that termination lock while waiting for the starter to unwind.
    Regression uses owned Python sleepers, never model engines, and always reaps
    its children. This addresses the ownership race, not cross-controller scheduling.

52. **Answer selection must not consume token-level evidence.** Remove whole-line
    markdown/operator stripping; supported formatting remains the existing token
    normalizer's responsibility. Lead-in recognition uses that normalizer too, so
    formatted number-free captions still work. Standalone edge operators remain
    unscorable through native, chat, partial-reuse and SWA comparisons, for correct
    and incorrect numeric payloads across the nine pairs. This enforces the already
    frozen v8 grammar; it changes no registered rule, workload, version or threshold.

53. **Share observed-baseline comparison across restoration owners.** A detached
    `ObservedConfigurationBaseline` records observed values and initial request
    contradictions/unverified settings. The dedicated verifier, live target recovery
    and rollback checkpoint recovery compare every previously known field, including
    defaults and missing restored evidence. Automatic owner requests are not replaced
    by observed fixed values. A deliberate successful configuration change establishes
    the live workload's new baseline; recovery must verify the existing one first.
    Rollback captures evidence during its existing checkpoint, before disruption,
    passes it explicitly through both failure routes and records it in the existing
    checkpoint event; no persisted record schema or measurement is added. Unknown
    unrequested defaults remain unknown. No claim of global optimality or semantic
    answer certification is made.

The review corrections continued on **19 Oct 2026**. Decision 51 also covers the
adapter's request bookkeeping: a deterministic public unload/cleanup probe shows
that an old release can return after a replacement load published its request,
then erase the replacement's model/params. Both cases fail before the adapter fix
(`impl_independent_adapter_before.xml`). A short metadata lock and generation token
now make clearing conditional on the captured request generation; long model loads
and process waits never hold that lock. Successful loads/reloads and deliberate
request updates publish a new token. This is not a global multi-controller lock.

The process-termination lock has a bounded acquisition timeout. A concurrent startup
termination cannot make another cancellation wait indefinitely. New stop errors and
Ctrl+C retain the original exception and process owner; cleanup retries it. The
existing interruption test formerly injected Ctrl+C on *every* termination attempt
but expected a later retry to succeed. It now covers both a single interruption
(retry succeeds after exit proof) and renewed interruptions (still unresolved),
retaining its original no-new-start and held-owner assertions. No production
interruption is swallowed to make that test pass.

Decision 52 also corrects label removal: `Answer: * 57` must not lose its standalone
operator. Only markup attached to a marked label is consumed with the label. The
existing backtick-as-quote grammar is retained; a backtick-only neighbour is not
newly reclassified as an arithmetic operator. The initial new test incorrectly
assumed otherwise; that failed exploratory run remains. Another exploratory fixture
changed telemetry's *requested* context instead of its independently observed
context. Its corrected case changes the latter; no production policy was weakened.

Regression sensitivity is measured against entry source injected only into isolated
test/probe processes. The package re-export of RollbackExecutor must also be rebound;
an earlier diagnostic missed that alias and exercised the new rollback class. That
initial output is preserved, not claimed as a before-result. The corrected probe
(`impl_independent_recovery_before2.json`) reproduces recovered=True and
failed_restored; the after probe gives recovered=False and failed_unrecovered.
The operator probe before2/after JSON retains native, chat and SWA conclusions.

The new file has **49 cases** across ownership, operators and recovery. Its earlier
42-case selection gives **31 failures / 11 passes** on preserved source
(`impl_independent_before2.xml`); the separate new termination cases give **3/3
expected failures** (`...before3.xml`), and the two initially unverified baseline
cases give **2/2 expected failures** (`...before4.xml`). The adapter's **2/2 failures**
are in its separate pre-fix artifact. These disjoint groups total the 49 cases,
but existing-request controls intentionally pass on old source. The prior before
run with the unrebound package alias is not substituted for the corrected evidence.

After repairs, the focused selection passes **187 tests, 1 skip**
(`impl_independent_focus6.xml`): new regressions, prompt reuse and resident adapter.
The earlier broader focused selection had **753 passes, 1 failure, 1 skip**
(`...focus3.xml`) at the repeated-interrupt fixture described above. That is not
reported as a pass. Mypy is clean on **461 files** (`...mypy6.txt`). Full Windows and
strict replay gates are still in progress; intermediate gates do not certify later
adapter changes. All original review artifacts remain intact. Job128 remains in
`later`, not run; no commit, push or saved-setup change is part of this work.

## Authority and maintenance

The owner switched this model from reviewer to implementer on 17 Oct 2026 and requested
**one new handoff** recording every implementation/design decision and its rationale.
This is that file. Update it in place for all subsequent implementation work; do not
create another handoff unless the owner explicitly asks. Earlier reviews, handoffs,
pre-registrations and results remain historical evidence and must be preserved.

**Current status (18 Oct 2026): audit follow-up implemented; final Windows software
gates pass: 3,071 passed, 3 skipped, 1 deselected; mypy clean on 460 files; strict
Practical 231/231 and Unbounded 328 scenarios / 323,916 events unchanged. Decisions
46-49 repair GPU attribution, path-capability inputs and restoration evidence;
decision 50 fixes a reproduced deadline-test race. The earlier 45-decision `.r2`
package and all failed/intermediate runs remain preserved. All 50 decisions, actual
coverage and remaining design limits are recorded below. Independent review is still
required; this is not exhaustive
line-by-line certification or a global-optimum claim. Job 128 remains prepared, not run.** The v7 findings and
earlier passing checks are preserved. The governing study amendment is now
`reuse-correctness-8`, in the final appended correction section. Earlier implementation and
self-audit sections are historical evidence. Job 128 remains in `later`, not run.

This maintained handoff began with the remaining job 128 judge finding in
`reviewer-job128-fixes-r3-review-2026-10-17.md`. That initial entry HEAD was:
`3badd7ba1300a6aec34804b134bdc1f261592695`. The workspace already contained the
uncommitted job 127 analysis corrections and job 128 implementation. Those were adopted
as existing work, not claimed as new work. The current v8 audit entry is recorded in its
appended section below. The old implementation handoff
`reviewer-implementation-handoff-2026-10-15.md` is retained unchanged.

No commit, push, hardware run or queue move is authorized by this implementation batch.
Job 128 stays in `_jobs/later`. Completion here means implemented, validated software
ready for review; it does not mean independent acceptance or permission to run hardware.

## Entry defect and scope

The study judge accepted `negative **57**`, `minus (57)` and formatted spelled numbers
as positive 57. Sign-word substitution ran before formatting was removed. The false
right verdict reached partial-reuse evidence and the full-cache comparison. The
documented magnitude plural `trillions` was also missing from the rejection set.

The previous fixes remain: exact rational comparisons, finite accepted numeric forms,
right/wrong/unscorable separation, all-load log verification, conclusive/inconclusive
comparison rules, matched chat references and interruption checkpoint retention.

The adopted study uses nine known-answer pairs, including job 127's exact regression
pair. Gemma runs default and full-SWA variants; Llama is the default-only control. Native
trials use three blocks per pair, a one-piece priming request and a 24-piece measured
request on each fresh load. Chat uses two blocks and three loads (client, identically
primed fresh reference, unprimed descriptive reference), with the first two alternating
order. That is 108 native trials plus 54 chat loads for Gemma and 54 native trials plus
54 chat loads for Llama. Saved setups are read only; context remains 4096; mains power,
cleanup, actual work counters and native reuse-slot evidence remain gating conditions.
The historical r4 pre-registration contains the complete unchanged G1–G7 rules.

## Decisions and reasons

| Decision | Implementation / why chosen | Limit or alternative |
| --- | --- | --- |
| Normalize outer formatting before spelling and numeric context | Use one early normalization stage for brackets, quotes and markdown surrounding words, then convert spelled numbers and inspect sign words next to the resulting numeric words. This closes combinations of supported forms without adding a regex for each example. | This is a finite answer grammar, not a general semantic checker. Unsupported forms remain unscorable. |
| Preserve punctuation boundaries | Keep trailing sentence/field punctuation while removing formatting. `Unit 7: 57` must remain distinct from two adjacent numbers `unit 7 57`. | Removing all punctuation early would change identifier/adjacency decisions. |
| Preserve standalone operators during normalization | A standalone `*`, `**` or bracketed operator must still reach the existing operator guard. | Blind markdown stripping could erase an arithmetic operator. |
| Apply sign words to exact parsed values | Inspect normalized neighboring words rather than substituting a sign into the raw sentence. Minus/negative negate the exact Fraction; plus/positive leave it positive. | An attached sign plus a sign word, or repeated sign words, is unscorable. No inferred double-negative arithmetic. |
| Reject ambiguous sign context | Reject multiple signs and trailing sign words next to numbers instead of silently ignoring them. | Conservative unscorable results may require reading the raw reply; they never establish a model failure or success. |
| Complete the existing magnitude list | Add the documented `trillions` plural and test the registered singular/plural forms. | No expansion into arbitrary English number expressions. |
| Keep the measurement and comparison owners | Change judge/grammar and tests only; preserve runners, lifecycle, workloads, model settings, trial ordering and evidence rules. | These stages have already passed adversarial checks and are unrelated to this defect. |
| Preserve raw replies | Normalize only the judge's local string; raw trial replies remain in the saved evidence. This keeps every score auditable against what the engine actually returned. | Explanation strings show normalized numeric labels; raw text is the authoritative response record. |
| Version the changed judgement | Advance study version to `reuse-correctness-5` before collecting real job 128 data. Retain older simulated outputs. | Evaluation transport version stays unchanged; only study judgement semantics change. |
| Keep one current handoff | Put the pre-registration amendment and implementation evidence here. Historical pre-registration r4 stays immutable. Wrapper/roadmap point here for the amendment. | Avoids another round-specific handoff or overwriting the earlier registered rules. |
| Test verdicts through study summaries | Cover sign words × formatting × digit/spelled values, ambiguous signs, operators, magnitude plurals, and downstream evidence/G3 classification. | A passing regex-only test would not prove that conclusions are protected. |

## Amended pre-registration for job 128

This section amends `reviewer-job128-prereg-r4-2026-10-17.md` **before any real job 128
result exists**. All conditions, pairs, trial order, usability requirements, G1–G7,
cleanup/power/interrupt stops and consequences in that document remain authoritative
except for the explicit rule 2/3 clarifications below. The earlier document is unchanged.

Study version: **`reuse-correctness-5`**.

1. After the existing first-answer-sentence selection, remove outer brackets, quotes,
   asterisks, underscores and backticks from words **before** converting spelled numbers
   and interpreting numeric context. Preserve trailing punctuation that distinguishes
   an identifier boundary (`Unit 7: 57`) from adjacent numbers. Standalone operators,
   including bracketed operators, remain present for the operator checks.
2. A normalized sign word immediately before an otherwise unsigned accepted number
   gives it its sign: minus/negative are negative, plus/positive are positive. This
   includes formatted digit and spelled forms: `negative **57**`, `minus (57)`,
   `negative [57]`, `minus **fifty-seven**` and `minus __fifty-seven__` all state -57.
   For expected 57 they are **wrong**, not right. Positive equivalents are right.
3. A sign word combined with an attached sign, repeated sign words, a standalone
   sign/operator next to the number, or a trailing sign word is **unscorable**. This
   includes `negative +57`, `negative -57`, `minus minus 57` and `57 negative`.
   Arithmetic between numbers remains unscorable.
4. The r4 finite numeric forms and exact Fraction comparisons remain. Unsupported
   exponents, magnitudes and Unicode digit forms remain unscorable. The documented
   magnitude/plural list includes both `trillion` and `trillions`.
5. These verdicts feed the existing summary unchanged: a negative answer to expected
   positive 57 under partial reuse is wrong evidence. An ambiguous form is inconclusive
   evidence. Neither can become a claim of a right answer or a removed failure.

This amendment is an implementation proposal for review, not independent review approval.

## Files and preservation

Pre-change copies of the four files edited by this batch are preserved in
`_jobs/out/implementation_job128_before_20261017.zip` (created exclusively, not overwritten):
the correctness module, its tests, the roadmap, and job 128 wrapper. The preceding
review's manifest is `_jobs/out/reviewer_job128_r4_checks.json`. Existing source changes
outside these files, original job 127 records, old simulations and reports are preserved.

Edited files: `src/inferenceos/tune/reuse_correctness.py`,
`tests/test_reuse_correctness.py`, `project-scope-and-roadmap-2026-10-08.md`,
`_jobs/later/128_reuse_correctness_study.ps1` (header only), and this handoff.

## Validation and completion

Implementation and software verification are complete. Independent review is pending.

### Concrete implementation

- `_unformat_word` removes outer formatting before `_spelled_to_digits` runs. It retains
  punctuation from the stripped suffix, so an identifier colon is not lost. It recognizes
  standalone operators before stripping markdown characters, including punctuation around
  an operator; `(*)`, `(**)` and `-;` cannot disappear into an empty word.
- `_SIGN_WORD` raw-text substitution was removed. `_SIGN_WORDS` supplies a finite context
  vocabulary. `judge` checks the normalized previous/next words, refuses ambiguous signs,
  and applies a negative word to the parsed Fraction. Explanatory labels retain that sign.
- `_MAGNITUDE` now includes `trillions` alongside `trillion`.
- No other existing function in the correctness module changed (AST-checked against the
  entry ZIP). `_unformat_word` is the only added function. `prompt_reuse.py`, runner and
  simulator retain their entry hashes. The wrapper's executable body is identical after
  removing comment lines and normalizing line endings; only its amendment/version header changed.
- Correctness tests increased from **191 to 310** (**119 new cases**): 72 composed
  sign/format/spelling cases, 13 ambiguous-sign/operator cases, 18 magnitude forms,
  7 exact-value/punctuation cases, 6 extra summary cases and 3 full G3 comparisons.
  The earlier 740 prefix/suffix combinations and all existing interaction tests remain.

### Results

| Check | Actual result / artifact |
| --- | --- |
| Regression sensitivity against preserved old module, injected only in memory | **51 failed, 62 passed, 197 deselected**. Expected failures in the selected new tests; old source files were not restored over the workspace. `_jobs/out/impl_job128_old_regressions.{txt,xml}` |
| Focused current prompt-reuse/correctness/job-script suite | **518 passed, 1 skipped**, exit 0. `_jobs/out/impl_job128_v5_focus.{txt,xml}` |
| Project/test mypy | **452 files clean**. `_jobs/out/impl_job128_v5_mypy.txt` |
| Direct script mypy | **2 files clean**. `_jobs/out/impl_job128_v5_scripts_mypy.txt` |
| Independent diagnostics | **1,620 exact numeric cases, 72 sign/format cases, 18 magnitude forms**, downstream evidence checks, AST scope and preservation checks passed. `_jobs/out/impl_job128_v5_diagnostics.{py,json,txt}` |
| Original reviewer r4 probe, output prefix changed only | Expected exit 1 at the assertion requiring negative forms to be falsely right. New code yields zero such forms. Original script retained. `_jobs/out/impl_job128_v5_old_probes.txt` |
| Broad Windows suite | **2,614 passed, 3 skipped, 1 deselected**, exit 0 in 581.89 s. `_jobs/out/impl_job128_v5_broad.{txt,xml}`. The reported monitor window test passed in this run. |
| Practical parity | **231/231 unchanged** against preserved `project_fixes_r2_practical.json`, existing normalization and no new exclusions. `_jobs/out/impl_job128_v5_practical_compare.txt` |
| Unbounded parity | **328 scenarios, 323,916 events, zero differences** against preserved `project_fixes_r2_unbounded.json.gz`, existing comparator and no new exclusions. `_jobs/out/impl_job128_v5_unbounded_compare.txt` |
| Correctness simulation | **done**, `reuse-correctness-5`, **108 completion trials + 18 chat trials / 54 loads**. `_jobs/out/impl_job128_v5_sim.json` (simulated only) |

The independent diagnostic distinguishes wrong, right and inconclusive summary evidence.
Formatted negative replies now produce `wrong only at the default` in the two-variant
probe, while double-sign/magnitude forms remain inconclusive. This is software evidence,
not a claim about a real model or a general `--swa-full` fix.

### Commands

PowerShell process-only execution preference for wrapper tests:
`$env:PSExecutionPolicyPreference = 'Bypass'`. The broad suite uses the established
outside-sandbox permission for existing read-only Windows CIM queries. No persistent
execution policy or machine configuration is changed.

```powershell
.venv\Scripts\python.exe -B -m pytest tests/test_prompt_reuse.py tests/test_reuse_correctness.py tests/test_job_scripts.py --basetemp=_jobs/out/impl_job128_v5_focus_tmp --junitxml=_jobs/out/impl_job128_v5_focus.xml -o addopts= -q
.venv\Scripts\python.exe -B -m pytest tests --ignore=tests/test_model_integration.py --ignore=tests/test_profiling_integration.py --ignore=tests/test_reasoning_integration.py --deselect=tests/test_experiment_integration.py::test_real_candidate_applies_to_real_backend --basetemp=_jobs/out/impl_job128_v5_broad_tmp --junitxml=_jobs/out/impl_job128_v5_broad.xml -o addopts= -q
.venv\Scripts\python.exe -B -m mypy --platform win32 src tests
.venv\Scripts\python.exe -B -m mypy --platform win32 --follow-imports=silent scripts/evaluate_prompt_reuse.py scripts/reanalyse_prompt_reuse.py
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py record . _jobs/out/impl_job128_v5_practical.json
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py compare _jobs/out/project_fixes_r2_practical.json _jobs/out/impl_job128_v5_practical.json
.venv\Scripts\python.exe -B scripts/unbounded_reference.py record . _jobs/out/impl_job128_v5_unbounded.json.gz
.venv\Scripts\python.exe -B scripts/unbounded_reference.py compare _jobs/out/project_fixes_r2_unbounded.json.gz _jobs/out/impl_job128_v5_unbounded.json.gz
.venv\Scripts\python.exe -B scripts/evaluate_prompt_reuse.py --simulate --study correctness --swa-full-variant --chat-exposure --blocks 3 --out _jobs/out/impl_job128_v5_sim.json
.venv\Scripts\python.exe -B _jobs/out/impl_job128_v5_diagnostics.py
git diff --check
```

For the old-module sensitivity reproduction, the equivalent reusable script is
`_jobs/out/impl_job128_old_regressions.py`: run it from the repository root. It injects
only the preserved module in memory and selects the same new tests as the original
`python -c` check. It deliberately exits 1 on the old code. Use fresh output paths when
rerunning diagnostics that create files exclusively.

Next after software verification: independent review of this change and amendment; owner
commit/run decision only after that review. No real job 128 result exists at entry.


### Final review package and limits

- Diff against the preserved entry files, plus this new handoff:
  `_jobs/out/impl_job128_v5.patch` (line endings normalized for readable comparison).
- Validation counts, hashes and entry commit: `_jobs/out/impl_job128_v5_checks.json`.
  Reproduction scripts/logs/XML, old-code failures and current diagnostics are retained.
- Original job 127 record hashes and preceding reviewer artifacts were verified unchanged.
- `git diff --check` passed. No source edits were needed after the main checks started.
- This batch changes the judge and its grammar only, with tests and documentary pointers.
  It supplies no hardware evidence, no general correctness guarantee for arbitrary reply
  language, no tune-path admission and no production-default change.
- Job 128 remains in `later`, not queued. No hardware run, commit or push occurred.
  The software and amended pre-registration are ready for another model's review.

Continue recording all future implementation decisions and results in **this file**.
Do not create another handoff unless the owner explicitly requests one.

## Adversarial self-audit — 17 Oct 2026

The owner requested an attack on every design/implementation choice in this handoff.
This is a self-audit, not an independent review. No implementation fix was made during
the audit, and no additional handoff or separate Markdown review was created. The
current status above supersedes any inference of readiness from the original passing
checks. The original implementation text is recoverable from its frozen diff and hash.

### Finding 1 — P2: unsupported Unicode digits can become right evidence

`reuse_correctness.py:317` discovers number words using `re.search(r"\d", word)`.
That recognizes Unicode decimal digits, but misses characters such as superscript
`²`, `³` and `⁰`, even though Python classifies them as digits (`str.isdigit()`).
The ASCII-only fullmatch is never reached for these separate words.

For expected 57:

| Reply | Actual | Required by the unsupported-number rule |
| --- | --- | --- |
| `57 ² degrees.` | right | unscorable |
| `57 ³ degrees.` | right | unscorable |
| `57 ⁰ degrees.` | right | unscorable |
| `² 57 degrees.` | right | unscorable |
| `57 ⁻² degrees.` | right | unscorable |
| `57² degrees.` (attached control) | unscorable | unscorable |

Through the actual summary, two default reuse replies `57 ² degrees.` produce right
partial-reuse evidence, `changed with reuse, still right`, and `wrong under neither` in
the full-cache comparison. The numeric modifier was ignored. This is within the
explicit unsupported Unicode/exponent contract, not a request for general English
understanding. The gate was inherited from r4; I retained it and overstated the protection
of the finite whitelist in this implementation without testing the complete candidate
character class. The same reproduction succeeds against the preserved r4 code.

Required next: discover unsupported numeric words using a consistent character-class
policy before the ASCII numeric fullmatch. At minimum, no Unicode digit may be skipped
because it is outside regex `\d`. Define the treatment of other numeric glyphs explicitly;
reject unsupported forms rather than interpreting them. Test separated and attached
Unicode digit modifiers across the nine pairs, then check their summary evidence is
inconclusive rather than right. Do not add another short blacklist of individual glyphs.

### Finding 2 — P2: my trailing-sign guard runs before identifier classification

`reuse_correctness.py:332` treats the next sign word as trailing context for every number,
including an identifier. Identifier recognition follows at line 338. This ignores the
colon boundary I deliberately preserved in normalization.

| Reply (expected 57, identifier 7) | Preserved r4 | Current v5 |
| --- | --- | --- |
| `Unit 7: positive 57 degrees.` | right | unscorable |
| `Unit 7: plus 57 degrees.` | right | unscorable |
| `Unit 7: negative 57 degrees.` | wrong | unscorable |
| `Unit 7: minus 57 degrees.` | wrong | unscorable |

This is an introduced regression. The sign word qualifies the answer after the colon;
it does not trail the identifier as an ambiguous sign. In an actual two-block summary,
negative labelled reuse answers lose their prior wrong evidence and become inconclusive.
Positive labelled fresh answers make an otherwise informative pair not informative.
These cases do not falsely establish a removal; they discard valid success/failure
evidence and can make the study unnecessarily inconclusive.

Required next: honor identifier roles and explicit punctuation boundaries when applying
sign adjacency rules. Retain the rejection of actual trailing signs, ambiguous multiple
signs and adjacent unseparated numbers. Add combinations of own identifier, colon,
positive/negative sign word and formatting across every pair, through both fresh and
reuse summary roles. Keeping punctuation is insufficient unless later guards use it.

### Attack coverage for every recorded decision

| Decision / implementation | Audit result and remaining limit |
| --- | --- |
| Early formatting normalization | Intended formatted-negative and spelled cases remain fixed. All 216 digit/sign/format combinations across nine pairs passed. Normalization order alone is insufficient without role-aware later guards (finding 2). |
| Preserve punctuation boundaries | Fails the signed-value-after-identifier composition in finding 2. The existing tests covered colon plus plain value, not colon plus sign word. |
| Preserve standalone operators | 104 separate/bracketed operator cases rejected as unscorable. No operator-loss reproduction found for the declared set. This is a finite set, not a claim about arbitrary mathematical prose. |
| Exact Fraction values and attached signs | 1,620 independently generated exact-value cases passed. No float rounding, sign reversal or rational-equivalence regression found. |
| Conservative ambiguous-sign rule | 32 repeated/attached double-sign cases rejected. The choice is sound for unsupported ambiguous values, but its application to identifiers is overbroad (finding 2). |
| Finite numeric forms and magnitude list | All 18 registered magnitude forms, including uppercase formatted plurals, rejected correctly. Numeric candidate discovery violates the Unicode contract (finding 1). |
| Measurement/comparison ownership and limited scope | Source hashes and preserved function scope are intact. The classification probes did not dispatch engine work or change cleanup counts. No lifecycle owner was added. |
| Preserve raw replies | Deep copies of all trial fields before/after classification are identical. The bad verdicts remain diagnosable from raw replies. |
| Study version / unchanged transport | v5 is identified in the implementation record and simulated study output. No tune-request or history-format change occurred. Versioning is appropriate; the semantic defects still require another amendment before hardware data. |
| One mutable handoff with historical evidence | The original v5 text is recoverable from the frozen patch; its original Windows CRLF byte hash verifies. Keep versioned amendment sections and frozen evidence when updating this file. No second handoff is needed. |
| Regression and summary testing | Test sensitivity to the original defect was real, but the generated cases missed Unicode digit-class discovery and identifier/sign composition. New counterexamples fail while all existing correctness tests stay green. Case counts alone did not establish complete grammar coverage. |
| Broad suite and parity gates | Valid evidence of general regressions and unchanged tune behavior. They do not validate a new development-study judge that the tune replays do not exercise. No need to reinterpret their green results as coverage of these findings. |

The finite judge remains a numeric-evidence classifier, not a general semantic answer
checker. Arbitrary prose qualifiers and units are outside its demonstrated semantic
coverage. This audit does not reopen every inherited language rule or claim that passing
the listed forms proves arbitrary replies correct. The two findings above violate the
explicit current rules and have executable downstream reproductions.

### New checks and artifacts

- Existing correctness suite: **310 passed**, exit 0, freshly rerun in this audit.
  `_jobs/out/impl_job128_v5_audit_existing.{txt,xml}`.
- New isolated contract suite: **63 failed, 45 passed**, expected failure exit 1 on the
  audited source: 27 separated Unicode-digit cases and 36 own-identifier/sign cases fail;
  attached-Unicode and standalone signed-value controls pass. These tests live only in
  `_jobs/out/impl_job128_v5_adversarial_cases.py`; no product tests were edited.
  Results: `_jobs/out/impl_job128_v5_attack.{txt,xml}`.
- Independent diagnostic checks: **1,620 exact numbers, 216 sign/format cases, 104 operator
  cases, 32 double-sign cases and 18 magnitude forms** pass; both findings are separately
  reproduced through actual `correctness_summary` output and compared with preserved r4.
- Raw trial data and engine dispatch counts remain unchanged by classification.
- Entry source/artifact hashes verified; original v5 handoff text recovered from the
  frozen diff, with CRLF restoration for its byte hash. The first audit draft assumed
  LF bytes when checking the normalized diff; its log is retained. That draft assertion
  was a reviewer-tool newline assumption, not a product defect.
- No fresh broad/mypy/parity claim: those checks were not rerun because no product source
  changed. Their earlier logged results remain historical implementation evidence.

Reproduce with fresh artifact names:

```powershell
.venv\Scripts\python.exe -B -m pytest tests/test_reuse_correctness.py --basetemp=_jobs/out/impl_job128_v5_audit_existing_tmp --junitxml=_jobs/out/impl_job128_v5_audit_existing.xml -o addopts= -q
.venv\Scripts\python.exe -B -m pytest _jobs/out/impl_job128_v5_adversarial_cases.py --basetemp=_jobs/out/impl_job128_v5_attack_tmp --junitxml=_jobs/out/impl_job128_v5_attack.xml -o addopts= -q
.venv\Scripts\python.exe -B _jobs/out/impl_job128_v5_adversarial_audit.py _jobs/out/impl_job128_v5_adversarial_audit_rerun.json
```

Audit script/output: `_jobs/out/impl_job128_v5_adversarial_audit.{py,json,txt}`; final
post-handoff check: `_jobs/out/impl_job128_v5_adversarial_audit_final.{json,txt}`.
Audit counts, artifact hashes and unchanged-source proof:
`_jobs/out/impl_job128_v5_audit_checks.json`.
The script allows the maintained handoff to change while checking its frozen entry
snapshot and every other recorded entry artifact. New JSON outputs refuse overwrite.

**Disposition:** fix findings 1 and 2 and update this same handoff/amendment before the
next independent review. No hardware, commit, push, queue move or product edit occurred
during this self-audit. It does not constitute independent acceptance.

## Corrections after the self-audit — 18 Oct 2026

The owner requested **"fix all"**, covering both findings above. This section records
the implementation and amendment in the same maintained handoff. No second handoff or
separate pre-registration file was created. The v5 implementation and self-audit text,
original tests/logs, and their frozen artifacts remain preserved.

### Decisions, implementation and reasons

| Decision | Implementation / rationale | Boundary retained |
| --- | --- | --- |
| Discover numeric characters more broadly than accepted number syntax | New `_has_numeric` uses `str.isnumeric()` over each character. Superscripts, fractions, Roman numerals and other Unicode numeric glyphs reach the existing ASCII fullmatch and are rejected as unsupported. | No conversion of Unicode glyphs to guessed numeric values, and no growing glyph blacklist. Ordinary accepted ASCII numbers and listed English spelling remain. |
| Share discovery with first-line selection | `answer_line` uses the same helper when deciding whether a colon-ended first line is a number-free lead-in. This also closes `²:` followed by a valid-looking later answer. | First line/sentence selection rules otherwise stay unchanged; unsupported numeric content cannot be silently skipped as a lead-in. |
| Share formatting/spelling normalization at that boundary too | A related within-batch probe found `__eight__:` followed by `57 degrees` was still skipped because first-line discovery examined unnormalized spelling. New `_normalise_answer` supplies the same canonical formatting/spelling pipeline to lead-in detection and scoring. | A genuine number-free lead-in still skips once. A numeric first line is judged as that first line, not replaced by a later convenient answer. |
| Validate an identifier before sign adjacency | `judge` determines whether a plain numeric token is the question's own identifier before the trailing-sign guard. | Wrong identifiers, signed/fractional/decimal identifiers and attached units still refuse scoring. |
| Use the colon as a specific identifier/value boundary | A following sign word is allowed after a **validated own identifier ending in a colon**. It then belongs to the next value: `Unit 7: negative 57` is wrong for expected 57; positive/plus is right. | This is not a blanket skip of identifier guards. Standalone operators, numeric adjacency and unsupported continuations still run. A plain value followed by a colon does not gain this exception. |
| Keep unseparated or ambiguous forms unscorable | `Unit 7 positive 57`, `57: negative 58`, double signs and separated attached signs remain unscorable. | The correction does not expand the grammar into interpreting arbitrary clauses. |
| Test the character-class policy, not a few code points | Scan every Unicode code point classified numeric by the current Python runtime, in four positions including a lead-in. Also check mixed/attached/separated forms and role/sign combinations across all nine pairs. | Unicode data version and count are recorded for reproducibility; successful examples are not a claim of a complete semantic language judge. |
| Test both evidence roles and the full comparison | Check signed identifier replies as fresh references and reuse candidates, with both positive and negative signs; check unsupported numeric modifiers through the summary. | A negative fresh reference must still make a pair not informative; a negative reuse reply must establish wrong evidence, and unsupported glyphs must be inconclusive. |
| Advance the study version before results | `CORRECTNESS_VERSION` is now `reuse-correctness-6`; roadmap and wrapper header point here. | Evaluation transport, tune requests/history, workload content, measurement ordering, cache settings, engine ownership and acceptance rules are unchanged. |

### Amended pre-registration — reuse-correctness-6

This amendment supersedes only the numeric-discovery and identifier/sign clauses of the
v5 amendment above, before any real job 128 result exists. All other v5/r4 study rules,
conditions, pair definitions, G1–G7 interpretations, cleanup/power/interrupt stops and
consequences remain unchanged. The historical r4 document is still retained unchanged.

1. A numeric character is any character for which Python `str.isnumeric()` is true.
   Every word containing one must pass the unchanged ASCII-only accepted number grammar.
   Unsupported numeric characters, including separate superscripts (`57 ²`), fractions
   (`57 ½`), Roman numerals and non-ASCII decimal digits, are **unscorable**. They are
   neither ignored nor converted. English spelled numbers retain their existing handling.
2. A first line containing such a numeric character, or a number recognized after the
   existing formatting/spelling normalization, is not a number-free lead-in. For
   example, `²:` followed by `57 degrees` is **unscorable** from its first line;
   `__eight__:` followed by `57 degrees` is **wrong** for expected 57 (it states 8).
3. A plain whole-number identifier must belong to the question. An explicit colon after
   that validated identifier separates it from the following signed value. Examples for
   expected 57: `Unit 7: positive 57` and `Unit 7: plus 57` are **right**;
   `Unit 7: negative 57` and `Unit 7: minus 57` are **wrong**. Existing outer formatting
   may surround the identifier/value. The same rule applies to the question's own row,
   section or note identifier.
4. Unvalidated identifiers and values receive no colon exception. `Unit 3: positive 57`,
   `Unit -7: negative 57`, `Unit 7.0: negative 57`, `57: negative 58`, unseparated
   `Unit 7 positive 57`, double signs and genuine trailing signs are **unscorable**.
5. Existing evidence rules apply without reinterpretation: unsupported Unicode forms
   produce inconclusive candidate evidence. A valid negative reuse answer is wrong
   evidence. Valid positive fresh answers preserve informativeness; negative fresh
   answers do not establish a valid comparison reference.

This is an implementation amendment awaiting independent review, not approval to run.

### Scope, preservation and validation

- Pre-change v5 source, tests, wrapper, roadmap and handoff are in
  `_jobs/out/implementation_job128_v6_before_20261017.zip`. Its historical date suffix
  is retained; the correction/validation section is dated 18 Oct. No old artifact was
  overwritten.
- Product scope: correctness module only (`_has_numeric`, `_normalise_answer`, `answer_line`, identifier/sign
  handling in `judge`, and version/documentation), plus regression tests. Wrapper
  executable code is unchanged; only its study-version header and roadmap pointer change.
- Correctness tests: **310 → 393**, 83 added cases. Those cases cover 162 Unicode
  modifier forms, 108 identifier/sign/format combinations, a complete numeric-character
  scan, 12 guard-preservation cases, 72 fresh/reuse summary scenarios, and 3 extra
  unsupported-glyph summary cases, plus 24 formatted/spelled first-line forms in four
  additional cases. Counts of generated forms are separate from test cases.
- The current Python Unicode database is **15.0.0**, with **1,902 non-ASCII numeric
  characters**. The exhaustive property checks all four placements for each (7,608 forms).

| Check | Result / artifact |
| --- | --- |
| New regression selection against preserved v5 code, injected in memory | **66 failed, 14 passed, 313 deselected**, expected exit 1; no source checkout or overwrite. `_jobs/out/impl_job128_v6_final_old.{txt,xml}` |
| Initial targeted correctness tests, before the related first-line correction | **389 passed**, exit 0. `_jobs/out/impl_job128_v6_target.{txt,xml}`. These are intermediate evidence; the final focused run includes all 393 correctness cases. |
| Final-source original, unmodified adversarial contract suite | **108 passed**, exit 0; previously 63 failed. `_jobs/out/impl_job128_v6_final_attack.{txt,xml}` |
| Final full focused suite | **601 passed, 1 skipped**, exit 0, including all 393 correctness tests. `_jobs/out/impl_job128_v6_final_focus.{txt,xml}` |
| Final-source broad Windows suite | **2,697 passed, 3 skipped, 1 deselected**, exit 0 in 511.60 s. `_jobs/out/impl_job128_v6_final_broad.{txt,xml}` |
| Final project/script mypy | **452 project/test files and 2 scripts clean**. `_jobs/out/impl_job128_v6_final_mypy.txt`, `impl_job128_v6_final_scripts_mypy.txt` |
| Final-source Practical / Unbounded replay | **231/231 unchanged; 328 scenarios / 323,916 events / zero differences** against the preserved `project_fixes_r2_*` recordings, with existing normalization and no new exclusions. `_jobs/out/impl_job128_v6_final_*_compare.txt` |
| Final-source correctness simulation | **done**, study `reuse-correctness-6`, **108 completion trials + 18 chat trials / 54 loads**. `_jobs/out/impl_job128_v6_final_sim.json` (simulated only) |

Final counts, reproduction commands, scope proof, hashes and a diff against v5 are
recorded below for review. No hardware, saved-setup
write, queue move, commit or push is part of this batch.

Within-batch validation history: the first v6 candidate ran before the formatted-spelled
lead-in correction. Its `impl_job128_v6_*` logs and simulations are retained as intermediate
evidence, including the earlier sensitivity result (65 failed / 11 passed). Final-source
verification uses the **`impl_job128_v6_final_*`** prefix. The first broad run is allowed
to finish; final broad verification starts afterwards, avoiding two concurrent broad
suites. No first-candidate result is substituted for a final-source result.

Independent final diagnostics: `_jobs/out/impl_job128_v6_final_diagnostics.{py,json,txt}`.
They verify 432 signed-identifier combinations (digit/spelled identifiers and values),
all 7,608 unsupported-Unicode placements, the original and related first-line examples,
actual summary/G3 outcomes, raw-data/dispatch immutability, unchanged class/function
scope outside `answer_line`/`judge`, and unchanged wrapper executable body. Only two
helpers were added. Other source and earlier artifacts, including original job 127
records, retain their hashes.

A supplemental hash spot-check initially looked for shared-module entries in the v5
summary manifest, which does not contain those entries, and raised a bookkeeping
`KeyError`. The checks were corrected to use the preserved r4 review manifest for those
three files. The successful explicit recheck is in
`_jobs/out/impl_job128_v6_final_scope_recheck.{json,txt}`; no source or reference was
changed to obtain the pass. It also reruns the same final diagnostics. Reproduction:
`python -B _jobs/out/impl_job128_v6_final_diagnostics.py NEW_OUTPUT.json` (use a fresh
output path). The final manifest includes both the original diagnostic and this recheck.


### Final v6 commands and review package

All commands run on Windows. Wrapper tests use process-only
`$env:PSExecutionPolicyPreference = 'Bypass'`; the broad suite uses the established
outside-sandbox permission for existing read-only CIM queries. No persistent execution
policy was changed. The final-source broad run started after the first run completed.

```powershell
.venv\Scripts\python.exe -B -m pytest tests/test_prompt_reuse.py tests/test_reuse_correctness.py tests/test_job_scripts.py --basetemp=_jobs/out/impl_job128_v6_final_focus_tmp --junitxml=_jobs/out/impl_job128_v6_final_focus.xml -o addopts= -q
.venv\Scripts\python.exe -B -m pytest tests --ignore=tests/test_model_integration.py --ignore=tests/test_profiling_integration.py --ignore=tests/test_reasoning_integration.py --deselect=tests/test_experiment_integration.py::test_real_candidate_applies_to_real_backend --basetemp=_jobs/out/impl_job128_v6_final_broad_tmp --junitxml=_jobs/out/impl_job128_v6_final_broad.xml -o addopts= -q
.venv\Scripts\python.exe -B -m pytest _jobs/out/impl_job128_v5_adversarial_cases.py --basetemp=_jobs/out/impl_job128_v6_final_attack_tmp --junitxml=_jobs/out/impl_job128_v6_final_attack.xml -o addopts= -q
.venv\Scripts\python.exe -B -m mypy --platform win32 src tests
.venv\Scripts\python.exe -B -m mypy --platform win32 --follow-imports=silent scripts/evaluate_prompt_reuse.py scripts/reanalyse_prompt_reuse.py
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py record . _jobs/out/impl_job128_v6_final_practical.json
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py compare _jobs/out/project_fixes_r2_practical.json _jobs/out/impl_job128_v6_final_practical.json
.venv\Scripts\python.exe -B scripts/unbounded_reference.py record . _jobs/out/impl_job128_v6_final_unbounded.json.gz
.venv\Scripts\python.exe -B scripts/unbounded_reference.py compare _jobs/out/project_fixes_r2_unbounded.json.gz _jobs/out/impl_job128_v6_final_unbounded.json.gz
.venv\Scripts\python.exe -B scripts/evaluate_prompt_reuse.py --simulate --study correctness --swa-full-variant --chat-exposure --blocks 3 --out _jobs/out/impl_job128_v6_final_sim.json
.venv\Scripts\python.exe -B _jobs/out/impl_job128_v6_final_diagnostics.py
git diff --check
```

- Diff against preserved v5, including this handoff update:
  `_jobs/out/impl_job128_v6_final.patch` (line endings normalized for readability).
- Final counts, source/artifact hashes, Unicode policy version and entry commit:
  `_jobs/out/impl_job128_v6_final_checks.json`.
- The 108 original adversarial cases now all pass; their source is unchanged. New
  product regressions also cover the fixes and downstream conclusions. The old-code
  sensitivity command is preserved in `_jobs/out/impl_job128_v6_final_old_recipe.py`.
- The intermediate broad run is retained in `impl_job128_v6_broad.*` and recorded in
  the manifest as an earlier candidate, not substituted for final-source verification.
- No source changes followed the start of the final focused run. `git diff --check`
  passed. The monitor answer-edge test also passed in the final broad run.

Both self-audit findings are closed by implementation and software tests. The additional
formatted-spelled first-line case is closed too. Independent review remains outstanding;
the finite judge still makes no claim of arbitrary-language semantic correctness.
No hardware job, saved-setup write, queue move, commit or push occurred. Job 128 stays
in `later`. Continue all subsequent implementation records in this same handoff.


## Independent v6 review corrections — 18 Oct 2026

Entry HEAD is `cd56c46b37a604b4c9f06d8920feaaec4306cca9` (the owner committed the
previous batch). Review `reviewer-implementation-handoff-v6-review-2026-10-18.md`
accepts the v6 changes and requests two P2 corrections plus a P3 rule-freezing improvement.
The original source, tests, wrapper, roadmap and this handoff at entry are preserved in
`_jobs/out/implementation_job128_v7_before_20261018.zip`.

### Decisions and rationale for v7

- Replace the finite `_DETACHED` glyph list with `_detached_symbol`: after removing
  outer brackets/quotes (ASCII plus Unicode Ps/Pe/Pi/Pf) and plain `. , ; : ! ?`, any
  nonempty neighbouring token with neither an alphabetic nor numeric character is
  unscorable. Empty punctuation is ignored. Standalone units `%`, `°`, `°C`, `°F`
  remain allowed. The existing letter `x` arithmetic guard remains explicit. This
  discovers unknown symbols without guessing their meaning or growing a blacklist.
- `_unformat_word` preserves such tokens, including `(*)` and `(**)`, rather than
  erasing them as markdown. `_sign_token` recognizes a sign word even with a trailing
  boundary, so unsupported punctuation cannot silently drop the sign or manufacture
  a negative value. Formatting is removed before this check; punctuation/closing
  delimiters are retained. A punctuation-separated sign is unscorable for either sign.
- Keep the validated identifier-colon exception from v6. The colon in `Unit 7:`
  belongs to the identifier; an immediate `negative 57` after it is still -57.
- A related first-line probe showed that `Negative:\n57` could lose the sign as a
  number-free lead-in. Such sign-bearing first lines now remain the answer line and
  are unscorable. Ordinary number-free lead-ins retain their previous behaviour.
- Advance the study to `reuse-correctness-7` before any hardware result. No measurement,
  workload, engine ownership, comparison logic, tune path or acceptance policy changes.
- Freeze only the governing rules, rather than another handoff: a UTF-8 rules artifact
  contains the preserved r4 pre-registration and v5/v6/v7 amendments, in that precedence
  order. It contains no implementation diary or future updates. Job 128 checks its
  hard-coded SHA-256 before any power wait or model dispatch and refuses missing or
  modified rules. This allows the ONE maintained handoff to continue evolving without
  changing the rules attached to the prepared run. Wrapper tests exercise both refusals.

### Amended pre-registration — reuse-correctness-7

This amendment supersedes the standalone-symbol and sign-boundary clauses in the prior
amendments; all other r4/v5/v6 study rules, G1–G7 interpretations, trial ordering, stops,
pair definitions and consequences remain. No real job 128 result exists.

1. After outer brackets/quotes and plain sentence punctuation `. , ; : ! ?` are removed,
   a nonempty standalone token immediately beside a number that has no alphabetic and no
   numeric character makes the answer **unscorable**. Brackets/quotes include ASCII
   delimiters and Unicode categories Ps/Pe/Pi/Pf. A token reduced to empty punctuation is
   ignored. The only symbolic standalone unit exceptions are `%`, `°`, `°C`, `°F`.
   Existing numeric/letter-continuation and `x` arithmetic guards still apply. In
   particular `‒ 57`, `57 −`, `≠ 57`, `< 57`, `57 ~` are unscorable; `57 °C` is supported.
2. Apply a recognized sign word only when formatting normalization leaves it immediately
   before the number with **no trailing punctuation or closing delimiter**. Otherwise
   the answer is **unscorable**, never right by dropping the sign and never wrong by
   applying it across the boundary. `negative, 57`, `Negative: 57`, `(negative) 57`,
   `plus; 57` and the corresponding spelled values are unscorable. A sign-bearing first
   line such as `Negative:` cannot be skipped as a number-free lead-in.
3. `Unit 7: negative 57` remains **wrong** for expected 57, while `Unit 7: positive 57`
   remains **right** (for the question's own identifier). Attached accepted signs,
   supported exact fractions and formatting retain their prior treatment.
4. Unscorable candidates produce inconclusive partial-reuse evidence. They cannot
   establish a G1/G2 wrong answer or a G3 removal. Existing established wrong evidence
   from other blocks/variants remains reported by the unchanged evidence rules.
5. The frozen rules artifact is `_jobs/later/128_rules_reuse-correctness-7.txt`.
   The prepared wrapper pins its exact byte SHA-256 and refuses absence or mismatch
   before launching any evaluation. Future rule changes require a new study version,
   explicit review and a new pin; the frozen v7 artifact is never edited in place.

### v7 verification record

Both P2 corrections and P3 are implemented. Correctness tests increased **393 -> 430**;
four executable wrapper refusal cases were added. The final-source checks are:

| Check | Result |
| --- | --- |
| Prompt-reuse / correctness / job wrappers | **642 passed, 1 skipped** |
| Broad Windows suite, established exclusions | **2,738 passed, 3 skipped, 1 deselected** |
| Project and script mypy | **452 project/test files and 2 scripts clean** |
| Practical replay | **231/231 unchanged** |
| Unbounded replay | **328 scenarios / 323,916 events / zero differences** |
| Correctness simulation | **done**, version 7; 108 native trials + 18 chat trials / 54 loads |
| New regressions against preserved v6, injected only in memory | **33 failed, 397 deselected**, expected exit 1 |

Replay baselines remain `project_fixes_r2_practical.json` and
`project_fixes_r2_unbounded.json.gz`; no exclusions or reference files were added/changed.
The simulation includes intentional fault modelling and has no hardware meaning.

The exhaustive Pd/Sm/So scan uses Python Unicode 15.0.0 and **7,608 characters**:
**136,944 direct placements** (both sides, all nine pairs) and **15,216 actual summary/G3
evaluations**, each covering all nine pairs. Additional regressions cover punctuation
and closing brackets after all four sign words, digit/spelled values, formatting,
Unicode-wrapped signs and the first-line boundary. Symbolic units and the original
identifier-colon behaviour retain explicit controls. Another **288 fresh/reuse evidence
role checks** verify that ambiguous answers cannot establish either a failure or removal;
the summary does not mutate the supplied trial evidence.

Scope diagnostics establish that only `_unformat_word`, `answer_line` and `judge` changed
among existing functions, with `_detached_symbol` and `_sign_token` added. Classes,
measurement/cleanup/power/chat/comparison functions and shared runner/simulator modules
remain unchanged. **43 earlier manifest entries** retain their original hashes.
The frozen rules hash is
`9aaf34e77d04757163e0cd3477490fd319cd5670f1ab35c313a93219ab5e8647`.
The wrapper verifies this artifact, not the mutable handoff; tests show missing/changed
rules refuse even with the test-only power bypass and perform no power query or dispatch.

Intermediate evidence is preserved under `impl_job128_v7_*`; final verification uses
`impl_job128_v7_final_*`. The initial focused run passed, but it preceded the added
Unicode-opening wrapper cases. The initial broad run was deliberately interrupted before
completion after that refinement; its partial log is not a passing result. Final focused
and broad runs use the final source. Final Practical and Unbounded recordings were made
again after that refinement. A draft probe's console print hit Windows cp1252 encoding
(the JSON had already been written); the final unchanged reviewer probe runs successfully
with `PYTHONIOENCODING=utf-8`. A PowerShell stdin encoding issue in the initial handoff
draft was repaired before creating the frozen UTF-8 artifact; its rules are checked against
r4 and all three authoritative amendment excerpts.

The final review package is `_jobs/out/impl_job128_v7_final_checks.json` (counts/hashes),
`impl_job128_v7_final.patch` (diff including ignored wrapper/handoff/rules evidence),
`impl_job128_v7_final_diagnostics.{json,txt}` and its script
`impl_job128_v7_diagnostics.py`. Original reviewer probes/results and all prior artifacts
are retained. No independent acceptance is claimed; job 128 still requires re-review.

Commands (Windows; use fresh output names when reproducing):

```powershell
$env:PSExecutionPolicyPreference='Bypass' # process only, for wrapper tests
.venv\Scripts\python.exe -B -m pytest tests/test_prompt_reuse.py tests/test_reuse_correctness.py tests/test_job_scripts.py --basetemp=_jobs/out/impl_job128_v7_final_focus_tmp --junitxml=_jobs/out/impl_job128_v7_final_focus.xml -o addopts= -q
.venv\Scripts\python.exe -B -m pytest tests --ignore=tests/test_model_integration.py --ignore=tests/test_profiling_integration.py --ignore=tests/test_reasoning_integration.py --deselect=tests/test_experiment_integration.py::test_real_candidate_applies_to_real_backend --basetemp=_jobs/out/impl_job128_v7_final_broad_tmp --junitxml=_jobs/out/impl_job128_v7_final_broad.xml -o addopts= -q
.venv\Scripts\python.exe -B -m mypy --platform win32 src tests
.venv\Scripts\python.exe -B -m mypy --platform win32 --follow-imports=silent scripts/evaluate_prompt_reuse.py scripts/reanalyse_prompt_reuse.py
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py record . _jobs/out/impl_job128_v7_final_practical.json
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py compare _jobs/out/project_fixes_r2_practical.json _jobs/out/impl_job128_v7_final_practical.json
.venv\Scripts\python.exe -B scripts/unbounded_reference.py record . _jobs/out/impl_job128_v7_final_unbounded.json.gz
.venv\Scripts\python.exe -B scripts/unbounded_reference.py compare _jobs/out/project_fixes_r2_unbounded.json.gz _jobs/out/impl_job128_v7_final_unbounded.json.gz
.venv\Scripts\python.exe -B scripts/evaluate_prompt_reuse.py --simulate --study correctness --swa-full-variant --chat-exposure --blocks 3 --out _jobs/out/impl_job128_v7_final_sim.json
$env:PYTHONIOENCODING='utf-8'
.venv\Scripts\python.exe -B _jobs/out/reviewer_job128_v6_probes.py _jobs/out/impl_job128_v7_final_probes.json
.venv\Scripts\python.exe -B _jobs/out/impl_job128_v7_old_recipe.py _jobs/out/impl_job128_v7_final_old # expected exit 1
.venv\Scripts\python.exe -B _jobs/out/impl_job128_v7_diagnostics.py NEW_OUTPUT.json
git diff --check
```

The broad suite uses established outside-sandbox permission for its existing read-only
CIM queries. No permanent execution policy change or new hardware evaluation occurred.
No hardware, commit, push, queue move or saved-setup write is part of this batch.

Final metadata check: the first manifest included the finalizer console log while it
was still being written. That live log entry is excluded; all completed artifacts and
source hashes were rechecked after finalization. The initial manifest is retained as
`impl_job128_v7_manifest_before_live_log_repair.json`. No source, rules or test result
changed during this metadata correction. The post-handoff diagnostic also passes.

## Adversarial self-review of v7 — 18 Oct 2026

The owner assigned this model the reviewer role as well and requested an attack on all
v7 implementation/design choices. **Verdict: request changes; job 128 is not ready.**
This is the implementation author's self-review, not independent model acceptance.
No product source, production test, wrapper, frozen rule, roadmap, queue entry or earlier
result was changed during this review. Only ignored diagnostic artifacts and this SAME
maintained handoff were written. The governing v7 artifact stays frozen; corrections
will need their own explicit amendment/version before hardware, not a silent edit.

### Finding 1 — P2: separate punctuation defeats the sign-boundary correction

`judge` looks at just the immediately preceding normalized word. Punctuation supplied
as its own token can either remain between the sign and number, hiding the sign, or
be erased by `_unformat_word`, making a closing delimiter disappear. This leaves the
required punctuation correction incomplete; all examples also reproduce against v6.

| Reply, expected 57 | Actual v7 | Required by the boundary policy |
| --- | --- | --- |
| `negative , 57 degrees.` | right | unscorable |
| `Negative : 57 degrees.` | right | unscorable |
| `The reading is negative ; 57 degrees.` | right | unscorable |
| `Unit 7: negative , 57 degrees.` | right | unscorable |
| `( negative ) 57 degrees.` | wrong (read as -57) | unscorable |
| `negative ) 57 degrees.` | wrong (read as -57) | unscorable |

The probe covers 10 split-boundary forms, digit/spelled values and all nine pairs:
**180 replies become 90 right and 90 wrong, none unscorable**. Through the actual
summary/G3, in all nine pairs:

- Keep an established default failure; replace the full-cache candidate with
  `negative , VALUE`: evidence becomes right and G3 says **wrong only at the default**.
  This falsely establishes absence of failure for an ambiguous answer.
- Start with no simulated fault; replace only the default candidate with
  `( negative ) VALUE`: evidence becomes wrong and G3 again says **wrong only at the
  default**. This manufactures a failure and apparent removal.
- The attached-punctuation control `negative, VALUE` is correctly inconclusive.

**Required:** preserve lexical boundary information through normalization. A punctuation
token cannot hide a nearby sign word, and deleting a standalone closing delimiter cannot
turn an ambiguous phrase into a signed measurement. Test whitespace on both sides of
punctuation/delimiters, tabs, formatting, all pairs and both evidence roles/G3. Preserve
supported `negative (57)`, balanced formatting and the own-identifier colon rule. Do not
patch this with a list of the demonstrated strings; the missing composition is the bug.

### Finding 2 — P2, inherited: unsupported Unicode spellings raise instead of judging

`_SPELLED` uses Unicode `re.IGNORECASE`, while its replacement indexes ASCII word
tables after `.lower()`. Those operations do not recognize exactly the same strings:

- `ſixty degrees.` (U+017F long s): `KeyError('ſixty')`;
- `fifty-ſeven degrees.`: `ValueError('ſeven' is not in list)`;
- `SİX degrees.` (U+0130 dotted capital I): `ValueError`;
- `FİFTY-SEVEN`, `ſeven` and `ſix` also raise.

All six also raise under preserved v6: **this is not introduced by v7**. It is a retained
normalization defect missed in earlier reviews, now verified rather than hypothesized.
An end-to-end simulated runner with such a reply exits **3**, status **error**, before
chat exposure starts. All **36 native trials** remain recorded and cleanup is clean;
there is no evidence loss or engine leak claim. It still aborts the study's classification
and later chat work because one unsupported model answer reached a dictionary lookup.

**Required:** make spelling discovery and supported-word validation agree. Unsupported
spellings must produce explicit unscorable evidence, not escape as parser exceptions.
Do not silently expand the frozen spelling grammar through guessed Unicode conversions.
Cover the direct judge, first-line normalization, summary and runner; retain ordinary
ASCII upper/lower-case spelling controls. Record the inherited attribution honestly.

### Finding 3 — P3, introduced: the symbol guard revokes formatted unit exceptions

`_unformat_word` applies the symbol-only guard before removing markdown. Therefore
`28 **%**` and `57 **°**` are unscorable while their plain-unit equivalents are right.
`28 _%_` has the same problem. V6 scored these right. The explicit unit exception is
recognized only in some surface forms: formatted `°C`/`°F` pass because they contain a
letter, whereas formatted `%`/`°` are treated as operators. The probe finds **36
right-to-unscorable regressions** across all nine pairs and the tested unit/format forms.

This is conservative rather than a false gain, but can discard a valid fresh reference
or candidate and contradicts composition of outer-format handling with listed units.
**Required:** recognize listed units with supported outer formatting before classifying
an entire formatted token as a standalone operator. Keep actual `(*)`, `(**)`, `≠`,
unsupported symbols and multiply/sign controls unscorable. Exercise reference/candidate
roles as well as direct verdicts. Avoid a blanket exemption for formatted symbols.

### Audit of the remaining decisions and claims

| Choice | Adversarial assessment |
| --- | --- |
| Character-property discovery for standalone symbols | Accepted direction. It closes the original 971 ignored glyphs and the unformatted Pd/Sm/So scan passes. It does not prove composition with separate punctuation or markdown units; findings 1/3 cover those gaps. |
| Keep an explicit `x` operator and narrow unit exceptions | Appropriate preservation of prior arithmetic and units. The exception needs to compose with formatting rather than depend on the token containing letters. |
| Retain closing punctuation after sign words | Correct for attached cases and Unicode-wrapped signs. Normalization of separate tokens remains destructive; finding 1 is the remaining structural problem. |
| Preserve the validated identifier-colon exception | Accepted. Controls retain `Unit 7: negative 57` as wrong and positive as right; ordinary operators/fractions/unsupported identifiers are not exempted. A later separate comma can still hide the sign and is part of finding 1. |
| Block sign-bearing number-free lead-ins | Conservative, with a wider cost than the minimal `Negative:` fix. `A positive example follows:\n57` now becomes unscorable too. This does not manufacture wrong evidence, but the earlier claim that all ordinary number-free lead-ins retain behaviour is too broad. Keep this tradeoff explicit when writing the next amendment; this finite judge does not parse adjective versus numeric-sign meanings. |
| Keep exact ASCII number grammar and Fraction comparisons | Accepted, with direct whole/fraction/sign controls. No evidence of changed numeric precision, measurements or acceptance policy. |
| New version and frozen rules plus pre-dispatch wrapper hash | Accepted for the requested freeze. The checksum matches r4 plus v5/v6/v7 amendments. Executable tests refuse missing/changed rules before power/model dispatch, including test-only power bypass. It pins rules in the wrapper, not inside each JSON result; retaining the wrapper/artifact/manifest is part of the evidence package. |
| Exhaustive scans and old-code sensitivity | Valid evidence for their stated shapes, insufficient to claim the tokenizer is fully composed. The new tests vary glyph and pair, but originally kept punctuation attached to the sign and units unformatted. The new contract suite exposes those omitted dimensions. |
| Scope, preservation and ownership | Accepted. Existing functions changed only in judge/format/answer-line handling, with two helpers added. Measurement, planner, cleanup, power and G3 decision code remain unchanged. No added measurement or production tuning path. |
| Manifest/live-log repair | Accepted after verification: all 32 delivered manifest hashes matched at audit entry. Frozen snapshot below preserves that exact entry handoff. This audit intentionally updates only the live handoff; the old manifest is historical, not silently refreshed to conceal it. |
| Software passes as a readiness claim | Earlier counts are accurate; they are not acceptance evidence for omitted contracts. The runner crash is inherited and the parser's numeric-only correctness limits remain. No hardware conclusion follows from a simulated study. |

### Review checks and reproductions

- All **32** v7 delivery manifest hashes verified before any handoff edit; preserved
  entry source/tests/wrapper/rules/handoff/manifest in
  `_jobs/out/reviewer_job128_v7_entry_20261018.zip`.
- Existing correctness + prepared-job tests rerun on Windows: **515 passed**. This
  includes the full single-glyph/summary scan and executable hash refusals.
- New isolated contracts: **132 failed, 9 passed**, expected exit 1: 90 split-boundary,
  6 inherited Unicode-error and 36 formatted-unit failures; controls retain supported
  numbers, signs, fractions, units and identifier roles.
- Project mypy clean on **452 files**; both scripts clean on **2 files**.
- Native/chat consequences were reproduced with simulated engines only. Raw supplied
  trial lists stay unchanged by summary classification. Runner raw trials/cleanup are
  retained on its error path.
- No new broad/parity pass is claimed: source did not change and their earlier result
  logs were checked. The recorded **2,738 broad passes**, Practical **231/231** and
  Unbounded **328 / 323,916 / 0 differences** remain historical implementation evidence.

Reproduce from the repo root with fresh artifact paths:

```powershell
$env:PYTHONIOENCODING='utf-8'
.venv\Scripts\python.exe -B _jobs/out/reviewer_job128_v7_probes.py NEW_OUTPUT.json
.venv\Scripts\python.exe -B -m pytest _jobs/out/reviewer_job128_v7_contract_cases.py --basetemp=NEW_TMP --junitxml=NEW_XML -o addopts= -q # expected exit 1
$env:PSExecutionPolicyPreference='Bypass' # process only
.venv\Scripts\python.exe -B -m pytest tests/test_reuse_correctness.py tests/test_job_scripts.py --basetemp=NEW_TMP --junitxml=NEW_XML -o addopts= -q
.venv\Scripts\python.exe -B -m mypy --platform win32 src tests
.venv\Scripts\python.exe -B -m mypy --platform win32 --follow-imports=silent scripts/evaluate_prompt_reuse.py scripts/reanalyse_prompt_reuse.py
```

Probes: `_jobs/out/reviewer_job128_v7_probes.{py,json,txt}`, plus the separately written
`reviewer_job128_v7_probes_runner_error.json`. The probe verifies the original handoff
from the frozen audit-entry snapshot so it remains reproducible after this required
in-place update; all other entry manifest files must still match their current bytes.
Contract suite/log/XML: `reviewer_job128_v7_contract*`. Existing tests/log/XML:
`reviewer_job128_v7_existing*`. Audit counts, entry/current hashes and disposition:
`_jobs/out/reviewer_job128_v7_audit_checks.json`.

**Disposition:** request changes for findings 1/2; address the introduced formatting
regression in the same correction. No fixes were implemented during this review.
Job 128 remains in `later`. No hardware, commit, push or queue move occurred.

## Full audit and implementation v8 — 18 Oct 2026

The owner requested fixes for all three v7 findings and a full audit of the intended
use case. Entry HEAD is `cd56c46b37a604b4c9f06d8920feaaec4306cca9`; the dirty v7
implementation was preserved in `_jobs/out/implementation_job128_v8_before_20261018.zip`
before editing. This audit covers the complete study route: answer grammar, native
work/reuse evidence, SWA comparison, ordinary chat exposure, simulation, real adapter,
runner/checkpoints/input provenance, prepared PowerShell wrapper and launch containment.
The full non-hardware test suite and unchanged Practical/Unbounded recordings check the
rest of the project for regressions. This is not an exhaustive proof of every module,
English answer or possible OS scheduling interleaving.

### Findings fixed, implementation choices and rationale

| Finding / consequence | Fix and why this implementation was chosen |
| --- | --- |
| V7-1: split punctuation erased the sign boundary (`negative , 57` right; `( negative ) 57` wrong). Both verdicts could manufacture G1/G3 evidence. | A shared neighbour traversal retains boundary/colon flags while looking across punctuation-only tokens. Sign words never cross sentence punctuation or a closing delimiter; opening numeric formatting remains supported. This handles composition rather than adding another punctuation list. |
| V7-2: Unicode case-insensitive spelling matches raised instead of producing an answer verdict. | Validate spelling lookup before converting; unsupported recognized forms remain visible and unscorable, including first-line lead-ins. No Unicode transliteration is invented. |
| V7-3: listed units wrapped in markdown were rejected as operators. | Recognize the four allowed units after outer formatting normalization before standalone-operator preservation. Actual operators remain unscorable. |
| Punctuation could hide a magnitude continuation; several different wrong values were called one wrong answer. | Use the same meaningful neighbour for continuations, and reject all distinct-value alternatives, whether or not one equals the expected value. This follows the registered ambiguity rule and avoids manufactured model failures. |
| Invisible format/control characters could hide a sign or make a numeric lead-in disappear; very large valid numeric text could crash Fraction parsing. | Reject non-whitespace Cc/Cf characters in the selected answer; catch exact-parser size errors as unscorable. Keep raw replies unchanged. Ordinary positive prose in a lead-in is allowed when the lead-in does not end in a sign word. |
| Native summaries trusted problem strings instead of validating the underlying cleanup/power/identity/freshness evidence. | Recompute work, immediate-reuse limits and identity hashes; require both power readings and confirmed process release, no credential-removal failure. A stopped/interrupted trial disables whole-study G3 interpretation even after earlier complete blocks. |
| Different configurations could be pooled across arms, blocks or SWA variants. | Require paired token counts and relevant request fields to match; retain a comparison identity and refuse mixed groups or variant comparisons. Identity omits the intentionally varied SWA flag. Model and executable identities are owned by the enclosing single-model runner. This is consistency checking, not an authentication scheme for hostile edited JSON. |
| Empty chat cleanup/power lists and incorrectly labelled measured replies could appear usable. | Require exactly the three planned cleanups, all six power boundaries, exact request roles/freshness flags, distinct valid blocks and per-request validity gates. Unknown cases are reported instead of crashing. |
| Chat usage and engine timing aliases could contradict while one preferred field passed. | Keep malformed/multiple-choice payload diagnostics; require reported total/completion/prompt counters to agree. Missing optional timing fields remain allowed; present malformed timings are not silently dropped. Native readings retain raw counters and require reported output aliases to agree; boolean times are not numeric evidence. |
| Incomplete startup logs could classify effective SWA from cache-size lines alone. | Require the load's own `model loaded` completeness marker before full/reduced classification, retaining all-load verification. No inference from the requested flag. |
| Zero/negative blocks, too few document sections and an empty case selection could create empty/missing-answer studies. | Refuse before engine work; at least 12 sections preserve every fixed known fact. The prepared job permits exactly its registered three native blocks. |
| An exists check before checkpoint writing allowed concurrent invocations to overwrite the same output. | Exclusively create/reserve the results name before any engine. Every later checkpoint comes only from this invocation's memory. A losing writer refuses; existing results are never merged or refreshed. |
| A native/partial chat checkpoint said `done` before the entire study finished. Disk failure later could leave false completion evidence. | Correctness progress is `running`; only final publication after analysis, cleanup and input checks can say `done`. Failed final publication exits nonzero. A pending Ctrl+C is preserved even when checkpoint publication also fails. |
| Results did not identify the exact model/engine bytes or carry the frozen rules pin. | Record model SHA-256 before/after, executable content identity (rehash when file identity changes), exact questions/generation settings, and governing rules digest/version from the first checkpoint. Changed model/executable input stops or invalidates conclusions. An unreadable initial executable is explicitly unverified, not assigned an invented hash. |
| Wrapper accepted contradictory successful reports and could proceed to the next model. | Verify run ID, done status, study version, governing digest, real-run marker and data-folder check; missing or contradictory successful evidence stops dispatch. Explicit incomplete/refused outcomes retain their historical non-success continuation. |
| Launch preparation/Popen errors leaked the newly created containment owner, and explicit failed assignment could return a usable server. | Own the guard before preparation; close on failure, preserve ordinary original errors, and fail assignment with a retained process-tree owner for the backend's existing unwind. Stop also releases a guard when no child was created. No second cleanup owner or new model process is introduced. |
| Windows HANDLE ABI was implicit in ctypes. | Set all used Win32 argument/return signatures explicitly, including pointer-sized handle returns. A native no-model test creates/closes a Job Object. This removes dependence on ctypes defaults; it does not claim observed high-bit handle corruption. |

The last ABI decision follows Microsoft's documented HANDLE contracts for
[CreateJobObjectW](https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-createjobobjectw)
and [AssignProcessToJobObject](https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-assignprocesstojobobject).

`KnownAnswerPair.case` and its SHA are cached pure immutable derivations: exhaustive
glyph/summary scans should not repeatedly rebuild/hash the large identical prompt.
No measurement, cache of model outputs, scheduling policy, selected setup or acceptance
threshold changes. New optional `Reading.engine_counters` and `ChatReading.problems`
fields are development-evaluation evidence; older dataclass records retain default empty
values. The evaluation transport version advances to `prompt-reuse-eval-5`, independently
of study version 8. RuntimeConfiguration and tune history formats are unchanged.

Ownership stays explicit: the resident backend owns processes, credential paths and
unconfirmed identities; its `LlamaServerProcess` owns containment handles. The real study
adapter retains that single backend and reads its release evidence. Native/chat trial
drivers own traversal and recorded observations, never a second cleanup queue. The
runner owns input fingerprints and the exclusively reserved output/checkpoint stream.
The wrapper owns only model sequencing, power waiting and report verification. The
judge and summary functions are pure derived analysis. The immutable case/hash cache
is not an engine-output cache. Windows assignment failure now intentionally refuses a
usable server rather than permitting it to run without the promised containment;
the existing backend failure owner performs termination and exit confirmation.

Model hashing reads all bytes before and after the study, outside timed requests. It
adds I/O and can warm the OS file cache; this correctness study makes no cold-load speed
claim. Both arms still have identical priming and work. Executable identity is checked
after successful load and before any request, with stat-based rehash on later loads;
the runner is not a security monitor against a malicious writer restoring metadata.

The final composition review also exercised an executable change **during chat**, after
native work was complete. The new input-change diagnostic initially became only a
failed chat load, which permitted further loads. It now stops chat immediately with
an error, retains cleanup evidence and disables final comparison interpretation. The
real adapter refuses any later start once an input change is known. A regression checks
one attempted load, one cleanup and no further dispatch. The earlier 800-pass focused
run and the deliberately stopped incomplete broad run are retained under
`impl_job128_v8_before_chat_stop_*`; final suites are rerun after this correction.

### Amended pre-registration — reuse-correctness-8

This amendment supersedes conflicting grammar, evidence and publication clauses in the
frozen v7 artifact. All unchanged r4/v5/v6/v7 pair definitions, generated document text,
trial order, context, generation limits, informative-pair threshold, G1–G7 consequences
and ordinary-client matching remain authoritative. No real job 128 data exists.

1. A punctuation-only neighbour is not evidence that the neighbouring sign/operator
   disappeared. Look through such tokens while retaining punctuation and closing-bracket
   boundaries. A sign word separated from its number by such a boundary is unscorable:
   `negative , 57`, `Negative : 57`, `( negative ) 57`, and spelled equivalents.
   Opening brackets around the numeric operand remain formatting: `negative ( 57 )`
   states -57. The question's own identifier-colon exception remains; `Unit 7: negative
   57` states -57. A sign-bearing lead-in is blocked when it ends in that sign word;
   `A positive example follows:` is ordinary number-free prose.
2. The standalone-symbol policy also looks across punctuation-only neighbours. Listed
   units `%`, `°`, `°C`, `°F` remain supported inside outer markdown, quotes/brackets.
   Actual standalone operators are not removed as formatting. A magnitude/exponent or
   lone-letter continuation across punctuation is unscorable (`57 , million`, `57 , M`).
3. Unsupported Unicode spelling matches, non-whitespace Unicode Cc/Cf characters and
   numbers beyond the exact parser's supported size are unscorable, never exceptions
   or silently discarded tokens. The existing ASCII number grammar, exact Fraction
   comparison and full Unicode numeric discovery remain unchanged.
4. Several distinct stated values are unscorable even if all are wrong (`56 or 58`
   for expected 57). The judge remains a first-answer numeric/refusal grammar, not a
   general semantic correctness oracle. Raw complete responses remain available for
   human adjudication; a right numeric label does not certify the rest of an answer.
5. Usability must be established from underlying evidence, not absence of diagnostic
   strings: cleanup, power boundaries, request identities/configuration, actual work,
   freshness/reuse bounds, native slots and chat role/order evidence. Reported counter
   aliases must agree. Incomplete or stopped trials cannot establish absence/removal of
   a failure. Different configurations cannot be pooled across blocks or SWA variants.
   Effective SWA requires each load's complete log, including its model-loaded marker.
6. Invalid empty studies are refused. Results are exclusively reserved, progress stays
   `running`, and only final publication can report `done`. Interruptions stay interrupted
   even if publication fails. Frozen rules/version, model content identity and observed
   engine identity/verification limits are carried in the run record. Changed input
   bytes invalidate study interpretation; no new measurement or production admission
   follows automatically from the study.
7. The governing frozen artifact is `_jobs/later/128_rules_reuse-correctness-8.txt`,
   consisting of the unchanged v7 rules followed by this amendment. The wrapper pins
   exact bytes and passes the path/digest to the runner. Both verify before model work;
   every checkpoint carries the pin. Earlier frozen artifacts remain unchanged.

### v8 audit coverage and remaining limits

The parser tests cover the nine pairs, all Pd/Sm/So glyphs on either side, split and
attached sign punctuation, supported numeric forms/formatting, unsupported Unicode,
summary evidence and G3. New end-to-end tests mutate evidence, interrupt publication,
race two simulated writers, vary executable/model inputs and exercise cleanup owners.
The unchanged v7 reviewer contract suite is rerun separately, not rewritten to pass.

No finite test set proves all possible English. For example, a numerically correct first
sentence does not prove units, explanation or the rest of the reply are semantically
right; this is now explicit run metadata. Conclusions are limited to the nine fixed
pairs, pinned engine/model/settings and observed trials. A verified full-SWA comparison
is not permission to enable reuse or change production defaults. Real engine behavior,
slot routing and effective SWA logs still require job 128 after review and owner approval.
Launch failure/containment changes receive software/native-API tests here, not a new
real-engine smoke. No hardware, queue movement, commit or push is performed.

Final verification counts, exact commands, reproducible diagnostics and artifact hashes
will be appended here after all checks complete; earlier candidate runs remain labelled
as candidates and are not substituted for final-source checks.

## v8 final software verification

| Check | Windows result |
| --- | --- |
| focus | 801 passed, 1 skipped |
| broad | 2897 passed, 3 skipped |
| contract | 141 passed, 0 skipped |

Broad suite: one deliberately deselected real-backend test; the three named
model/profiling/reasoning integration files remain excluded. No hardware test
was run. Broad execution uses the already authorized read-only CIM queries.
Type checking: **453 source/test files plus both evaluation scripts clean**.
Practical: **231/231 unchanged**. Unbounded: **328 scenarios, 323,916 events,
zero differences**, against the unchanged `project_fixes_r2_*` Windows files.
Existing comparator exclusions are unchanged and their named locations appear
in the comparison logs; this is not an every-field/no-normalization claim.

Correctness simulation: **108 native trials, 18 chat blocks / 54 loads**,
done, study 8, transport eval 5, frozen digest in the result. The injected
default-SWA failure is simulated and has no hardware meaning.

The independent entry contract suite had 132 failures / 9 passes on v7;
the unchanged 141 cases now pass. Additional before/after diagnostics load
the exact preserved v7 modules, reproduce all three original findings and
the new evidence/comparison/log gaps, then assert their corrected behavior.
Outputs: `impl_job128_v8_final_{before,after}_diagnostics.{json,txt}`.

Read-only reanalysis of all four real job 127 source records exactly matches
the previous e7-status-3 summaries; no duplicate loads, all original source
SHA-256 values unchanged. This is a reanalysis, not new hardware evidence.

The governing SHA-256 is `4a80891cb9f607da6d341f27d0da090148292a199d389d4101b6038b8e293734`. The old frozen v7 bytes
still match their original SHA. The full rule amendment is verified against
the frozen artifact, not reconstructed from a changing summary.

Artifacts: `_jobs/out/impl_job128_v8_final_checks.json` (hashes/counts),
`impl_job128_v8_final.patch` (complete dirty tracked diff plus new audit tests
and ignored wrapper/rules/handoff changes), `impl_job128_v8_final_since_v7.patch`
(this audit against its preserved entry), and final-prefix logs/XML/recordings.
The static finalizer hashes completed evidence only; its own live console log
is intentionally excluded. Earlier candidates, failures and reviews remain.

### Exact final commands

```powershell
$env:PSExecutionPolicyPreference='Bypass' # process only, executable PowerShell wrapper tests
.venv\Scripts\python.exe -B -m pytest tests/test_prompt_reuse.py tests/test_reuse_correctness.py tests/test_reuse_study_audit.py tests/test_job_scripts.py --basetemp=_jobs/out/impl_job128_v8_final2_focus_tmp --junitxml=_jobs/out/impl_job128_v8_final_focus.xml -o addopts= -q
.venv\Scripts\python.exe -B -m pytest tests --ignore=tests/test_model_integration.py --ignore=tests/test_profiling_integration.py --ignore=tests/test_reasoning_integration.py --deselect=tests/test_experiment_integration.py::test_real_candidate_applies_to_real_backend --basetemp=_jobs/out/impl_job128_v8_final2_broad_tmp --junitxml=_jobs/out/impl_job128_v8_final_broad.xml -o addopts= -q
.venv\Scripts\python.exe -B -m pytest _jobs/out/reviewer_job128_v7_contract_cases.py --basetemp=_jobs/out/impl_job128_v8_final_contract_tmp --junitxml=_jobs/out/impl_job128_v8_final_contract.xml -o addopts= -q
.venv\Scripts\python.exe -B -m mypy --platform win32 src tests
.venv\Scripts\python.exe -B -m mypy --platform win32 scripts/evaluate_prompt_reuse.py scripts/reanalyse_prompt_reuse.py
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py record . _jobs/out/impl_job128_v8_final_practical.json
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py compare _jobs/out/project_fixes_r2_practical.json _jobs/out/impl_job128_v8_final_practical.json
.venv\Scripts\python.exe -B scripts/unbounded_reference.py record . _jobs/out/impl_job128_v8_final_unbounded.json.gz
.venv\Scripts\python.exe -B scripts/unbounded_reference.py compare _jobs/out/project_fixes_r2_unbounded.json.gz _jobs/out/impl_job128_v8_final_unbounded.json.gz
.venv\Scripts\python.exe -B scripts/evaluate_prompt_reuse.py --simulate --study correctness --swa-full-variant --chat-exposure --blocks 3 --preregistration _jobs/later/128_rules_reuse-correctness-8.txt --preregistration-sha256 4a80891cb9f607da6d341f27d0da090148292a199d389d4101b6038b8e293734 --out _jobs/out/impl_job128_v8_final_sim.json
.venv\Scripts\python.exe -B _jobs/out/impl_job128_v8_diagnostics.py NEW_BEFORE.json --before
.venv\Scripts\python.exe -B _jobs/out/impl_job128_v8_diagnostics.py NEW_AFTER.json
.venv\Scripts\python.exe -B _jobs/out/impl_job128_v8_check_job127.py # exclusive new audit output; reads originals only
```

Self-review disposition: no confirmed software defect remains open in this
audit's scope. This is not independent acceptance or a claim that all possible
defects have been found. The finite grammar, verification limits and hardware
boundary above remain explicit. Owner/independent review should inspect the
full diff and frozen amendment before approving job 128. No commit, push,
hardware run or queue move occurred.

## Project-wide audit scope correction — 18 Oct 2026

The owner clarified that **everything built so far, and the interactions between all
optimization paths**, is in scope. The preceding v8 review was a study/dependency audit;
its passing suite and replays do not constitute the requested project-wide audit. That
limitation is now explicit. This section is maintained in the same handoff.

Entry HEAD remains `cd56c46b37a604b4c9f06d8920feaaec4306cca9`. Before extending the audit,
all source/test/script text plus this handoff, roadmap and the v8 manifests were archived
to `_jobs/out/impl_project_full_audit_before_20261018.zip` (SHA-256
`b42017cf2cfeaf72794b1a3e8480fd599139cefeb4702ae75d8e6c66b75ebb9a`). The inventory is
`_jobs/out/impl_project_full_audit_inventory.json`: **265 source modules, 77,999 lines,
178 top-level test modules**. Import relationships and exact entry source hashes are
recorded. Updating the live handoff intentionally supersedes its v8 manifest hash; the
previous verified handoff is preserved in that archive. No old manifest is rewritten.

### Coverage ledger (bounded source audit and software validation, not independent acceptance)

| Area | Required checks | Current evidence |
| --- | --- | --- |
| All eight tune paths | applicability, candidate generation, actual application, workload/quality guards, memory fit and cross-path side effects | Declarations, applicability, path handlers and shared pipeline boundaries inspected; unknown effective settings remain explicitly unverified |
| Path interactions | read/write dependencies, invalidation/revisits, captured bases, stale evidence, merged changes, combined setup and approval subsets | Actual policy/coordinator, planner and combined-selection routes inspected; layer-to-switch invalidation fixed; global-optimum limitations below remain |
| Practical | path admission boundary, budgets/reserves/extensions, history hints/costs, earlier complete setups, stop/reason fidelity | Existing three-category dispatcher, completion and selection inspected; 231-scenario replay unchanged; no new admission policy enabled |
| Measurement/confirmation | freshness, correct configuration/workload, process attribution, noise, quality, fixed-look acceptance and effective settings | Profiler, measurement scopes, stream protocol, CLI counters, quality and acceptance boundaries inspected and repaired; no threshold change or hardware validation |
| Persistence/start/deployment | exact saved data, transactional failures, selected setup identity, requested versus observed settings, lifecycle and credential ownership | R1–R5 retained; model-generation binding, atomic deployment, shared pure release proof and failed-start routes inspected/repaired |
| Runtime monitor/recovery | actual target identity/settings, checkpoints, cancellation, pause/drain, restoration and stale knowledge | Previously deferred request-as-observation problem repaired; live approval and checkpoint/restore failure routes tested; no monitor activation |
| Older optimization/card engine | compatibility/clashes, preconditions, costs, safety, evaluation, keep/revert and knowledge transfer | Registry/executor/action schema, resource envelope, baseline conversion, quality, restoration and rollback boundaries inspected; not interchangeable with tune acceptance |
| Historical learning/knowledge | model/build/hardware/workload/goal identity, negative evidence, cost provenance, no historical acceptance bypass | Applicability, rollback, request compatibility and cost consumers inspected; missing conditions remain conditional and historic timings remain advisory |
| Models/hardware/telemetry | GGUF facts/estimates, architecture support, GPU selection, memory/paging and power attribution | GGUF bounds/types/arrays, profile dimensions/source binding, output-layer estimate, numeric validity and sampler ownership repaired; ambiguous multi-device scalar capacity is unknown, not invented |
| Reasoning/outer loops | untrusted suggestions, plan validation, bounded execution, corroboration and fallback behavior | Registered action boundary, reasoner swap/release, reload observations and bridge failure routes inspected; queue records are accounting, not a network replay service |
| OS/external-process operations | authorization, PID identity, reversible actions, journal/restore and actual activation boundaries | Registry and external safety still structurally recommendation-only; owned-child interruption cleanup repaired; no external mutation or OS path enabled |
| CLI/reporting/storage | end-to-end command routes, error exits, truthful coverage/results, atomic publication and compatibility | Tune/start/deployment error/report routes, atomic writers and allowlisted retention inspected; native and CLI counters distinguished; real model integrations excluded |
| Development studies and jobs | separation from tune, preregistration/evidence, no silent activation, wrappers and artifact integrity | Frozen v8 study retained; runner gets actual partial protocol evidence without treating it as usable work; job-wrapper tests included in Windows scan |
| Overall design/claims | implemented versus planned, consistency between parallel mechanisms, no claim of a global optimum or unproven path-admission benefit | Roadmap entry updated; finite search/coverage and request-versus-observation limits documented below; final source gates pass, independent review pending |

Passing old tests is not sufficient to mark an area reviewed. Confirmed defects require
a reproduction, a fix and appropriate interaction/end-to-end regression evidence. Missing
future capabilities are recorded as design gaps; this audit does not activate new paths,
change acceptance thresholds or launch hardware without the owner's authorization.

### Whole-project findings and implementation decisions (completed repairs; chronological evidence)

The independent entry probes are `_jobs/out/impl_project_full_probes.py` and
`impl_project_full_before_probes.json`. The initial 15 new boundary regressions all
failed against the entry source (`impl_project_full_before_tests.txt/.xml`). This
is new defect evidence beyond the earlier study audit. No historical replay has
been refreshed to erase a difference.

1. **Layers must invalidate engine switches.** A memory change can cause a nested
   layer revisit after engine switches finished. The declaration said switches
   read layer placement, but layers did not invalidate them. The scripted actual
   coordinator checked switches only at 8 layers, then changed to 13. Added this
   missing dependency, retaining existing queue ownership, ordering and revisit
   bounds. The old declaration table remains literal in its test; this correction
   is named separately. An Unbounded replay difference caused by this correction
   is expected to need explicit classification, not a wider exclusion.
2. **Measured model identity must survive until publication.** A scripted model
   replacement during measurement previously saved old measurements under the new
   file's hash. Both tune entry routes capture resolved path, size, mtime_ns and
   inode before measurement. The existing save guard now checks that signature
   before/during hashing and under the store lock before publication. Cancellation
   retains its original guard lock/event and commit point. `ModelFileChanged` uses
   the existing failure-report/no-save route. Cheap stat checks avoid adding a
   second multi-gigabyte hash and warming the file before timing. This protects
   ordinary writes/replacements, not hostile preservation of file metadata or an
   external mutation after the final check; it is not filesystem attestation.
3. **Deployment publication and output-layer validation.** Publishing a deployment
   now uses the existing atomic text writer, preserving prior bytes on failed
   replacement. Validation permits the separate output step (`n_layers + 1`), as
   tune already does; no additional GPU capacity is inferred.
4. **Older action inputs must match the registered schema.** Missing parameters,
   nonfinite numbers, float bound violations and enormous integers are refused
   without accidental OverflowError or a claimed no-op application. Unknown-name
   error priority is retained. No OS/system action is enabled by this change.
5. **Release evidence is shared, cleanup ownership is not.** The new pure
   `backends/release.py` reads active state, retained PID, held key path, undeleted
   paths and explicit unload evidence. It performs no stop or cleanup. Unknown
   legacy credential evidence remains unknown; explicit failed or unreadable
   evidence cannot become a clean result. Deployment always calls the resident
   adapter's existing cleanup, even after a dead or partially started engine.
   `start` uses the same evidence and calls the older stop-only owner's release
   after failed startup. The old test fake now records/clears its credential when
   starting/stopping, rather than returning a permanent path after release; real
   held credential paths remain a veto. Failed startup prints cleanup problems.
6. **Recovery must observe settings, not echo requests.** The previously deferred
   monitor follow-up is in this full audit's scope. Shared comparisons moved from
   deployment into `backends/observed.py` (the deployment import remains available).
   Recovery requires actual telemetry without contradictions or missing requested
   settings. Missing evidence refuses recovery rather than inventing verification.
   The startup parser reads b11139's own `n_ctx_slot` initialization line; the
   telemetry context copied from params is still never used as proof. Unknown
   settings such as engine switches can therefore prevent automatic recovery;
   ordinary requested start keeps its existing explicit-unknown contract. Cleanup
   failure prevents a reload, and unreadable orphan checks no longer mean success.
   Primary source for the per-slot log/capacity:
   https://raw.githubusercontent.com/ggml-org/llama.cpp/b11139/tools/server/server-context.cpp
   (`n_ctx_slot()`, startup initialization). This does not change slot allocation.
7. **A reused restoration verifier cannot inherit an older baseline.** Capture now
   clears previous baseline fields before attempting the new probe. Failed capture
   therefore cannot later verify against an earlier experiment's successful probe.
   Other restoration and reasoning lifecycle checks remain under active review.

Intermediate verification: 106 boundary/coordinator/declaration/executor/deployment
tests passed in `impl_project_full_boundary1.txt/.xml` before the release/recovery
changes. Subsequent targeted checks are ongoing; no project-wide passing result or
completion verdict is claimed. The first release run exposed four old fake-credential
bookkeeping assumptions, which were corrected in the fake rather than weakening the
resource-release gate. A later sandbox test invocation could not create pytest's
default external temp directory; the rerun uses a new workspace-local basetemp.

8. **Reasoner/target exclusivity uses release evidence.** The older resident
   diagnosis flow could restore the target after an incomplete reasoner unload.
   Both process and credential evidence now gate normal reload and cleanup reload.
   The concrete reasoner exposes its existing backend's cleanup/evidence; no second
   owner is added. Failed reasoner startup is included in that cleanup boundary.
   Failed unload measurements remain in the outcome after a successful fallback
   cleanup. The failure-injection test which formerly required overlapping models
   now requires the target to remain stopped when reasoner release is unconfirmed.
   A successful current fake cleanup clears its stale fake unload record, while the
   real retained PID/key records remain authoritative. Request delivery/accounting
   and effective settings in this older flow are still under review.
9. **Noise cache input and publication.** Cached spreads must be nonnegative finite
   numbers (zero is valid); bools, negative values, overflow and nonfinite values
   cannot influence planning. Invalid additions leave the cache untouched. Cache
   publication uses the existing atomic writer. This remains an advisory cache,
   with its existing model/setup-family/workload identity and count rules; it is
   not confirmation evidence or a concurrent transactional knowledge store.
10. **Every answer must pass quality checks.** New direct suite reproductions showed
    five exact good answers could hide an unrelated sixth answer, or a fourth-length
    answer, and still receive acceptable_variation. Both regressions fail against
    the previous evaluator (`impl_project_full_quality_before.txt/.xml`). Similarity
    now uses the worst answer's best reference; coverage and length are checked per
    answer against demonstrated references. The existing length check now actually
    gates the verdict, and validated cannot be true after a failed semantic check.
    Thresholds are unchanged. Default suite version is 7r.2; persisted old results
    remain old evidence. This is a conservative baseline-preservation check, not a
    general semantic correctness oracle; negation, units and arbitrary factual
    meaning still cannot be guaranteed by text similarity. Known-answer checks
    remain authoritative where required by the existing precision policy.
11. **Unknown OS process queries cannot establish exit.** process_exists now errs
    towards possibly present when the OS query fails. A memory-read failure retains
    exists=True when the process still exists; missing memory is not process exit.
    This closes a false-clean path shared by wait_process_exit and resident cleanup.
    No unknown PID is killed by this observation change.
12. **Bounded GGUF reads and actual skipping.** An impossible u64 string length
    formerly reached the file reader as an allocation/overflow request. Reads now
    check remaining file bytes first and raise GgufError. Array payloads and skipped
    strings seek over validated spans instead of allocating discarded payloads.
    Legitimate metadata parsing and tensor descriptors remain unchanged. Deep nested
    arrays and metadata identity across concurrent model replacement remain under
    review. A stale model_facts docstring was corrected to output-first; the actual
    placement algorithm was checked against pinned b11139 source and is unchanged:
    https://raw.githubusercontent.com/ggml-org/llama.cpp/b11139/src/llama-model.cpp

Intermediate checks added: `impl_project_full_boundary5.xml` records 115 passing
release/recovery/restoration/deployment/start/lifecycle tests. The two quality
reproductions and existing quality suites pass after the correction
(`impl_project_full_quality_after2.xml`, 81 tests). `impl_project_full_boundary6.xml`
records 68 passing boundary/GGUF/recovery/lifecycle tests. Mypy is clean on 456
source/test files (`impl_project_full_mypy4.txt`). The first new Practical replay
is **231/231 identical** to the preserved v8 recording under the unchanged strict
comparator (`impl_project_full_practical1.json`, `..._compare.txt`). These remain
intermediate results: the audit and source changes continued during the broad run;
that run cannot be called a final check of the eventual delivered snapshot.

13. **Context capacity is observed and cannot silently shrink.** After startup,
    the raw resident backend refuses a known per-slot capacity below the explicit
    requested context, before publishing the engine as ready. Its existing failed
    start unwind releases the process/key. Unknown logs remain unknown rather than
    inventing capacity. Engine padding above a requested capacity is allowed: context
    is the required minimum capacity, not a promise of an exact allocation quantum.
    Shared comparisons now use this same minimum-capacity rule. New scripted-start
    tests exercise the real backend class and verify idle/no retained credential
    after refusal; no engine executable is launched.
14. **The outer loop cannot discard a lifecycle resource failure.** The Phase 9
    resident bridge formerly returned the diagnosis after logging cleanup trouble,
    allowing later profiling to start another target while the reasoner remained.
    It now always calls the existing target cleanup (including partial/dead starts)
    and raises ResidentLifecycleError if either owner remains unreleased. That
    aborts subsequent optimization; it does not invent a fallback diagnosis or save.
    Pure owner_released evidence reading is shared with the lifecycle. A failed
    target restore no longer marks queued accounting records drained or announces
    a successful resume. RequestWindow is bookkeeping for injected lifecycle
    requests, not a network request proxy or a demonstrated conversation replay
    mechanism; its design limitations remain under review.

`impl_project_full_boundary8.xml` checks the new boundaries with the existing
resident lifecycle and fresh-run suites. The first startup-boundary test run had
one assertion-shape error (empty list versus empty tuple), not a retained resource;
the corrected assertion checks emptiness without assuming the container type.

15. **Unreleased diagnostic probes are terminal for the tune.** The probe reader
    treated identity as a method although the real backend exposes a property, and
    ignored failed stop/credential evidence. Its caller then swallowed ProbeNotSafe
    and continued ordinary measurements. A diagnostic using the archived _diagnose
    catch in memory (remaining synthetic tune unchanged) reproduced **54 later
    measurements and a save**; the corrected catch re-raises the same exception,
    makes zero later measurements and saves nothing. Script/output:
    `impl_project_full_probe_transition.py`, `..._results.json`. This is an isolated
    transition diagnostic, not a full-source parity recording. The initial whole-tune
    test fixture had no selected paths/on-card start and did not invoke the probe;
    it was corrected before claiming that reproduction. The retained-credential
    direct probe reproduction independently failed on the previous implementation.
    The existing backend gets stop and cleanup even if log reading/stop is
    interrupted. Fresh release evidence and the existing identity wait must pass;
    unknown process state cannot become clean. ProbeNotSafe retains its backend
    owner, names resource problems and uses tune's existing failure-report/no-save
    route. A propagating interrupt stays the original interrupt and retains the
    owner for diagnostics; a new Ctrl+C keeps normal exception chaining. No generic
    cleanup framework, retry loop or additional engine owner was introduced.
16. **Nonfinite measurement evidence cannot establish safety.** A direct NaN paging
    reproduction passed the memory-safety resource gate. RunMetrics now rejects
    nonfinite/negative measured durations, counters and rates; model-copy/finalizer
    output is also revalidated at measurement ingestion. The resource gate separately
    refuses invalid values if a caller bypasses contract validation. Zero is valid,
    and boosted/per-core percentages above 100 are not arbitrarily capped. This is
    evidence validation, not a threshold change. The existing keep rule already
    refused the tested NaN/Infinity goal gains; no unnecessary keep-policy rewrite
    was made. `impl_project_full_numeric_before.xml` records the NaN gate failure;
    `..._numeric_after.xml` records 93 passing boundary/review-7/experiment/quality tests.
17. **Full configurations survive reporting and older interventions.** The profiling
    projection omitted reading threads and engine switches; runtime monitor reports
    also omitted batch, flash, cache, placement and device settings. Reconstructing a
    baseline from those reports could erase unrelated optimized settings. A single
    versioned full RuntimeConfiguration snapshot now lives in ProfilingConfig's
    existing `extra` string map (`runtime_request_v1`); no ProfilingConfig layout
    change or lossy field-by-field replacement is needed. The shared decoder requires
    every current field, rejects duplicates/malformed snapshots, and never falls back
    when a present snapshot is damaged. Old profiles without that key retain their
    documented legacy conversion; unavailable historical settings cannot be recovered.
    RuntimeObservation adds an optional requested_configuration snapshot captured
    with the sample. Report conversion uses that snapshot rather than relabelling an
    older observation with today's setup. Legacy/injected samples receive an explicit
    current-workload fallback label, and collection stamps only a stable matching
    setup. Profiling also retains the already-declared effective thread/mmap fields.
    Requested snapshots are not advertised as engine observations.
18. **GPU accounting counts output exactly once.** The older resource-envelope
    caller supplied the engine's offload total (blocks plus output) to a calculator
    which itself adds output. A 28-block model could therefore propose **30** counts.
    The model profile's block count is now authoritative for that calculator; its
    contract documents the units. Monitor offload estimates include output, preserve
    the exact request in the full snapshot, and explicitly label estimates as such.
    The prior code fails `impl_project_full_layer_units_before.xml`; corrected tests
    cover the envelope plus runtime/profiling round trips. No extra model layer is
    invented from a telemetry counter.
19. **Known startup contradictions cannot become measurements.** The backend now
    compares actual engine observations for layers, threads, mmap, flash and cache
    with explicit requests before publishing readiness. Automatic threads/offload
    retain their existing semantics; capacity padding is allowed, reduction refused.
    Unknown observations stay unknown. Specialized placement/cache per-run acceptance
    checks are unchanged. Broader claims that every runtime setting is proven on
    every load are still being audited; unknown batch/reading-thread/engine-activation
    evidence must not be presented as proven merely by a request snapshot.

Intermediate checks: the first broad Windows scan completed with **2,933 passed,
3 skipped, 1 deselected** (`impl_project_full_broad1.xml`, 730.752 s). Source editing
continued during that scan, so it is regression evidence rather than a final snapshot
gate. The corrected engine-probe suite plus boundary/probe tests has **143 passing**
tests (`impl_project_full_probes_after4.xml`). Configuration/monitor/envelope checks
have **118 passing** tests (`impl_project_full_config_after2.xml`); the subsequent
startup contradiction/race/adapter checks pass in `impl_project_full_effects_after.xml`.
Mypy is clean on **457 files** (`impl_project_full_mypy11.txt`).

The first new Unbounded recording used workspace/out as TEMP, outside the unchanged
comparator's documented tmp/Temp normalization. Its strict comparison exposed only
scratch-root path differences; that artifact and failing comparison are retained.
The second recording used workspace/out/tmp, recognized by the original comparator;
**328 scenarios, 323,916 events, 0 differences** against the preserved v8 reference
(`impl_project_full_unbounded2.json.gz`, `..._compare.txt`). No exclusions changed and
no reference was replaced. This recording predates later request-snapshot/probe and
metric-validation edits; another final-snapshot gate remains required.

### Open audit work after these corrections

The project-wide audit remains active. In particular, normal generation completion
markers/short-work handling, all remaining applied-setting claims, restoration and
rollback's requested-versus-observed distinctions, persistent compatibility, actual
Practical admission evidence, and the remaining source areas in the coverage ledger
are not yet signed off. A bounded greedy/revisit search does not establish a global
optimum; adding untested paths or a new scheduler is not a valid shortcut to that
claim. No model was loaded, job queued/moved, commit made or push performed.
The ongoing broad/replay checks do not yet cover every subsequent edit.

### Continued full-project audit: completion, restoration and failed measurements

20. **Native completion must be proved by the engine.** The resident generation
    path accepted a clean HTTP EOF with partial text (or a timing dictionary) as
    a complete reading, then invented a token count from whitespace-separated words.
    The pinned b11139 `server-task.cpp::server_task_result_cmpl_final::to_json_non_oaicompat`
    sends `stop: true` on completion. Only that actual boolean terminal marker now
    establishes completion; a missing count remains None. Epoch cancellation is
    checked again before returning. Per-request generation/counter state is reset
    before work so a failed request does not inherit the preceding answer. The five
    regressions fail on the preceding code (`impl_project_full_stream_before.xml`);
    resident/cancellation/reuse/correctness coverage then passes **662 tests, 1 skip**
    (`..._stream_after.xml`). This does not impose fixed output length on every
    workload or reinterpret an ordinary EOS as an error. Study work/length gates
    remain separate. Primary source checked:
    https://github.com/ggml-org/llama.cpp/blob/b11139/tools/server/server-task.cpp#L323
21. **Independent restoration uses observed settings.** Both the older experiment
    verifier and resident reasoner reload previously claimed configuration_match
    from request equality or mere liveness. A scripted engine could answer OK with
    a smaller or unobserved context and be labelled verified. Both now use the shared
    observed comparator, requiring every explicitly requested setting to be shown
    without contradiction for that strong verification claim. Unsupported evidence
    stays unverified; it may therefore prevent an older restoration from being
    certified. It is not supplied from the request or an extra measurement. Real
    generation remains required. Reload identity compares PID plus creation time,
    including a genuinely new process reusing the same PID. Failed/unverified reloads
    cannot mark queued request accounting drained or service resumed. Test fixtures
    supply explicit synthetic engine context evidence; overrides with missing/wrong
    telemetry still fail. Restoration's running field records operation during its
    probe, not a claim that its adapter remained loaded afterwards. Latency tolerance
    stays diagnostic; thresholds were not changed.
22. **A stale captured PID is not proof of orphan-free recovery.** The old helper
    returned True whenever old_pid equalled the captured target PID, even after
    failed cleanup/loss. It now allows that shortcut only for an actually loaded,
    currently healthy target owned here; otherwise it checks conservative process
    existence. The first diagnostic accidentally passed a bound target_pid method;
    its artifact is preserved. Corrected six-case restoration/PID regressions all
    fail against the preceding source (`..._restore_before2.xml`). The corrected
    restoration/recovery/resident GPU search tests pass **107 tests**
    (`..._restore_after2.xml`).
23. **Profiler failures return to existing cleanup owners.** Partial load,
    generation and telemetry failures skipped adapter unload; the three new tests
    all reproduce this (`..._profiler_before.xml`). BaselineProfiler now delegates
    failure cleanup to its existing monitor/sampler/adapter owners, with no new
    process owner. Its per-answer sampler is recorded before start/first-read and
    retained if release is unconfirmed. An unresolved backend release is a sticky
    BackendCleanupUnresolved condition: no later load, warmup retry, confirmation
    or save. Experiment measurement propagates it; both tune modes use their existing
    failure-report contracts. A successful already-completed per-answer monitor run
    keeps its previous return contract; unconfirmed cleanup blocks subsequent work.
    Practical no longer swallows terminal cleanup exceptions as ordinary missing
    screening evidence. ResidentMeasurementAdapter's intentionally inert unload is
    preserved: its workload still owns the target. Ordinary generation/load failures
    retain the same exception when cleanup succeeds. When cleanup itself fails,
    the fatal release error chains the original cause; Ctrl+C remains the original
    interrupt, with diagnostic notes and retained owners. No unbounded retry occurs.
    Seven focused cleanup/tune-mode cases pass (`..._cleanup_after.xml`); an
    intermediate broader measurement check passes **221 tests**
    (`..._measure_after2.xml`). Subsequent sampler bookkeeping still requires its
    next focused/full checks.
24. **Applied-setting descriptions are honest.** Declarations are now v4, recording
    the earlier layers->engine-switch invalidation change and narrowing effect claims.
    Known observed startup contradictions are rejected. Reading threads and batch
    launch requests are retained, but their effective values are not currently
    verified. A missing specialized verifier does not prove some universal fallback
    verifier ran. No new path or engine observation was invented to satisfy a claim.
25. **Late approval completion cannot beat a delayed waiter.** The injected approval
    helper examined only whether a result existed when join returned. If the caller
    was descheduled past the deadline, it could accept a callback completed too late.
    Completion now carries a monotonic timestamp and must precede the original
    deadline. Late values and late callback exceptions are discarded. A controlled
    delayed-join reproduction fails on the old code; the existing approval provider
    and context binding contracts are retained.
26. **Historical unknowns cannot become exact matches.** The older knowledge matcher
    treated non-overlapping or NaN conditions as MATCH, ignored unknown dimensions
    when claiming DIRECTLY_APPLICABLE, and could accept a future date (or raise on a
    naive one). Conditions now require comparable finite nonnegative observations;
    zero-to-nonzero resource change is a difference. Unknown identity/conditions or
    invalid/future dates downgrade relevance rather than claim an exact match. The
    descriptive weighting and existing policy tolerances stay unchanged, and history
    still cannot establish acceptance. Five new approval/history regressions fail
    against preceding code (`..._history_before.xml`); current validation is running.

This continuation remains an **in-progress whole-project audit**. In particular,
rollback's separate verification route, remaining history consumers, interrupted
sampler cleanup, full path dependency/revisit coverage (including batch/flash memory
effects), and final source-stable replay/broad-suite gates remain open. A bounded
search can miss jointly beneficial combinations; these changes do not establish a
global optimum or evidence-based admission of additional Practical paths. No model
or hardware study was run; no Git or queue mutation occurred.

27. **Rollback protects the entire live setup and verifies the engine.** Its
    applicability checked only the original changed field, although its executor
    reloads a complete saved configuration. That could erase a later thread setting.
    Matching now covers the complete prior/resulting snapshot; an explicitly
    supplied stale context is rejected against current live requested settings.
    Incompatible model/backend/host and invalid/future age checks precede the
    already-restored classification. An idle target with old request objects is
    not reported already restored. Strong configuration-restored/recovery claims
    require engine observations, while actual_configuration reports those
    observations rather than echoing the request. The existing adapter unload
    happens even when the engine is no longer loaded; retained resource evidence
    prevents a new rollback load. A successful applied rollback also requires a
    new PID/creation-time identity, not just text plus requested settings. Missing
    observations fail verification; no invented evidence or changed measurement
    tolerance compensates for them. Test fixtures now explicitly simulate observed
    context/layers/mmap. Four regressions fail before this repair
    (`impl_project_full_rollback_before.xml`); a fifth stale-context reproduction is
    preserved separately (`..._rollback_stale_before.xml`). This is the existing
    single-owner rollback execution route, not a new concurrent control service;
    cross-thread ownership/serialization continues to be audited.

28. **Runtime approval binds the live context and expiry at dispatch.** Matching
    only the approval record to an old proposal accepted a changed live setup and
    an expired proposal. The ignored scripted probes record both as True before
    correction (`impl_project_full_runtime_pending_before.json`). The monitor now
    compares the proposal with its current workload/configuration/baseline identity,
    refuses missing-timezone or elapsed expiry, and repeats that guard immediately
    before intervention dispatch, including policy-permitted non-disruptive work.
    No checkpoint, pause or application follows a stale approval. The existing
    timeout provider and proposal IDs remain in control; no new approval UI exists.
29. **False checkpoint restoration is terminal.** Both GPU pre-search and intervention
    flows ignored restore_runtime_checkpoint's False return. A scripted quality
    regression with failed restoration still called resume and ended cleanly at its
    duration bound. It now stays unresumed, records failure and ends as a safety
    termination. The attached workload keeps its existing owner; this is not an
    instruction to kill an external service. Three initial monitor regressions
    fail before correction (`..._monitor_before.xml`); current monitor/approval/GPU
    search boundary coverage passes **160 tests** (`..._monitor_after2.xml`). A
    separate regression covers the GPU-search restore branch.
30. **Missing identity evidence is not identity verification.** Bounded resident
    recovery counted a verifier's None as verified so long as it did not return
    False. It now requires an actual True confirmation. Unsupported identity
    verification cannot certify a replacement and therefore fails recovery safely.
    The scripted unknown-verifier reproduction fails on the preceding source
    (`..._identity_before.xml`). Ordinary healthy attachment semantics are unchanged.
31. **Unresolved samplers stop at the measurement boundary.** Further inspection
    amended decision 23's intermediate compatibility choice: returning a completed
    reading while its sampler was unconfirmed could permit a later independent
    diagnostic probe before the next profiler entry. The completed answer is not
    cut short, but run_once now raises at its cleanup boundary. Experiment
    measurement propagates both monitor and backend cleanup exceptions instead of
    treating either as ordinary missing evidence eligible for retry. The existing
    per-answer sampler regression now requires this stronger immediate stop, plus
    the existing one-answer/no-new-sampler assertions. Retained sampler ownership
    and the user's interrupt behavior remain as described above.
32. **Reference data also needs numeric validation.** Candidate paging was checked
    for finite values, but a NaN baseline median could disable its comparison and
    hide a finite paging regression. Invalid/missing reference readings now refuse
    that resource proof. Booleans are refused before Pydantic can turn them into
    numeric counts/rates/durations. Four new tests reproduce both defects on the
    preceding code (`..._numeric2_before.xml`). The same finite/nonnegative and
    existing paging tolerance rules apply; no threshold was relaxed or tightened.

The known-negative runtime knowledge fixture previously supplied no conditions while
asserting direct applicability. It now supplies explicit synthetic matching pressure
and available-memory values to keep testing legitimate direct rejection. Missing
conditions remain conditional/deprioritized, as tested separately; that is not a
reason to weaken the new history guard.

Intermediate validation: history/approval checks pass **116 tests, 1 skip**
(`..._history_after.xml`), rollback/knowledge checks pass **127 tests, 1 skip**
(`..._rollback_after.xml`), and the expanded boundary check passes **198 tests,
1 skip** (`..._boundary11.xml`). Mypy is clean on **457 files** through
`impl_project_full_mypy19.txt`; later numeric changes still require rechecking.
The second Practical replay has **231/231 identical** results
(`impl_project_full_practical2.json`, `..._compare.txt`); the third Unbounded
recording has **328 scenarios, 323,916 events, 0 differences** against the preserved
v8 reference (`impl_project_full_unbounded3.json.gz`, `..._compare.txt`). The original
comparators and exclusions are unchanged. These recordings began before the latest
monitor/identity/numeric corrections; they are not labelled the final snapshot gate.

The broad second Windows scan is still running and has exposed failures that must
be classified. Its 511-file input hashes are preserved in
`impl_project_full_verification2_inputs.json` (SHA-256
`1efb30cfff50047235e3491f8d86fb3949bc28cafa5ab234fdd1d53ed9ad9d1f`). Editing continued
after that snapshot, so it is intermediate regression evidence. No previous failed
log, reference recording or source archive was overwritten.

33. **Fixed-length native requests need the requested amount of work.** A terminal
    stop marker alone could still describe a shorter request. For ignore_eos requests
    with a positive length and no explicit stop strings, the resident backend now
    requires the engine's written-token count to equal the requested length. Unknown,
    short and excessive counts cannot produce a successful fixed-work measurement.
    Ordinary EOS-terminated requests and explicit stop-string requests keep their
    semantics. Three cases fail before correction (`..._fixed_before.xml`); current
    resident/reuse boundary checks pass **252 tests, 1 skip** (`..._fixed_after.xml`).
    This also strengthens the study's transport/engine boundary. Final study-version
    compatibility review must document any newly terminal protocol error before
    declaring job 128 ready; no hardware was run under these changes.
34. **The older CLI backend also needs real failure/cleanup handling.** run_cli
    stopped its memory observer but could leave its child alive when communicate
    raised KeyboardInterrupt or a pipe error. It now invokes the existing process-tree
    helper, kills/reaps its owned root with bounded communication, retains an
    unreleased process on the terminal error, and preserves a successful cleanup's
    original interruption/error. Timeout cleanup is bounded too. Observer startup
    is inside the ownership boundary and Windows launch hides its console. The CLI
    adapter refuses nonzero engine exit codes instead of constructing a successful
    GenerationResult from partial output; it clears prior per-attempt run evidence.
    Four cleanup/exit tests include a real owned **Python sleeper**, never a model
    (`..._cli_after2.xml`). The first nonzero-exit test omitted _timeout_s, so its
    failure was a fixture error; preserved logs are not claimed as that reproduction.
    The corrected archived/current-method diagnostic is
    `impl_project_full_cli_exit_probe.py` / `...probe.r2.json`: old code returns a
    GenerationResult for exit 1, current code refuses. Its initial JSON used the
    wrong mocked globals and is retained as a failed diagnostic. CLI descendant
    containment remains best-effort through the existing tree helper; this is not
    a claim that arbitrary detached descendants or an interrupted OS spawn are
    atomically contained.
35. **Complete requested setups must reach the CLI too.** The prior report/snapshot
    repair exposed another drop: the CLI adapter ignored reading threads, explicit
    engine switches and the request's ignore_eos value. Those now reach -tb, the
    existing managed process-environment builder, and --ignore-eos respectively.
    Inherited conflicting managed switches remain removed. Unsupported per-request
    stop strings/token probabilities raise an explicit unsupported error rather than
    silently claiming support. Logs omit prompt/schema bodies while the actual
    execution/provenance command retains them. A cross-adapter regression fails on
    preceding code (`..._cli_config_before.xml`); the command/environment/log test
    checks that real launch arguments contain the request while logs do not.
36. **CLI timing counters were being parsed as server logs.** Static inspection of
    the installed DLL (no binary/model execution) confirms llama_perf_context_print
    labels, load-time counters, and decode counts expressed as **runs**. The parser
    accepted only print_timing and counted only tokens, dropping real CLI metrics.
    Binary hashes and exact format strings are retained in
    `impl_project_full_cli_timing_formats.json`; the synthetic numeric regression
    fails before correction (`..._cli_timing_before.xml`). Parsing now supports the
    actual dialect and stderr timing fallback. Decode evaluations have their own
    field and are not silently relabelled written tokens. Printed CLI load duration
    is used when no logged startup interval exists. Actual TTFT cannot be derived
    from an average decode step: it stays unknown; the old arithmetic survives only
    as explicitly named ttft_estimate_s and is not exported as measured TTFT. The
    native resident backend still measures TTFT from streaming. No fabricated +1
    token adjustment, model run or new timing threshold was introduced. Network
    attempts to fetch the pinned CLI/context source failed; static binary evidence
    supports the format correction, not an unverified reconstruction of its algorithm.
37. **Cleanup errors are terminal control conditions.** Adversarially following the
    newly introduced BackendCleanupUnresolved through optional evidence handlers
    exposed a design mistake: as a RuntimeError it could be swallowed by generic
    candidate/diagnosis fallbacks. It now deliberately inherits BaseException, like
    the already-existing MonitorCleanupUnresolved, Cancelled and Abandoned controls.
    Lifecycle/report owners catch it explicitly; ordinary failed-run retries do not.
    Correction to decisions 23/31: the existing monitor exception already bypassed
    except Exception; it was not newly fixed by adding an explicit catch tuple.
    Backend cleanup was the newly exposed ordinary-exception problem. This choice
    avoids duplicating special-case checks in every optional evidence consumer.
38. **Scoped monitor startup/close keeps ownership until release.** The scoped
    monitor previously marked itself opened only after start/readiness, then skipped
    stop if interrupted in between. Its owner could also disappear from the profiler
    before close returned. A start-attempt flag is now set before resource creation;
    partial starts are stopped, a never-started monitor records that no owner existed,
    failed/unconfirmed closes retain the monitor and can retry bounded cleanup, and
    opening one monitor twice is refused. Raw-counter reader join failures become
    explicit unresolved evidence; a not-yet-started reader is not joined illegally.
    Fresh-start hooks and measurement-scope closure check terminal cleanup before any
    later work. Measurement-close failure no longer hands back an acceptance reading;
    Ctrl+C stays the original interrupt with notes. The archived/current complete
    class diagnostic (`impl_project_full_scoped_probe.py`, `...probe.json`) shows
    **old: 0 stop calls, resource held; new: 1 stop call, resource released**.
    Two initial new tests had fixture errors (missing answers, missing keyword kwargs);
    their logs are retained and are not claimed as independent defect reproductions.
    The existing Practical/report regressions now require zero extra refused attempts
    after discovering cleanup failure at close, with no save and the same failure
    report/cleanup owners.

Second broad scan: **2,980 passed, 6 failed, 3 skipped, 1 deselected**
(`impl_project_full_broad2.xml`, 733.198 s). Each failure was inspected: three old
28-block/output assertions omitted the output step, one test expected contradictory
mmap startup to succeed, one probe double supplied no release evidence, and one
known-negative fixture supplied no conditions while expecting direct applicability.
The fixtures now assert 29 engine counts, preserve but refuse contradictory startup
evidence, track the probe double's running/stop state, and supply explicit matching
synthetic conditions respectively. The mmap double no longer claims pytest's own
PID as an engine it owns. **63 focused checks pass**
(`..._broad2_fixes.xml`). This is classification of actual changed contracts, not
an exclusion or reference refresh. Further scoped/CLI fixes followed that scan, so
another final broad gate remains necessary. Mypy is clean on **457 files** through
`..._mypy27.txt`; the newest focused run is still running.

39. **Protocol refusal must not conceal study validity evidence.** Native fixed-work
    requests now require the exact reported written-token count, but an incomplete
    or short response can still expose forbidden reuse. ResidentGenerationProtocolError
    carries the actual partial GenerationResult; it never becomes last_generation or
    a successful tune measurement. RealReuseEngine alone extracts those partial
    counters for the evaluation. work_evidence makes the reading unusable via its
    explicit protocol_problem, while prompt_counts still allows the unchanged E1/E4
    gates to stop immediately. This avoids hiding invalidity behind an ordinary
    failed-request record. No estimated counters, new measurements or acceptance
    retries were added. Two backend-to-study regressions pass
    (`impl_project_full_protocol_gates.xml`); the wider protocol gate has **668 passed,
    1 skipped** (`..._protocol_after.xml`). This does not amend the frozen v8 study:
    incomplete work remains unusable and its existing validity gates remain active.
40. **GGUF parsing preserves valid nesting and refuses malformed scalar evidence.**
    The official ggml GGUF description permits nested arrays, requires Boolean
    encodings 0/1, and uses UTF-8 strings. Nested discarded arrays now use an explicit
    stack rather than Python recursion: a valid depth-2000 array remains supported.
    Invalid Boolean bytes and UTF-8 are errors instead of plausible normalized data.
    Repeated metadata keys are refused as ambiguous, an explicit reader policy (not
    an asserted uniqueness requirement from the specification). File bounds and
    seek-based skipping remain. Four regressions fail before correction, and **131
    checks pass** after (`..._gguf2_before.xml`, `..._gguf2_after.xml`). This is not a
    full tensor-payload validator, nor a new arbitrary maximum valid nesting depth.
    Source: https://raw.githubusercontent.com/ggml-org/ggml/master/docs/gguf.md.
41. **Metadata, measured model and saved identity must refer to one file generation.**
    Tuner accepted a ModelProfile for one path and a separate model_path for another;
    the first could be measured while the second authorized persistence. Both tune
    entry routes now refuse that mismatch before any measurement. The loader records
    a cheap source signature around metadata reading and attaches it to the profile;
    tune checks that stamp at entry. This catches an ordinary change between parsing
    and tuning, as well as a change during parsing. The one signature implementation
    lives in models/identity.py and is re-exported by tune/profiles.py for compatibility.
    It reads stat information, not the model contents; no hashing/warming is inserted
    before a timing run. Existing save-time hashing guards still apply. The common
    test fixture was corrected to bind its synthetic profile to its actual file,
    rather than weakening the guard for simulations. **220 checks pass** after the
    first binding correction (`..._binding_after.xml`). The first metadata-change
    regression had incomplete metadata and demonstrated only a different error;
    it was repaired to use an otherwise valid minimal model and is not claimed as
    evidence that the first fixture could previously load. The later stale-profile
    regression exercises an actual successfully parsed profile. Old recordings and
    any mismatch remain retained; no comparator exclusions were widened.
42. **Dimensions are facts, not coercible hints.** Architecture normalization could
    turn Boolean/fractional dimensions into integers, infer MHA from a malformed
    present KV-head value, and pick an ambiguous suffix by dictionary order. Present
    dimensions must now be positive scalar integers; absent KV heads still get the
    existing MHA default. Unsupported array-valued dimensions remain explicitly
    unsupported, not silently flattened. Ambiguous suffix lookup fails, and deriving
    a head size from non-divisible embedding/head counts requires explicit key length.
    ModelMetadataError gives the loader caller a stable failure rather than leaking
    arithmetic conversion errors. The regression population has **10 failures / 1
    pass** before (`..._arch_before.xml`): negative dimensions already raised another
    validation error, so those cases are error-contract improvements, not a claim
    that negative profiles previously loaded. **151 checks pass** after
    (`..._arch_after.xml`). No architecture-specific numbers or guessed head counts
    were introduced.
43. **A rollback checkpoint cannot authorize overwriting a new target.** Actual
    generation during the checkpoint can overlap a settings change or replacement
    target. Both injected cases previously returned APPLIED_VERIFIED after erasing
    that newer state (`..._rollback2_before.xml`: 2 failures). The executor snapshots
    the process identity and rechecks the full runtime, PID and identity after the
    probe, before its first unload. A mismatch is rejected through the existing
    inapplicable-result/event route with no rollback or checkpoint recovery. The
    newer target is left running. **156 boundary checks pass**
    (`..._boundary_final.xml`). This narrows the exposed checkpoint window; it is not
    a cross-process transaction lock. Controllers still need exclusive control of
    one target while applying a change.

### Design limits and validation boundaries after the wider sweep

- The eight executable tune paths remain layers, threads, reading_threads,
  prompt_batch, flash_attention, engine_switches, placement and kv_cache. Practical
  still dispatches only its layer-count, thread and batch categories. Its `placement`
  category is not the per-piece placement path. Prompt reuse and correctness remain
  development evaluations; lookup decoding, OS changes and new Practical admission
  are not implemented by this audit.
- The shared coordinator is dispatch and trace, not a global optimizer. Each policy
  keeps its own ordering, queue, counters and evidence owners. Captured comparison
  bases and whole-setup selection avoid adding isolated gains together. Bounded
  greedy passes can still miss jointly beneficial combinations when neither isolated
  change wins. Revisit caps can leave an already tested path unvisited on a later
  configuration. Layer-memory revisits currently trigger on KV/per-piece placement,
  not every workspace-affecting batch/attention option. Marking every path as memory
  shaping without evidence could spend the limited revisits before more useful
  changes; this audit does not invent such a scheduling policy. No global-best or
  general 95%-retention claim is warranted.
- Practical path selection should be designed from controlled development studies
  for the model/hardware family, as the owner requested. Existing historical cost
  forecasts and candidate hints are not that study and do not independently validate
  quality or an accepted gain. The current three-category boundary is retained.
- Observed settings are distinguished from requests. Known startup contradictions
  stop measurement; missing effective batch/reading-thread observations are still
  unknown. A full serialized configuration is not proof that the engine applied it.
  Context read from a request is never reused as independent restoration proof.
- Quality coverage is stronger after the per-answer fixes, but generic lexical and
  length checks are not a semantic correctness oracle. Statistical confidence also
  depends on sampling/noise assumptions; repeated blocks do not prove a universal
  performance guarantee.
- Reasoner RequestWindow records hashes and accounting; marking those records drained
  does not implement a network request queue/replay service. The resident runtime's
  own pause/drain is a separate real in-flight request boundary. CLI interruption
  cleanup is bounded and tested on an owned Python child; arbitrary detached
  descendant containment and interruption inside OS process creation are not newly
  proven by those tests.
- Coverage means inspection of the inventoried subsystems and their critical
  contracts/call routes, with focused and integration regressions. It is not a claim
  that every line of all 77,999 inventoried lines was independently reviewed. There
  is no independent reviewer signoff or new hardware validation from this work.

The third broad Windows scan uses an exclusive input manifest,
`impl_project_full_validation3_inputs.json`: **508 Python files**, SHA-256
`5cc2112e11322cd9b4f59e4da4c1854c87cc8a91cf37da89789b3b5624f3ed66`.
Python source/tests/scripts are held unchanged during that scan; handoff documentation
can be updated separately. Mypy is clean on **458 source/test files**
(`..._mypy33.txt`). Including both evaluation/reanalysis scripts exposed seven old
type errors in their imported simulate_confirmation.py, retained in
`..._mypy32.txt`. Explicit subclass/result annotations correct those types without
changing simulator operations; **460 files pass** (`..._mypy34.txt`). The full-precision
Practical replay still reports **231/231 identical** (`..._practical3_compare.txt`),
without new allow flags. The broad scan and Unbounded replay are still running at
this update; neither is claimed to have passed yet.

44. **GPU capacity and usage need the same device attribution.** A scripted two-card
    inventory (4 GiB and an unrelated 16 GiB device) produced a 16 GiB planning total
    and 14 GiB free from the other card's 2 GiB usage, without selected-device identity.
    This is arithmetic/provenance evidence, not a hardware OOM reproduction. The
    before/after probe and JSON are `impl_project_full_gpu_attribution_probe.py` and
    `..._before.json` / `..._after.json`. A new pure planning_vram_bytes helper returns
    unknown for ambiguous multiple-device inventories. Raw largest-device inventory
    and card-presence reporting remain available separately. Tune, older GPU search
    and diagnosis use the conservative planning helper; live usage and resource
    envelopes no longer merge multiple unrelated adapter rows into one scalar.
    Invalid usage also remains unknown. No device is silently chosen or new GPU
    probe added. The explicit limitation is that heterogeneous/multiple-card memory
    fit is unavailable until real selected-device binding is implemented. That may
    reduce heuristic candidates on multi-adapter machines; inventing capacity would
    be worse. Single-card behavior is retained and tested by the existing suite.
45. **Contradictory token counts and observed reuse cannot authorize a fresh tune
    measurement.** The native backend preferred timings.predicted_n even when a
    simultaneously reported tokens_predicted disagreed; Boolean counts could also
    be coerced into ordinary numbers. Counts now remain independent evidence and
    present malformed/negative or contradictory values produce a protocol refusal.
    A response explicitly reporting cache_n > 0 while cache_prompt=False is also
    unusable as fresh work. The same partial-result exception preserves its raw
    counters for evaluation E1/E4; no failed work becomes a tune reading. Missing
    cache counters remain unknown, not a claimed measured zero. This deliberately
    advances the earlier P10 deferral: job127 is complete, and regardless of why an
    engine might restore cached work, observed reused work cannot satisfy a request
    for a fresh timing. It does not retroactively certify history or claim the engine
    can never reuse. It adds no probes or measurements and changes no gain/quality
    threshold. Pinned final-response fields are documented in b11139
    `tools/server/server-task.cpp` (tokens_predicted comes from n_decoded; stop:true
    marks the final native response). Five new regressions for decisions 44/45 all
    fail on the immediately preceding code (`..._last_before.xml`). The expanded
    353-case check has **351 passed, 1 failed, 1 skipped**: its one failure was an
    earlier audit double missing SystemState's gpu_memory attribute, now explicitly
    [] for that single-device output-count test. The repaired audit file has
    **139 passed** (`..._last_after2.xml`). The original failing log is retained.

### Third scan result and strict replay fixture correction

The third Windows scan finished with **3,031 passed, 3 skipped, 1 deselected**
(`impl_project_full_broad3.xml`, 744.534 s). A post-run check verifies all 508 Python
input hashes remained unchanged for the whole scan
(`impl_project_full_validation3_unchanged.json`). Decisions 44/45 followed this scan,
so a fourth scan now checks the final Python snapshot, recorded in
`impl_project_full_validation4_inputs.json` (508 files; SHA-256
`7b65aa894b92a708b55c123a31483eb01fbfe68afeecc2cc2e9f11920449f0e8`).

The Unbounded run against the original v8 recording correctly reports **328/328
different** (`impl_project_full_unbounded4_compare.txt`), with printed differences in
model-profile paths. The old common fixture identified `models/sample.gguf` while
measuring a different absolute scratch file; decision 41 now requires those to agree.
The comparator prints limited diagnostics, so inspecting those printed lines alone
is not sufficient to claim they are the only differences. Instead of adding any
exclusion, a preserved entry-source reference was reconstructed and given **only
the same fixture path binding** as the current tree. Product reference source,
scenario identities, seeds, operation recording and normalization are untouched.
The extraction script `impl_project_full_bound_reference.py` verifies the original
archive SHA-256, validates every destination stays within the newly created ignored
directory, refuses existing outputs, and records the exact fixture text and hashes
in `impl_project_full_bound_baseline.json`. It never checks out over the workspace.
The ordinary strict comparison of that fresh before recording and delivered after
recording passes **328 scenarios, 323,916 events, zero differences**
(`impl_project_full_unbounded_bound_compare.txt`). This is a controlled input repair,
not a refreshed product reference that discarded a behavioral mismatch. Both the
original mismatch and every old recording remain. Final-source replays are running
again after decisions 44/45; they are not yet claimed to have passed at this update.

The third-scan and later focused evidence are cumulative software checks, not additional
hardware evidence. Job128 is still in later. There was no commit, push or job dispatch.

### Cross-system ownership and implementation rationale

| Owner | Authoritative state / responsibility | Boundary retained by this audit |
| --- | --- | --- |
| Cards, declarations and registered handlers | Supported surfaces, parameter schemas, applicability and invalidation facts | No commands or OS actions are constructed from model suggestions; actual specialized path checks remain authoritative |
| Shared coordinator | Dispatch and detached action/error trace | No second editable queue, cost budget, cache, choice or measurement store |
| UnboundedPolicy | Carried setup, work queue, tested/finished sets, diagnosis and revisit limits | Keeps Unbounded ordering and bounded revisits; layer changes now invalidate completed switch checks |
| Planner / PracticalPolicy | Planner owns category choices, queue/context and revisit rules; policy owns traversal/termination | Each step's candidates share its captured base; temporary exhaustion is not completion |
| BudgetedTune | Existing measurement cache/history, weak-repeat state, watchdog, costs, completion and final selection | No extra trace measurements; final choice comes from whole setups, including earlier complete ones; a screened choice is not a confirmed gain |
| ResidentActiveWorkload and its backend | Target lifetime and runtime configuration; backend owns its actual process and credential | Measurement adapter unload remains intentionally inert; the outer resident owner releases/reloads the target |
| BaselineProfiler / measurement scopes | Per-answer sampler and scoped monitor lifetime, returned observations | Ownership is recorded before resource creation and retained until cleanup is confirmed; unresolved cleanup cannot return a usable reading |
| Native/CLI backend adapters | Actually issued commands and independently reported settings/counters | Requested settings do not become observed settings; CLI eval runs and a TTFT estimate do not become written-token/actual TTFT measurements |
| Runtime monitor / rollback / reasoner lifecycle | Existing approval, pause/checkpoint, restore/reload and temporary-owner transitions | No resume or new load after failed release/restore; unknown settings/identity cannot certify restoration; stale approval/context cannot authorize changes |
| SetupStore | Exact document update and one guarded atomic publication point | Measured file generation must survive publication; existing process/thread guard still defines cancellation before/after commit |
| History/knowledge stores | Append-only provenance, compatible advisory costs, conditional applicability | No historic throughput or remembered gain substitutes for current measurement, quality or confirmation |
| Development evaluator | One retained backend owner, checkpointed readings and pre-registered analysis | Partial protocol evidence remains available for validity gates; unusable work cannot be counted as a speed gain; no tune-path activation |

These changes strengthen the existing boundaries rather than creating another
controller or persistence layer. Pure release/observation/signature/planning helpers
centralize facts only; they never acquire cleanup ownership or make search decisions.
Optional observations remain unknown when absent. This choice avoids both silently
inventing evidence and breaking older serialized records merely to add a new claim.

An additional archived-function reproduction closes decision 41's initial fixture
limitation: `impl_project_full_model_profile_generation.py` uses an otherwise valid
minimal GGUF and the actual archived loader function. The old function accepts
28-layer metadata after the file has become unrelated 36-byte content; the current
function refuses the same mutation. Both outcomes are preserved in
`impl_project_full_profile_generation.json`. No real model is involved.

### Reproduction commands for the final software gates

Run from the repository root in PowerShell. Use new artifact/basetemp names when
repeating so earlier results remain. The environment overrides are local to that
PowerShell process; they change neither project settings nor saved setups.

```powershell
$env:PSExecutionPolicyPreference = 'Bypass'
$env:TEMP = Join-Path (Get-Location) '_jobs\out\tmp'
$env:TMP = $env:TEMP
.venv\Scripts\python.exe -B -m pytest tests --ignore=tests/test_model_integration.py --ignore=tests/test_profiling_integration.py --ignore=tests/test_reasoning_integration.py --deselect=tests/test_experiment_integration.py::test_real_candidate_applies_to_real_backend --basetemp=_jobs/out/impl_project_full_broad4_tmp --junitxml=_jobs/out/impl_project_full_broad4.xml -q
.venv\Scripts\python.exe -B -m mypy --platform win32 src tests scripts/evaluate_prompt_reuse.py scripts/reanalyse_prompt_reuse.py
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py record . _jobs/out/impl_project_full_practical4.json
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py compare _jobs/out/impl_job128_v8_final_practical.json _jobs/out/impl_project_full_practical4.json
.venv\Scripts\python.exe -B _jobs/out/impl_project_full_bound_reference.py
.venv\Scripts\python.exe -B scripts/unbounded_reference.py record _jobs/out/impl_project_full_bound_baseline _jobs/out/impl_project_full_unbounded_bound_before.json.gz
.venv\Scripts\python.exe -B scripts/unbounded_reference.py record . _jobs/out/impl_project_full_unbounded5.json.gz
.venv\Scripts\python.exe -B scripts/unbounded_reference.py compare _jobs/out/impl_project_full_unbounded_bound_before.json.gz _jobs/out/impl_project_full_unbounded5.json.gz
.venv\Scripts\python.exe -B scripts/evaluate_prompt_reuse.py --simulate --study correctness --swa-full-variant --chat-exposure --blocks 3 --preregistration _jobs/later/128_rules_reuse-correctness-8.txt --preregistration-sha256 4a80891cb9f607da6d341f27d0da090148292a199d389d4101b6038b8e293734 --out _jobs/out/impl_project_full_correctness_sim2.json
.venv\Scripts\python.exe -B _jobs/out/impl_project_full_gpu_attribution_probe.py NEW_OUTPUT.json
.venv\Scripts\python.exe -B _jobs/out/impl_project_full_model_profile_generation.py
```

The two one-off setup/reproduction scripts deliberately refuse already-existing
scratch/output paths. Their preserved outputs can be inspected directly; make a
newly named copy of a diagnostic when rerunning it, preserving its source and the
specific renamed paths. Do not alter a reference population or comparator to force
a pass. The simulated replay population is exactly **231 Practical / 328 Unbounded**;
new protocol/lifecycle/invalid-input regressions are additional focused/broad evidence,
not an inflated replay count. No cross-platform numeric tolerance or new allow flag
is used. Test-driven historical recordings beyond these 328 scenarios were not
re-recorded as part of this final gate.

`impl_project_full_finish.py` refuses to package a review unless the final broad XML,
strict parity logs, type check, frozen-rule simulation and unchanged Python input
hashes all pass. It writes an entry-archive diff, a full HEAD diff (which also includes
adopted earlier work), a source snapshot and one JSON manifest with source/artifact
hashes. It performs only read-only Git commands. Those outputs do not replace this
handoff or any original report/result. A passing package is software evidence, not
independent acceptance or authorization to run job128.

### Final software results and delivery (18 Oct 2026)

The final source snapshot passes the broad Windows suite: **3,036 passed, 3 skipped,
1 deselected** (`impl_project_full_broad4.xml`, 708.008 s). All **508 Python input
hashes** match the snapshot taken before this scan. Model/profiling/reasoning hardware
integrations and the explicitly named real-candidate experiment remain excluded;
the modified profiling integration assertion was therefore not hardware-validated.
Windows job-wrapper cases run inside the broad suite with their test doubles, not
with real model loads. The **139** whole-project boundary regressions are included
in that broad total; they are not additional independent passes to add to it.

- Mypy: **460 files clean**, including both evaluation/reanalysis scripts and their
  simulator import (`impl_project_full_mypy36.txt`).
- Practical: **231/231 identical**, original v8 same-platform reference and documented
  existing volatile locations only (`impl_project_full_practical4_compare.txt`).
- Unbounded: **328 scenarios / 323,916 events / zero differences**, freshly recorded
  archived entry source and final delivered source with the identical fixture path
  repair described above (`impl_project_full_unbounded5_compare.txt`). The old v8
  mismatch, both corrected recordings and the before-source repair manifest remain.
- Correctness simulation: status **done**, **108 native trials / 18 chat blocks
  (54 chat loads)**, frozen v8 rule SHA-256 unchanged. Simulation faults/findings are
  invented software inputs and have no hardware/performance meaning.
- The four original job127 files still have their original bytes/checksums; current
  reanalysis matches the prior e7-status-3 summaries with no duplicate loads and no
  non-E7 differences (`impl_project_full_job127_check.json`).
- The final measurement-close diagnostic checks completed work, an original ordinary
  error and Ctrl+C (`impl_project_full_terminal_error_probe.py/.json`). Unresolved
  cleanup raises the terminal monitor control for the first two, with the ordinary
  error retained as cause; the exact KeyboardInterrupt object survives with a cleanup
  note. Each closes once and returns no usable reading. No source change was needed.

Review artifacts (all ignored, originals retained):

- `_jobs/out/impl_project_full_audit_diff.r2.patch`: this wider audit's diff against the
  archived entry source, including added modules/tests and this maintained handoff.
- `_jobs/out/impl_project_full_workspace_head.r2.patch`: full uncommitted diff against
  owner HEAD `cd56c46`, including the earlier adopted v8 work; it includes new files.
- `_jobs/out/impl_project_full_review_source.r2.zip`: current changed source/tests/docs,
  the single handoff, prepared job128 wrapper and frozen governing rules.
- `_jobs/out/impl_project_full_final_checks.r2.json`: source hashes, handoff hash, actual
  test counts, strict replay population/fixture qualification, all available whole-audit
  diagnostic/artifact hashes, source package hashes and exact entry changes. The
  packaging script verifies Git whitespace checks as well as the gates above.

Packaging self-check: the first manifest included its redirected console-output file
before that file finished writing. Its hash check correctly detected that one mismatch;
the first manifest/diff/package are retained as an initial attempt. The `.r2` package
excludes that mutable own-output log and is independently checked after writing. This
is a packaging correction, not a changed source gate, reference population or result.

Disposition: the confirmed defects recorded here are repaired and the listed software
gates pass. The bounded-search, unobserved-setting, multi-device attribution, semantic
quality and single-controller limits above remain explicit design constraints. This is
not a claim that every possible defect has been found or that all inventoried lines
were independently reviewed. Review this sizeable patch and its rationale before
approving job128 or starting another capability. No model was loaded, no hardware
evaluation was run/queued, no saved owner setup was changed, and no commit/push or
Git history change occurred. The same handoff remains the sole maintained record.

### Follow-up audit: cross-API GPU attribution (18 Oct 2026)

46. **CPU execution is not GPU-device evidence; a short OS inventory cannot override
    contradictory backend evidence.** Decision 44's first implementation grouped CPU
    availability with GPU APIs. Without OS GPU rows it could turn a valid single-GPU
    capacity into unknown merely because CPU execution was available. With one OS
    GPU row it skipped the cross-API conflict check entirely: Vulkan's 4 GiB device
    and CUDA's unrelated 16 GiB device became a 16 GiB planning capacity. Software
    Vulkan CPU renderers could also be counted as another GPU or provide CPU memory
    as VRAM. The planning helper now excludes CPU backends and CPU devices from both
    API and OS attribution, checks conflicts regardless of OS row count, and takes
    its capacity only from that filtered evidence. The raw inventory helper remains
    unchanged. Tune's machine check and legacy search still call the same pure
    planning helper; no second scheduler, probe or selected-device setting is added.

    Multiple GPU devices within an API and multiple OS GPU rows remain ambiguous.
    Repeated single-device API reports are combined only when names agree after
    case/whitespace normalization and capacities agree. No fuzzy-name, PCI-substring
    or largest-card guess is introduced. Legitimate API name aliases or incomplete
    cross-API capacity evidence may therefore remain unknown; reliable physical
    device binding is still future work. This is deliberate conservative loss of
    planning evidence, not proof of engine device selection.

    Eight GPU cases cover CPU availability, matching API reports, conflicting API
    reports with/without OS inventory, CPU-only memory, a software renderer beside
    a real GPU, and two devices within one API. A ninth regression checks the actual
    search capacity and tune machine-check consumers. Before the source fix, the
    corrected regression selection reports **6 failed / 12 passed**
    (`impl_project_followup_gpu_before2.xml`); the first attempt is also retained
    and includes a test-fixture error from assigning a frozen model field. After
    the fix, GPU plus the whole-project boundary file report **157 passed**
    (`impl_project_followup_gpu_after.xml`), including **140** audit-file tests.
    Mypy remains clean on **460 files** (`impl_project_followup_mypy1.txt`).

The earlier broad suite skipped two symbolic-link tests because this Windows account
cannot create those links. An additional diagnostic uses **actual Windows directory
junctions** under a new ignored scratch directory, avoiding that privilege requirement.
The evaluator refuses a results path redirected into its scratch data folder with
exit 4 and zero engine starts. Report storage refuses a write through a junction
outside the owned report root; retention deletes zero files and the external scratch
sentinel retains its SHA-256. `impl_project_followup_junction_probe.py/.json` preserve
the reproducible checks. This is additional coverage of directory junctions, not a
claim that the skipped file-symlink or POSIX-terminal tests ran. No product change was
needed for those guards; no owner data folder or saved setup was used.

The follow-up Python snapshot contains **508 files**, recorded before its broad scan
in `impl_project_followup_validation_inputs.json` (SHA-256
`fc2893863b32b8ce281b345ba13c46a2df476ac02277ecc6465ded5841f80141`).
The previous `.r2` package and its hashes are preserved as the exact earlier snapshot.
The new broad scan and strict Practical/Unbounded recordings are in progress; their
results are not yet claimed here. This section will be updated in this same handoff
after those checks finish. No commit, push, queue move or model load occurred.

47. **Path eligibility needs executable GPU evidence, not a memory-size proxy.**
    Following MachineFacts into both modes exposed another use of raw inventory:
    card_usable equated nonempty memory capacity with a usable graphics card.
    A CPU-based Vulkan renderer with a reported 32 GiB heap therefore produced
    processor_share=0 at full offload and the actual THREADS applicability handler
    skipped processor tuning as "everything ... is on the graphics card". The
    before/after diagnostic (`impl_project_followup_card_probe.py`,
    `..._card_before.json` / `..._card_after.json`) now reports card=False,
    processor_share=1 and threads eligible for that same CPU-renderer case.

    card_usable now requires at least one usable non-CPU device from a usable
    non-CPU backend. OS detection alone, an unusable API, an unusable device and CPU
    software rendering do not establish that capability. Conversely, a genuinely
    usable GPU does not disappear merely because its memory size is unknown. This
    separates capability from the scalar memory-fit evidence in decision 46;
    multiple usable graphics cards still establish capability while their unbound
    planning capacity remains unknown. A False result means no GPU capability was
    confirmed by the current inventory; it leaves processor tuning available rather
    than declaring processor work absent from a detected card alone. This does not
    prove which adapter the engine selected or invent a live utilization reading.

    The seven cases exercise machine_facts, processor_share and the actual threads
    eligibility hook together. Their preserved pre-fix execution has **5 failed /
    2 passed** (`impl_project_followup_card_before.xml`); the source was kept under
    `_jobs/out` until the running earlier snapshot finished, then the regression
    cases were added to tests/test_gpu.py. Normal single-card and multiple-card
    capability remain positive controls. The raw inventory helper is still present
    for inventory use; it no longer controls this path-selection fact. No search
    ordering formula, candidate-generation rule, acceptance threshold or new
    optimization path was introduced. On the affected hardware descriptions, path
    eligibility, priority and therefore dispatched measurement counts may change;
    that is the intended repair. Existing measurement and confirmation rules remain
    authoritative once those paths are selected.

Before decision 47 was applied, the follow-up broad scan completed with **3,045 passed,
3 skipped, 1 deselected** (`impl_project_followup_broad1.xml`, 734.550 s), all **508**
Python input hashes unchanged (`impl_project_followup_validation1_unchanged.json`).
Its strict replays also passed: **231 Practical**, **328 Unbounded / 323,916 events /
zero differences**, with the same references and qualifications recorded above.
Those are intermediate-source results; they do not validate decision 47. A second
final snapshot/gate checks that additional capability correction. The earlier records
are retained without being relabelled as final-source evidence.

48. **Automatic requests need consistent semantics across observation consumers.**
    Reproduced while checking the shared setting comparator: automatic requests
    have inconsistent semantics across owners.** Startup already treats threads=0
    and legacy negative GPU-layer requests as automatic, but observation consumers
    see literal 0/-1 and declare the actual chosen 6 threads / 8 layers contradictory.
    `impl_project_followup_auto_probe.py` / `..._auto_before.json` reproduce a healthy
    same-request restoration reported unverified. Ten new comparison/restoration
    cases have **8 failures / 2 passes** before repair
    (`impl_project_followup_auto_before.xml`). The correction moves the
    existing automatic-setting interpretation into the pure shared comparator,
    retaining actual positive observations and preserving explicit CPU-layer zero
    and positive-thread constraints. Removing startup's duplicate exception list
    then keeps all observation consumers on one interpretation.

49. **Equality of requests misses changed
    engine-selected defaults.** The actual verifier reports verified=True after
    captured effective threads=6 become 8, with the same requested configuration
    and the same probe answer (`impl_project_followup_restore_probe.py`,
    `..._restore_before.json`). Nine pre-fix regressions also demonstrate changed or
    missing observed threads, mmap, flash attention, K/V formats and context capacity,
    plus a contradicted/unverified baseline capture becoming apparently valid later;
    all nine fail (`impl_project_followup_restore_before.xml`). This is a false
    restoration proof, distinct from decision 48's false refusal. The repair
    retains the baseline's independently observed settings and evidence problems,
    compares those known settings after the existing restoration probe, and refuses
    lost/changed evidence or a baseline that never established its requested settings.
    Unknown unrequested settings cannot be invented. Existing unload ownership,
    probe count, cancellation propagation and result schema must remain intact.

Decisions 48/49 are now implemented. An internal frozen `_ProbeReading` gives named
fields to the existing probe result, including its detached observed configuration;
it avoids an expanding positional tuple and adds no serialized/persisted schema or
measurement store. Capture clears the previous observed baseline and evidence
problems on entry, just as it clears the old probe hash. A contradicted or unverified
requested baseline remains unsuitable even if the restored engine later shows the
requested value. Every originally observed setting must remain observable and equal
after restoration, including engine-selected defaults. This includes actual slot
context capacity: startup still accepts capacity >= the request, while restoration
requires equality with the capacity the original target actually showed. That
conservative distinction prevents a changed allocation from being called the same
observed baseline. Unknown unrequested settings remain unknown; the verifier does
not infer missing values or prove unobserved defaults. No additional generation,
measurement, retry, cleanup owner or gain threshold is added. Result notes name
baseline contradictions and lost/changed observations; the existing result contract
and exception/unload boundaries are retained.

The verifier does not silently replace automatic/default requests with fixed values
from telemetry. Doing so would change the owner's requested configuration and move
configuration ownership into a diagnostic component. It checks the existing restore
operation's fidelity and uses the existing failure path when that cannot be shown.

The direct probes now show a healthy automatic request verified=True without false
contradictions, and a changed effective default (6 -> 8 threads) verified=False.
Both still unload their adapter; new JSON files retain the before artifacts. Mypy
passes on 460 files (`impl_project_followup_mypy3.txt`). The second broad scan finished
before these edits with **3,052 passed, 3 skipped, 1 deselected**
(`impl_project_followup_broad2.xml`, 749.768 s), all 508 Python inputs unchanged
(`impl_project_followup_validation2_unchanged.json`); its strict replays also pass.
Those are intermediate-source results, not evidence for the subsequent restoration
correction. The final source needs its own snapshot/gates. No hardware or study-rule
change is involved; frozen study v8 still governs job128.

The restoration correction's focused selection passes **204 tests**
(`impl_project_followup_restore_after.xml`): the verifier, whole-project boundary
regressions, effective threads, resident recovery and resident race/timeouts. These
overlap earlier focused selections and are not counts to add together. Mypy remains
clean on **460 files**. The third/final follow-up snapshot records all **508 Python
files** in `impl_project_followup_validation3_inputs.json`, SHA-256
`46233dbaa907c23311b06a369602b75da53a55ea704ce47dd8b31e3d73e94f77`.
The final Practical replay passes **231/231 identical**
(`impl_project_followup_practical3_compare.txt`); Unbounded3 and broad3 are still
running at this update. Correctness sim3 completes under unchanged frozen v8 rules.
`impl_project_followup_finish.py` will refuse a final package unless the current
source hashes and every final gate match. The `.r2` package remains an immutable
parent; the follow-up package will contain the current changed files pinned to the
same owner HEAD, a delta from `.r2`, an updated full HEAD diff and their hashes.

An additional current-source automatic-choice diagnostic exercises the actual
verifier (`impl_project_followup_restore_matrix.py/.json`): the unchanged chosen
threads/GPU layers verify; changed automatic threads, changed automatic GPU layers
and lost GPU-layer evidence all refuse verification. Every case unloads its adapter.
These four synthetic cases supplement the test file; they are not hardware evidence
or four extra cases in either strict replay population.

50. **A wall-clock deadline test did not reliably reach the behavior it asserted.**
    The third broad scan has **3,070 passed, 1 failed, 3 skipped, 1 deselected**
    (`impl_project_followup_broad3.xml`, 744.850 s). Its sole failure is the existing
    test_balanced_layer_round_stops_at_the_time_limit: preparation plus short real
    sleeps can consume its 0.4 s budget before the layer reference is established,
    so it legitimately returns an earlier "starting ... could not be measured"
    record without a `complete` field. The test then raises KeyError rather than
    testing a layer search interrupted during traversal. It passes alone
    (`impl_project_followup_deadline_once.xml`). A controlled 0.4 s preparation
    delay reproduces that same failure (`..._deadline_stall_before.xml`), using
    the retained `_jobs/out/impl_project_followup_deadline_stall.py` pytest plugin.

    The test now shares one simulated perf_counter across its existing deadline
    owners, advancing 0.02 s for each scripted inference. Host scheduling and
    metadata/file preparation cannot select a different branch. Module-local
    time namespaces avoid changing the stdlib clock or pytest's own duration
    accounting. The three original assertions (limit applied, traversal incomplete,
    limit message emitted) are unchanged. The exact same injected preparation stall
    now passes (`..._deadline_stall_after.xml`). The unused real-sleep wrapper is
    removed. No production timing or report rule is changed, no test is deselected
    and no parity exclusion is widened. The failed full run remains evidence and
    must not be described as a pass. A final scan checks the repaired test.

The only Python change after the third broad scan is tests/test_tune.py; product,
evaluation, comparator and other fixture source remain unchanged. Fresh final
artifacts will still be produced for the repaired test snapshot. This is test
reliability work, not a fifth product behavior repair in this follow-up.

The repaired-test focused selection passes **214 tests**
(`impl_project_followup_deadline_after.xml`): tune, restoration, GPU and the full
boundary regression file. The stalled-clock reproduction passes too. After removing
the now-unused responder type import, the final checker again reports **460 files
clean** (`impl_project_followup_mypy5.txt`). The fourth snapshot contains **508 Python
files**, SHA-256 of `impl_project_followup_validation4_inputs.json`:
`e159790ae3d76d5c72b4d5d05f8903441d4f7c6c1715a23393ef629272fcc989`.
`impl_project_followup_validation3_delta.json` confirms tests/test_tune.py is the only
Python change since the failed third scan. Fourth broad/replay artifacts and sim4
are used for the final gate, avoiding any ambiguity about the repaired test snapshot.
Broad4 and the replays are still running at this update; sim4 completes under the
unchanged frozen v8 rules. Failed, intermediate and previous final records all remain.

Follow-up commands as executed (PowerShell, repository root). When reproducing, choose
fresh output/basetemp names so original evidence stays intact. Broad Windows tests
need the same read-only CIM access as the earlier scan; no model integrations run.

```powershell
$env:PSExecutionPolicyPreference = 'Bypass'
$env:TEMP = Join-Path (Get-Location) '_jobs\out\tmp'
$env:TMP = $env:TEMP
.venv\Scripts\python.exe -B -m pytest tests --ignore=tests/test_model_integration.py --ignore=tests/test_profiling_integration.py --ignore=tests/test_reasoning_integration.py --deselect=tests/test_experiment_integration.py::test_real_candidate_applies_to_real_backend --basetemp=_jobs/out/impl_project_followup_broad4_tmp --junitxml=_jobs/out/impl_project_followup_broad4.xml -q
.venv\Scripts\python.exe -B -m mypy --platform win32 src tests scripts/evaluate_prompt_reuse.py scripts/reanalyse_prompt_reuse.py
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py record . _jobs/out/impl_project_followup_practical4.json
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py compare _jobs/out/impl_job128_v8_final_practical.json _jobs/out/impl_project_followup_practical4.json
.venv\Scripts\python.exe -B scripts/unbounded_reference.py record . _jobs/out/impl_project_followup_unbounded4.json.gz
.venv\Scripts\python.exe -B scripts/unbounded_reference.py compare _jobs/out/impl_project_full_unbounded_bound_before.json.gz _jobs/out/impl_project_followup_unbounded4.json.gz
.venv\Scripts\python.exe -B scripts/evaluate_prompt_reuse.py --simulate --study correctness --swa-full-variant --chat-exposure --blocks 3 --preregistration _jobs/later/128_rules_reuse-correctness-8.txt --preregistration-sha256 4a80891cb9f607da6d341f27d0da090148292a199d389d4101b6038b8e293734 --out _jobs/out/impl_project_followup_correctness_sim4.json
.venv\Scripts\python.exe -B -m pytest -p _jobs.out.impl_project_followup_deadline_stall tests/test_tune.py::test_balanced_layer_round_stops_at_the_time_limit --basetemp=_jobs/out/impl_project_followup_deadline_stall_after_tmp --junitxml=_jobs/out/impl_project_followup_deadline_stall_after.xml -q
```

The negative pre-fix selections and all before/after direct probes remain alongside
these outputs. Existing references and exclusions are unchanged. The newer test fixes
do not replace a reference population, old recordings or the original broad failure.

### Follow-up final results and review artifacts (18 Oct 2026)

The final fourth Windows scan passes: **3,071 passed, 3 skipped, 1 deselected**
(`impl_project_followup_broad4.xml`, 733.219 s). All **508 Python input hashes**
still match the pre-scan snapshot (`impl_project_followup_validation4_unchanged.json`).
The same real-model integration exclusions remain. The POSIX-terminal and two
restricted-symlink skips are not presented as passes; the separate real-junction
diagnostic above supplements, rather than replaces, their coverage.

- Mypy: **460 files clean**, including evaluation/reanalysis scripts
  (`impl_project_followup_mypy5.txt`).
- Practical: **231/231 identical**, unchanged original v8 reference and documented
  existing normalization only (`impl_project_followup_practical4_compare.txt`).
- Unbounded: **328 scenarios / 323,916 events / zero differences**, unchanged
  preserved entry reference with the identical synthetic profile/path binding
  repair described above (`impl_project_followup_unbounded4_compare.txt`). No new
  allow flag, tolerance, scenario substitution or evidence subtree exclusion.
- Correctness sim4: **done**, **108 native trials / 18 chat blocks (54 chat loads)**,
  frozen study v8 SHA-256 unchanged. Simulation is software evidence only.
- The follow-up adds **35 regression cases** across GPU evidence, actual path
  eligibility, automatic settings and restoration proof. These are included in the
  broad total. The repaired deadline test retains its original assertions and the
  controlled real-delay reproduction now passes. The earlier broad failure and all
  negative pre-fix selections remain available, without being relabelled as passes.

Review delivery is pinned to unchanged owner HEAD `cd56c46`:

- `_jobs/out/impl_project_followup_diff.patch`: changes since the preserved `.r2`
  package. Unchanged files omitted from that earlier changed-file package are
  recovered from the original entry archive only after their bytes match `.r2`'s
  complete Python manifest; an existing test is not mislabelled as a new file.
- `_jobs/out/impl_project_followup_workspace_head.patch`: complete current HEAD diff,
  including the already-adopted earlier work and all untracked source/tests.
- `_jobs/out/impl_project_followup_review_source.zip`: current changed source,
  tests/docs, this sole handoff, prepared job128 and its frozen governing rules. This
  is a changed-file review package pinned to HEAD, not a new complete Git checkout.
- `_jobs/out/impl_project_followup_final_checks.json`: actual gate counts, full
  508-file Python hash map, parent-package identity, before/after reproductions,
  current source/patch/package hashes and the unchanged Git head.
- `_jobs/out/impl_project_followup_verified.json`: independently written by
  `impl_project_followup_verify.py` only after checking every artifact hash in both
  the parent and follow-up manifests, package bytes against the workspace, the
  handoff hash, unchanged HEAD, frozen rules and job128 still in `later` with no
  queued scripts. Keeping this check separate avoids a self-referential handoff /
  manifest / archive hash cycle.

`impl_project_followup_finish.py` refuses a package unless the final source hashes,
broad suite, type check, strict replays and frozen-rule simulation pass. Both scripts
use read-only Git operations and refuse to overwrite their outputs. The earlier
`.r2` package, its manifest and all reviewer repairs remain intact.

The four further product defects are repaired, and the test race is made reproducible
and deterministic. Known limits remain: bounded searches cannot prove a global
optimum; ambiguous GPU capacity needs real selected-device binding; observations
cannot prove settings the engine never reports; generic quality checks are not a
semantic oracle; supported model geometry and the single-controller lifetime contract
still bound the implementation. This is an architecture/critical-boundary audit of
all existing optimization paths and their interactions, not independent line-by-line
certification of every file or a claim that no further defect can exist.

No model was loaded and no hardware performance/correctness study was run or queued.
Windows tests used read-only inventory where required. No saved owner setup was
changed, and there was no commit, push, history rewrite or job move. Job128 remains
prepared in `later`. This file is still the only maintained handoff.


## Independent-review correction completion (19 Oct 2026)

Decisions 51-53 and their related adapter-publication repair are implemented.
Independent acceptance is still pending. The reviewer findings were reproduced,
not waived. This final section supersedes the correction section's intermediate
validation statements; all earlier artifacts and failed explorations remain.

- **Final Windows suite:** 3,121 passed, 3 skipped, 1 deselected, zero failures
  or errors (`impl_independent_broad2.xml/.txt`, 740.844 seconds).
  All **509 Python hashes** still match `impl_independent_validation3_inputs.json`,
  SHA-256 `3668e54236a3d4b04f649ad61a4920884a8412809277556f4378bde284b4503f`.
- **Mypy:** 461 files clean, including both evaluation/reanalysis scripts
  (`impl_independent_mypy7.txt`).
- **Practical:** 231/231 identical against the unchanged v8 reference
  (`impl_independent_practical2_compare.txt`).
- **Unbounded:** 328 scenarios / 323,916 events / zero differences
  (`impl_independent_unbounded2_compare.txt`). The same previously reviewed
  synthetic profile/file-path binding qualification applies to the preserved
  reference; no reference repair, tolerance, allowance or population change was
  added here. The additional historical test-driven recordings are not claimed as
  separately rerun recordings; the broad tests are separate evidence.
- **Frozen-rule simulation:** done, 108 native trials and 18 chat blocks / 54 loads
  (`impl_independent_correctness_sim2.json`). This is simulated, not hardware evidence.
  Study v8 and rule SHA-256 remain unchanged. These fixes enforce the existing
  operator grammar; there is no new preregistration amendment or changed rule.
- **Sensitivity:** the entire final 49-case regression file gives **38 failures and
  11 passing controls** on preserved entry code (`impl_independent_before5.xml`).
  The old modules are injected only into that test process, including the package
  re-export of RollbackExecutor. No old product file is restored over the workspace.
  All 49 pass on final source in the broad suite. The focused 187-pass selection
  and final 8-case lifecycle check are overlapping evidence, not extra broad counts.
- **Intermediate broad run:** 3,119 passed, 3 skipped, 1 deselected in 976.89 s
  (`impl_independent_broad.xml`). Source changed during that run as the adapter
  bookkeeping repair and two regressions were added; it does not certify a single
  final snapshot. Only broad2 is the final whole-suite gate. An early Unbounded
  comparison was attempted before the recording existed; its missing-file output
  is preserved, followed by the completed successful comparisons with fresh names.

The retained operator before2/after probes show raw `57 *` / `56 *` becoming
unscorable, partial-reuse evidence inconclusive, no interpretable SWA removal claim
and unscorable chat-client evidence. A supplementary simulated chat matrix covers
144 contexts: all nine pairs, correct and incorrect values, four operators on both
sides (`impl_independent_chat_matrix.py/.json`). All produce unscorable client
evidence over two blocks each; these are diagnostics, not extra broad test cases.
The retained recovery probes show observed
threads 6 -> 8 refusing both resident recovery and checkpoint recovery. Real-child
tests cover both stop/cleanup orderings, starts refused while stopping, retained
replacement credentials and later successful release; every diagnostic child is
reaped in a finally. Additional controls cover startup cancellation, failed-stop
retry, missing observations, all supported observed fields, legitimate unchanged
defaults and initially unverified requested settings.

The ready-process cleanup route now uses the stop's existing unload measurement
format, so cleanup can populate last_unload where it previously did not. No lifecycle
schema, tune-request format or history identity was added. Request-generation tokens,
captured stop operations and observed-baseline snapshots are in-memory ownership /
verification state, not new editable configuration or measurement stores. There is
still one resident resource owner and one selected/requested setup per existing owner.
No extra inference, measurement or confirmation was added to collect these diagnostics.

Reproduction commands (repository root, use fresh names when repeating):

```powershell
$env:PSExecutionPolicyPreference = 'Bypass'
$env:TEMP = Join-Path (Get-Location) '_jobs\out\tmp'
$env:TMP = $env:TEMP
.venv\Scripts\python.exe -B -m pytest tests --ignore=tests/test_model_integration.py --ignore=tests/test_profiling_integration.py --ignore=tests/test_reasoning_integration.py --deselect=tests/test_experiment_integration.py::test_real_candidate_applies_to_real_backend --basetemp=_jobs/out/impl_independent_broad2_tmp --junitxml=_jobs/out/impl_independent_broad2.xml -o addopts= -q
.venv\Scripts\python.exe -B -m mypy --platform win32 src tests scripts/evaluate_prompt_reuse.py scripts/reanalyse_prompt_reuse.py
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py record . _jobs/out/impl_independent_practical2.json
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py compare _jobs/out/impl_job128_v8_final_practical.json _jobs/out/impl_independent_practical2.json
.venv\Scripts\python.exe -B scripts/unbounded_reference.py record . _jobs/out/impl_independent_unbounded2.json.gz
.venv\Scripts\python.exe -B scripts/unbounded_reference.py compare _jobs/out/impl_project_full_unbounded_bound_before.json.gz _jobs/out/impl_independent_unbounded2.json.gz
.venv\Scripts\python.exe -B scripts/evaluate_prompt_reuse.py --simulate --study correctness --swa-full-variant --chat-exposure --blocks 3 --preregistration _jobs/later/128_rules_reuse-correctness-8.txt --preregistration-sha256 4a80891cb9f607da6d341f27d0da090148292a199d389d4101b6038b8e293734 --out _jobs/out/impl_independent_correctness_sim2.json
.venv\Scripts\python.exe -B -m pytest -p _jobs.out.impl_independent_before_plugin tests/test_independent_review_fixes.py -o addopts= --basetemp=_jobs/out/impl_independent_before5_tmp --junitxml=_jobs/out/impl_independent_before5.xml -q
```

Delivery: `impl_independent_fixes.patch` is the complete correction diff against
owner commit 9e29ba8, including the new test file. `impl_independent_review_source.zip`
is a changed-file package pinned to that commit, with this sole handoff, prepared
job128 and its frozen rules. `impl_independent_final_checks.json` records the complete
Python hash map, actual gate counts and artifact hashes. `impl_independent_verify.py`
independently checks package bytes, hashes, HEAD and job placement and writes
`impl_independent_verified.json`; that separate record avoids a self-hash cycle.
The package helper checks all gates and refuses existing outputs. The 22 artifacts
hashed by the independent review are verified unchanged. Old review packages and
their archives were not replaced.

No hardware/model evaluation, saved-owner-setup change, queue move, commit or push
occurred. The Windows tests use read-only hardware inventory and owned Python child
processes where needed. Job128 remains in later for re-review before owner-authorized
execution. The bounded-search, unknown-telemetry, supported-geometry and semantic
quality limits from the earlier audit still apply. This is a correction delivery,
not independent acceptance or a claim of exhaustive scheduling-interleaving coverage.


## Second independent-review correction completion (19 Oct 2026)

Decisions 54-56 are implemented. This section supersedes this round's preliminary
validation statement; the earlier dated results remain preserved.

- Final Windows broad suite: **3,153 passed, 3 skipped, 1 deselected**, no
  failures/errors (`impl_publication_broad2.xml/.txt`, 740.722 seconds).
  The 78-case independent-review regression file includes the original 49 and
  this round's 29 adapter cases. One additional debug-fixture case tests preservation after a failed stop.
  Two additional recovery-fixture cases are in
  `tests/test_resident_recovery.py`. The final focused selection passes 143 tests;
  it overlaps the broad gate.
- Mypy: **461 files clean**, including both evaluation/reanalysis scripts.
- Strict Practical: **231/231 identical**, using the preserved v8 reference.
- Strict Unbounded: **328 scenarios / 323,916 events / zero differences**, using
  `impl_project_full_unbounded_bound_before.json.gz`. Its previously reviewed
  synthetic profile/file binding qualification is unchanged. No reference,
  comparator allowance, exclusion, tolerance or scenario population was changed.
  The additional historical test-driven recordings are not separately rerun here;
  broad tests are separate evidence.
- Frozen-rule simulation: **108 native trials, 18 chat blocks / 54 loads**, done,
  with rule v8 SHA-256 unchanged. This is simulated evidence, with no hardware meaning.
- All **509 Python hashes** still match `impl_publication_validation2_inputs.json`.
  Previous delivery/review artifact hashes all match (45 + 22 + 23 entries in their
  respective preserved manifests). No prior artifact or original record was replaced.
- Regression sensitivity: entry adapter injected into an isolated pytest process
  gives **26 failures / 3 passing controls** for the 29 new adapter cases. The forced
  host-collision probe independently fails the unchanged entry recovery test and
  passes the repaired fixture; unknown-PID existence remains conservative.

The new package is `impl_publication_review_source.zip`, pinned to owner HEAD
9e29ba8 with the complete uncommitted correction files, the sole handoff, job128
and frozen rules. `impl_publication_fixes.patch` is the complete diff against HEAD;
`impl_publication_delta.patch` isolates this round against the preserved entry
files. `impl_publication_final_checks.json` carries source/artifact hashes and counts;
`impl_publication_verified.json` is its separate read-only verification result.
The package helpers refuse existing outputs. The earlier `impl_independent_*`
packages, all reviewer artifacts and the failed diagnostic ZIP lookup remain intact.

Reproduction commands (repository root; use fresh artifact names on repetition):

```powershell
$env:PSExecutionPolicyPreference = 'Bypass'
$env:TEMP = Join-Path (Get-Location) '_jobs\out\tmp'
$env:TMP = $env:TEMP
.venv\Scripts\python.exe -B -m pytest tests --ignore=tests/test_model_integration.py --ignore=tests/test_profiling_integration.py --ignore=tests/test_reasoning_integration.py --deselect=tests/test_experiment_integration.py::test_real_candidate_applies_to_real_backend --basetemp=_jobs/out/impl_publication_broad2_tmp --junitxml=_jobs/out/impl_publication_broad2.xml -o addopts= -q
.venv\Scripts\python.exe -B -m mypy --platform win32 src tests scripts/evaluate_prompt_reuse.py scripts/reanalyse_prompt_reuse.py
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py record . _jobs/out/impl_publication_practical2.json
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py compare _jobs/out/impl_job128_v8_final_practical.json _jobs/out/impl_publication_practical2.json
.venv\Scripts\python.exe -B scripts/unbounded_reference.py record . _jobs/out/impl_publication_unbounded2.json.gz
.venv\Scripts\python.exe -B scripts/unbounded_reference.py compare _jobs/out/impl_project_full_unbounded_bound_before.json.gz _jobs/out/impl_publication_unbounded2.json.gz
.venv\Scripts\python.exe -B scripts/evaluate_prompt_reuse.py --simulate --study correctness --swa-full-variant --chat-exposure --blocks 3 --preregistration _jobs/later/128_rules_reuse-correctness-8.txt --preregistration-sha256 4a80891cb9f607da6d341f27d0da090148292a199d389d4101b6038b8e293734 --out _jobs/out/impl_publication_correctness_sim2.json
.venv\Scripts\python.exe -B -m pytest -p _jobs.out.impl_publication_before_plugin tests/test_independent_review_fixes.py -k 'superseded_adapter or pending_adapter or backend_load_evidence' --basetemp=_jobs/out/impl_publication_negative2_tmp --junitxml=_jobs/out/impl_publication_negative2.xml -o addopts= -q
.venv\Scripts\python.exe -B _jobs/out/impl_publication_probe_runner.py before
.venv\Scripts\python.exe -B _jobs/out/impl_publication_probe_runner.py after
.venv\Scripts\python.exe -B _jobs/out/impl_publication_fixture_probe.py
```

Coverage limits remain the excluded real-model integrations, POSIX terminal test,
and two symlink tests restricted on this host. The bounded-search, unknown-telemetry,
model-geometry and semantic-quality limitations are unchanged. No claim of exhaustive
multi-controller interleavings or a global optimum is made. Independent acceptance
is distinct from these implementation checks. Job128's original software blockers
are independently cleared; the frozen raw-backend runner remains in `later` for a
separately owner-authorized run. No hardware/model evaluation, saved-owner-setup
change, queue move, commit or push occurred.


## Third independent-review correction completion (20 Oct 2026)

Decisions 57-60 are implemented and their final-source gates complete. This section
supersedes this round's preliminary gate status; earlier dated evidence is retained.
Validation ran on 19 Oct; this review package was finalized on 20 Oct (Asia/Calcutta).

- **Windows broad suite: 3,218 passed, 3 skipped, 1 deselected**, zero failures or
  errors (`impl_stop_intent_broad2.xml/.txt`, 759.695 s). The regression
  file now has 143 cases (78 preceding + 65 this round); the focused 336-pass/
  1-skip selection overlaps the broad suite and is not an additional count.
- **Mypy: 461 files clean**, including both evaluation/reanalysis scripts.
- **Practical: 231/231 identical** against `impl_job128_v8_final_practical.json`.
- **Unbounded: 328 scenarios / 323,916 events / zero differences** against
  `impl_project_full_unbounded_bound_before.json.gz`. The independent reviewer has
  verified all 517 archived reference files and that the documented repair changes
  only the declared synthetic model-path binding. The original mismatch remains
  preserved. No reference, allowance, comparator, tolerance, exclusion or scenario
  population was changed in this repair. Historical extra test-driven recordings
  were not separately rerun; broad tests are distinct evidence.
- **Frozen-rule simulation: done, 108 native trials, 18 chat blocks / 54 loads**;
  this is simulated evidence, not a hardware result. Rule version/SHA-256 unchanged.
- All **509 Python hashes** match `impl_stop_intent_validation2_inputs.json`.
  The preceding artifact groups remain byte-identical; their per-manifest entry
  counts (with overlap possible) are recorded in `impl_stop_intent_preserved.json`.
- Entry-code sensitivity: **47 failures / 18 passing controls** for 65 final new
  cases, with archived classes injected only inside an isolated pytest process.
  The six before/after reviewer schedules independently reproduce four unwanted
  restarts before repair and zero after repair (plain cancellation was already a
  control). All six after cases invalidate the pending generation, keep the engine
  idle, retain null captured target PID, and perform no third engine start.

Intermediate diagnostics remain: `impl_stop_intent_focus1` (13 failed / 318 passed /
1 skipped; not one final snapshot), the initial schedules with preparation waits,
faulthandler stacks, and the 60-case initial entry run (42 failed / 18 controls).
They are not claimed as final gates. The diagnostic broad run with an added
60-second faulthandler timer terminated with Windows access violation during an
unchanged Unicode-summary test; its original `impl_stop_intent_broad.txt` is retained.
The isolated same test/timer passed in 91.33 seconds. The cause remains unestablished;
the final standard-command pass does not erase that unresolved diagnostic observation.
The finalized preparation preflight and cached
resume diagnostic have passing final coverage; exit proof remains the backend's
responsibility. Canceled work may still finish an already-entered bounded preparation
wait, but cannot be admitted afterwards. A resumed stop group never clears an old
request's Event. Atomic admission is supplied by the production resident backend;
legacy injected backends retain only their older protocol checks. Arbitrary multiple
raw-backend controllers are not turned into a new scheduler by this repair.

Delivery: `impl_stop_intent_fixes.patch` contains the complete uncommitted correction
against owner HEAD 9e29ba8. `impl_stop_intent_delta.patch` isolates this round from
`impl_stop_intent_before.zip`. `impl_stop_intent_review_source.zip` contains the
changed files plus this sole handoff and unchanged job128/rules. The final checks
manifest carries source/artifact hashes; `impl_stop_intent_verified.json` independently
verifies them and the package bytes. Helpers refuse existing outputs. All preceding
packages, reviewer reports and original results are retained.

Reproduction commands (repository root; use fresh artifact names on repetition):

```powershell
$env:PSExecutionPolicyPreference = 'Bypass'
$env:TEMP = Join-Path (Get-Location) '_jobs\out\tmp'
$env:TMP = $env:TEMP
.venv\Scripts\python.exe -B -m pytest tests --ignore=tests/test_model_integration.py --ignore=tests/test_profiling_integration.py --ignore=tests/test_reasoning_integration.py --deselect=tests/test_experiment_integration.py::test_real_candidate_applies_to_real_backend --basetemp=_jobs/out/impl_stop_intent_broad2_tmp --junitxml=_jobs/out/impl_stop_intent_broad2.xml -o addopts= -q
.venv\Scripts\python.exe -B -m mypy --platform win32 src tests scripts/evaluate_prompt_reuse.py scripts/reanalyse_prompt_reuse.py
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py record . _jobs/out/impl_stop_intent_practical2.json
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py compare _jobs/out/impl_job128_v8_final_practical.json _jobs/out/impl_stop_intent_practical2.json
.venv\Scripts\python.exe -B scripts/unbounded_reference.py record . _jobs/out/impl_stop_intent_unbounded2.json.gz
.venv\Scripts\python.exe -B scripts/unbounded_reference.py compare _jobs/out/impl_project_full_unbounded_bound_before.json.gz _jobs/out/impl_stop_intent_unbounded2.json.gz
.venv\Scripts\python.exe -B scripts/evaluate_prompt_reuse.py --simulate --study correctness --swa-full-variant --chat-exposure --blocks 3 --preregistration _jobs/later/128_rules_reuse-correctness-8.txt --preregistration-sha256 4a80891cb9f607da6d341f27d0da090148292a199d389d4101b6038b8e293734 --out _jobs/out/impl_stop_intent_correctness_sim2.json
.venv\Scripts\python.exe -B -m pytest -p _jobs.out.impl_stop_intent_full_before_plugin tests/test_independent_review_fixes.py -k 'workload_stop_cancels or older_resume or serving_request_preparation' --basetemp=_jobs/out/impl_stop_intent_negative3_tmp --junitxml=_jobs/out/impl_stop_intent_negative3.xml -o addopts= -q
.venv\Scripts\python.exe -B _jobs/out/impl_stop_intent_probe.py before
.venv\Scripts\python.exe -B _jobs/out/impl_stop_intent_probe.py after
```

The real-model integrations remain excluded. The POSIX-terminal and two restricted
link tests remain skipped on this Windows host. Bounded search does not prove a
global optimum; deterministic parity does not prove hardware performance or general
semantic correctness. The previous unknown-telemetry/model-geometry limitations are
unchanged. Independent acceptance remains separate. Job128's direct-backend runner
remains software-ready per independent review and stays in later for separately
owner-authorized hardware work. No hardware/model run, saved-owner-setup change,
queue move, commit or push occurred.


## Fourth independent-review correction completion (20 Oct 2026)

Decision 61 is implemented. Final Windows gates on the same 509 Python inputs:

- **3,244 passed, 3 skipped, 1 deselected** in the broad suite
  (`impl_halt_permission_broad.xml/.txt`, 703.797 s).
- **362 passed, 1 restricted-link skip** in the focused lifecycle/adapter/recovery/
  reuse/acceptance selection; this overlaps the broad suite. The independent-review
  regression file now has **169 cases**, including this round's 26 cases. Those 26
  failed against entry code and pass against the repair; the negative output is
  retained rather than refreshed.
- **Mypy: 461 files clean**, including both evaluation/reanalysis scripts.
- **Practical 231/231 identical** against `impl_job128_v8_final_practical.json`.
- **Unbounded 328 scenarios / 323,916 events / zero differences** against
  `impl_project_full_unbounded_bound_before.json.gz`. The previously independently
  verified synthetic model-path binding repair remains the only declared reference
  change; its original mismatch and all reference files remain preserved. No
  comparator, exclusion, tolerance or scenario population changed in this round.
- **Frozen-rule simulation: done, 108 native trials, 18 chat blocks / 54 loads**.
  This is simulated evidence only. Job128's wrapper and frozen rule bytes/version/
  SHA-256 are unchanged.
- The supplied direct and public-verifier schedules reproduce **four bypasses in
  six cases before**, and **zero after**; both no-release controls remain refused.
  Every after case has old resume False, no subsequent engine start, and idle state.
- **509 Python hashes match** `impl_halt_permission_validation_inputs.json`. Only
  the adapter and regression file differ from the entry Python snapshot. The
  roadmap and this sole handoff are the documentation changes. All **311 unique
  preceding delivery/review artifacts** still match their recorded hashes.

The previous diagnostic access violation remains unresolved. Its failed log and
both passing isolated timer controls remain preserved. This standard-command pass
does not identify its cause or erase the failed run. Hardware/model integrations
remain excluded; the POSIX-terminal and two restricted-link skips remain. The
legacy/custom-backend admission, bounded-search, unknown-telemetry/model-geometry
and semantic-quality limitations recorded earlier are unchanged. Parity does not
prove global optimality or hardware performance. No exhaustive multi-controller
interleaving claim is made.

Review package: `impl_halt_permission_fixes.patch` is the cumulative dirty diff
against owner 9e29ba8; `impl_halt_permission_delta.patch` isolates this round from
the entry archive; `impl_halt_permission_review_source.zip` contains the changed
files, same handoff and unchanged job128/rules. The checks manifest carries input,
artifact and handoff hashes. The separate `impl_halt_permission_verified.json`
checks hashes, package/workspace equality, HEAD/index and preserved artifacts.
All outputs use fresh names and previous packages are retained.

Exact commands (repository root; choose fresh artifact names on repetition):

```powershell
$env:PSExecutionPolicyPreference = 'Bypass'
$env:TEMP = Join-Path (Get-Location) '_jobs\out\tmp'
$env:TMP = $env:TEMP
.venv\Scripts\python.exe -B -m pytest tests/test_independent_review_fixes.py tests/test_prompt_reuse.py tests/test_resident_adapter.py tests/test_resident_cancellation.py tests/test_resident_races_timeouts.py tests/test_resident_recovery.py tests/test_review7_acceptance.py --basetemp=_jobs/out/impl_halt_permission_focus_tmp --junitxml=_jobs/out/impl_halt_permission_focus.xml -o addopts= -q
.venv\Scripts\python.exe -B -m pytest tests --ignore=tests/test_model_integration.py --ignore=tests/test_profiling_integration.py --ignore=tests/test_reasoning_integration.py --deselect=tests/test_experiment_integration.py::test_real_candidate_applies_to_real_backend --basetemp=_jobs/out/impl_halt_permission_broad_tmp --junitxml=_jobs/out/impl_halt_permission_broad.xml -o addopts= -q
.venv\Scripts\python.exe -B -m mypy --platform win32 src tests scripts/evaluate_prompt_reuse.py scripts/reanalyse_prompt_reuse.py
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py record . _jobs/out/impl_halt_permission_practical.json
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py compare _jobs/out/impl_job128_v8_final_practical.json _jobs/out/impl_halt_permission_practical.json
.venv\Scripts\python.exe -B scripts/unbounded_reference.py record . _jobs/out/impl_halt_permission_unbounded.json.gz
.venv\Scripts\python.exe -B scripts/unbounded_reference.py compare _jobs/out/impl_project_full_unbounded_bound_before.json.gz _jobs/out/impl_halt_permission_unbounded.json.gz
.venv\Scripts\python.exe -B scripts/evaluate_prompt_reuse.py --simulate --study correctness --swa-full-variant --chat-exposure --blocks 3 --preregistration _jobs/later/128_rules_reuse-correctness-8.txt --preregistration-sha256 4a80891cb9f607da6d341f27d0da090148292a199d389d4101b6038b8e293734 --out _jobs/out/impl_halt_permission_correctness_sim.json
.venv\Scripts\python.exe -B _jobs/out/impl_halt_permission_probe.py before
.venv\Scripts\python.exe -B _jobs/out/impl_halt_permission_probe.py after
.venv\Scripts\python.exe -B -m pytest -p _jobs.out.impl_halt_permission_before_plugin tests/test_independent_review_fixes.py -k 'test_release_preserves_halt or test_release_inside_resume' --basetemp=_jobs/out/impl_halt_permission_negative_replay_tmp --junitxml=_jobs/out/impl_halt_permission_negative_replay.xml -o addopts= -q
```

The before probe command deliberately recorded the entry implementation before
product edits; recreating that historical probe requires its preserved adapter
source, not today's checkout. The isolated negative-test command above does this
without changing checkout files and reproduces all 26 failures after the repair.
For the positive selection, omit the archived-source plugin and use fresh output
paths. The original before and replay outputs are both retained.
No checked-out source, existing reference or reviewer artifact was overwritten.
Independent acceptance remains pending. Job128 remains software-ready per the
independent review and stays in later for separate owner hardware authorization.
No hardware/model run, saved-owner-setup change, queue move, commit or push occurred.


## Job128 completion and frozen-rule interpretation (20 Oct 2026)

63. **Keep post-data interpretation distinct from changing the experiment.** Both
stored summaries recompute identically with the unchanged frozen-version functions
in a read-only audit. Raw result bytes are unchanged. A plausible answer rejected
by the conservative grammar stays unscorable in this registered result; no parser
or denominator was repaired after observing data. Correct answers after requesting
--swa-full do not establish a mitigation without the required cache-state proof.
This preserves the pre-registration while exposing both limitations for separate
review. No extra hardware investigation, retry, production capability or default
change was launched.

Execution: **19:52:01 to 20:57:17 IST**, 3,916.22 s / **65 min 16 s**, including the
unchanged ten-minute rest. Wrapper exit **0**; both records status **done**.
Operational completion is distinct from correctness: Gemma failed G1.

| Model | Native trials | Chat blocks / loads | Clean unloads | AC checks |
| --- | ---: | ---: | ---: | ---: |
| Gemma 3 1B Q4_K_M | 108 | 18 / 54 | 162 | 324 |
| Llama 3.2 3B Q4_K_M | 54 | 18 / 54 | 108 | 216 |
| Total | 162 | 36 / 108 | 270 | 540 |

Each model has unchanged model-file and data-folder fingerprints, no validity
breach, no reported request/cleanup problem, and no held-engine retry. A post-run
process-name check found no llama engine running. The launcher released its wake
hold on exit. Both contexts are 4096, using saved AC setups read only. Gemma uses
setup-0e54fdd01e (threads 9, ubatch 1024, GPU layers 1); Llama uses setup-7c62902e00
(ubatch 1024, GPU layers 29, threads left to the engine default). Other requested
fields and exact per-load commands are in the raw records. This is not a new tune
result or an optimal-configuration claim.

Frozen rules applied:

- **G1 reproduced:** Gemma's exact job127 regression has three usable blocks: fresh
  states 57; partial reuse (1033 of 1046 prompt tokens) refuses in all three. Raw
  text confirms the refusal. This is one prompt pair, not a population failure rate.
- **G2: 0 of 7 additional scored pairs.** Filters is uninformative: fresh and reuse
  put 10 on the first line instead of expected 20 (the later explanation mentions
  20). The frozen first-answer rule remains wrong. Do not count this as a reuse
  failure or a successful causal comparison.
- **G3 not interpretable:** the regression is right in all three --swa-full blocks,
  still with partial reuse. But all 54 default loads are labelled 'no sliding-window
  cache'; all 54 full-variant loads are 'unverified: no cache sizes in the startup
  log'. Required reduced/full per-load proof is absent. interpretable=False and
  logs_verified=False govern: the descriptive 'wrong only at the default' label
  permits no removal/fix claim, and no supported mechanism/cause claim.
- **G4: 0 of 9 scored Llama native pairs** show wrong partial-reuse evidence. All
  27 comparisons have right, identical fresh/reuse answers. This is a control in
  these cases, not proof of a sliding-window-specific cause or general safety,
  especially with Gemma's effective cache states unverified.
- **G5 no reuse-attributed exposure established.** Gemma has six informative chat
  pairs with right client answers after partial reuse. Pressure, bloom and the
  regression pair have wrong client/matched/unprimed replies in both blocks; those
  pairs establish no reuse-specific effect. Llama has eight informative chat pairs
  with right client answers after partial reuse. Its pressure pair is unscorable
  for all three roles in both blocks. The raw sentence 'For unit 5, a pressure drop
  above 25 kilopascals means a filter is blocked.' looks correct manually; the frozen
  continuation guard rejects ('5,' 'a'). It stays excluded, not silently counted
  right. Excluded cases provide no reassurance. Chat tested the default variant,
  not a --swa-full chat mitigation; no conclusion covers every client/format.
- **G6: no stops.** E1/E4, cleanup and AC evidence stayed valid. Requested-fresh
  readings showed zero reuse here; that does not audit historical tuning readings
  or guarantee other conditions.
- **G7 limits retained:** nine pairs, at most 24 answer tokens, one laptop/local
  engine setup, saved configurations, first-answer grammar. Right labels do not
  certify full semantics. Cache-log observability and the conservative identifier/
  continuation grammar need separate review; frozen artifacts are not changed
  retrospectively. Recorded engine identity is the runner's launcher identity,
  not independent loaded-library attestation.

The registered mitigation consequence needs G1/G2 wrong evidence AND G5 exposure;
G5 exposure is not established here, while G3 is not interpretable. No default
change follows. Prompt reuse remains a capability/development evaluation, not a
new tune path. Review the results and logging/grammar limits before another study
or mitigation decision. Job127's shifted-reuse/slot-routing E7 gap is still open.

Artifacts under _jobs/out (originals never overwritten):

- 128_correctness_gemma1b_20261020_195201_79da9758.json, SHA-256
  e78a5f44a21493a7ba85d4ce962e509cbabcce846e7e009cc9eaf5a280bde105.
- 128_correctness_llama3b_20261020_195201_79da9758.json, SHA-256
  139f50faa0e2af87a0fba1ab79ae655e5ffea8db2bd39ecb13c6c78fb6bda8e1.
- Matching .audit.json files: separate derived checks, with stored summaries
  recomputed identically and raw-result hashes verified unchanged.
- 128_owner_20261020_195200_dce18a03.log / .started.json / .done.json: console,
  launch identity, exit/duration. The wrapper's 'all steps passed' means operational
  completion; it does not mean every correctness rule passed.
- impl_job128_launch.ps1 / impl_job128_status.py / impl_job128_audit.py: exact
  orchestration and read-only monitoring/analysis helpers.
- 128_owner_20261020_195200_dce18a03.verified.json: combined provenance, artifact
  hashes, unchanged-source checks and frozen-rule outcomes.

Audit reproduction (choose fresh output names):

```powershell
.venv\Scripts\python.exe -B _jobs/out/impl_job128_audit.py _jobs/out/128_correctness_gemma1b_20261020_195201_79da9758.json _jobs/out/128_gemma_review_audit.json
.venv\Scripts\python.exe -B _jobs/out/impl_job128_audit.py _jobs/out/128_correctness_llama3b_20261020_195201_79da9758.json _jobs/out/128_llama_review_audit.json
```

All 509 Python inputs still match the accepted package; no source/tests changed,
so software gates were not rerun during hardware work. Owner commit 63f59d0 moved
its development log into docs/archive before the launch. That historical archive
is preserved; this run is recorded in the SAME maintained handoff and new result/
audit artifacts only. No tracked files changed and no new handoff was created.
Previous reports, simulations, reference recordings/exclusions, original job127
records and sealed packages are retained. No saved-setup/history write, queue move,
commit or push occurred. Job128 executed directly from later and remains there,
now explicitly recorded as run. The earlier diagnostic access violation remains
unexplained; this hardware run does not establish its cause.


## Software batch after accepted job128 results: decisions 64-72

Scope and entry: owner-authorized software work on clean HEAD 3314c863c8c8eb37ba7cc0a120dc4833555bbf83.
The independent results review accepted the accounting/interpretation, including
G3 unanswered; it did not approve a mitigation/default change. Entry snapshots are
_jobs/out/impl_g3_capture_before.zip (509 Python files plus handoff/README/job128 rules
and wrapper), impl_g3_capture_entry.json, and impl_g3_capture_preserved.json (28 study
and independent-review artifacts). Older repair packages and references stay intact.
The roadmap was moved to docs/archive by owner commit 63f59d0; that historical archive
is left intact. This handoff holds this batch's current development record.

64. **Add opt-in development diagnostics, no tune path or new measurement.**
    evaluate_prompt_reuse.py --capture-load-evidence records evidence version
    reuse-load-evidence-1. It is off by default. Both arms then request log_verbosity=4;
    this is a diagnostic condition, recorded in each load's requested_params, and not a
    production/default/threshold/search change. The pinned b11139 help describes level4
    as trace. Its common/log.cpp common_log_default_callback maps core INFO to trace,
    whereas its cache-size lines use LLAMA_LOG_INFO (preserved reviewer source
    _jobs/out/reviewer_job128_b11139_iswa.cpp, lines83/100). This makes trace a reasoned
    choice for collecting missing evidence. It is not proof that job128's missing lines
    had only this cause. Source reference:
    https://raw.githubusercontent.com/ggml-org/llama.cpp/b11139/common/log.cpp
    No change to frozen v8 judge, trial ordering/work, AC/validity checks or cleanup
    rules. Source version remains reuse-correctness-8 / prompt-reuse-eval-5 for unchanged
    scientific rules; the new observations have a separate format/protocol identity.
    Legacy records remain readable. New Reading/ChatReading optional load_evidence_id
    fields default to None, including serialized nulls in capture-off/simulated readings.
    These are evaluation records only; tune history/measurement schemas are untouched.

65. **Use the process owner's existing stdout/stderr readers.**
    LlamaServerProcess.startup_snapshot returns retained decoded text, first5000-line
    limit, dropped-line count, truncation and reader errors. Reader threads keep counting
    loss after the cap; they do not silently turn truncation into completeness. UTF8
    replacement decoding and merged stream read order are labelled; these are not original
    bytes or a total causal order. Existing startup_text/recent-log behavior is unchanged.
    LlamaServerResidentBackend.startup_log_snapshot binds the read to its existing process
    and epoch and rechecks the generation. No process lock is held during library hashing,
    no waiting for more log lines and no extra control/cleanup owner are introduced.
    A failed start that already discarded its process may have no startup snapshot. That
    stays an explicit gap; no previous load's log is borrowed. These snapshots concern a
    live load at readiness/before_stop, not complete shutdown logs.

66. **Observe loaded library backing files, with honest limits.**
    New tune/reuse_evidence.py process_image reads actual psutil memory_maps from the
    backend PID and hashes its executable and mapped .dll/.so/.dylib files, not model/data
    mappings. It records PID/create-time, UTC capture time, path, size, mtime and SHA256;
    it rechecks identity using a NEW Process instance because create_time can be cached.
    Unreadable/deleted libraries, access denial, exit and identity changes stay explicit.
    No optimistic fallback to the small launcher hash. Hashes describe observed backing
    files, NOT loaded instruction-memory attestation, official vendor provenance, or
    continuous coverage between snapshots. No hash cache: each opt-in snapshot actually
    reads files; pre/post samples catch discrepancies without assuming timestamps suffice.
    File identity checks descriptor/path file IDs, size and mtime, and each API's own ctime
    consistency. Windows3.12 experiment impl_g3_capture_stat_probes.json found35/300 stable
    fresh files where stat/fstat disagreed only in ctime; these APIs are therefore checked
    within themselves for ctime, while the other fields must agree across both. A focused
    regression preserves that distinction. This removes false refusals, not numeric or
    evidence exclusions. Per-file hashing is a bounded observation, not an OS transaction.

67. **Bind observations to native/chat reading owners, retain cleanup contracts.**
    RealReuseEngine assigns this-run/load-N identities before start, attaches them to
    returned native/chat readings and retains requested variant/params, redacted command,
    ready/before_stop snapshots, capture duration/errors, and release outcome. Native prime
    and measured replies share one load; every chat role has its own load. One backend per
    study remains the sole process/credential owner. Optional capture runs outside answer
    measurements. Ordinary diagnostic errors remain capture_errors, never successful
    evidence and never a replacement for an engine exception. Ctrl+C during capture still
    reaches existing stop in finally and propagates; a new exception raised by cleanup has
    the usual Python context (there is no blanket promise to suppress a second Ctrl+C).
    No retries/new probes/measurements populate diagnostics. Existing retry_held ownership
    remains authoritative; a later successful release does not retroactively make an
    interrupted trial usable. Extra hashing/logging can affect machine conditions, so the
    focused follow-up makes NO performance/noise/gain claim from its timing fields.

68. **Retain full fingerprint maps, including the baseline before any engine work.**
    Every REAL invocation, capture flag or not, retains data_folder_evidence version
    file-fingerprint-1: resolved root, before/after maps with size/mtime_ns/SHA256,
    timestamps and separate completeness flags. Baseline publication precedes model work.
    Each file hash checks a stable open descriptor/path; the file population is enumerated
    again. Enumeration uses os.scandir because rglob can silently skip unreadable folders.
    Errors propagate; nested links/reparse points and nonregular entries are explicitly
    unsupported rather than ignored/followed outside the root. This can refuse a previously
    accepted development invocation with such data entries; it preserves data and reports
    the limitation before model work. Windows reparse metadata uses the stat attribute
    flag, available without Python3.12-only Path.is_junction (project minimum is3.11).
    Errors/interruptions leave absent maps explicitly incomplete and preserve the
    earlier baseline; mismatches retain both maps and existing failure status. No setup or
    history is written. Identical maps do not prove there was no transient write; no new
    historical claim is made for job128, whose original maps were not retained. Simulation
    never fingerprints real owner data or fabricates these maps.

69. **Audit independently of operational exit and cache-state interpretation.**
    New scripts/audit_prompt_reuse_evidence.py reads a source and frozen rules, refuses
    existing/protected outputs, and exclusively writes a new audit with source/rules SHA.
    No engine call, raw-record edit, result merge or new quality judgement. It recomputes
    the UNCHANGED correctness summary, checks all12 ordered trials/6blocks and reading-to-
    load bindings, exact variants/requested config/context/model identity, complete AC and
    release evidence, raw log digests/loss metadata, PID identity, stable observed file
    hashes, required implementation/Vulkan libraries, and retained before/after maps.
    Raw before_stop cache evidence must match the trial parser; a ready snapshot may lag
    async log readers and is not used to invent a state. Known library hashes must match
    frozen engine input hashes. Newly lazy-loaded libraries need not have been present
    at readiness, but an already observed path's bytes cannot change unnoticed. A malformed
    record is refused, never successful by unsupported serialization. Exit0 means complete
    OBSERVATIONS, not a fix. Overall G3 interpretable = observations_complete AND the old
    comparison.interpretable. Complete capture can still have unknown cache state, no
    partial reuse or inconclusive replies. The audit preserves that distinction. Exit2
    retains explicit gaps; exit4 refuses input/output misuse. Unknowns never confirm G3.

70. **Prepare ONLY a bounded G3 follow-up, not another broad study.**
    Job129 _jobs/later/129_g3_startup_evidence_study.ps1 is NOT queued/run. Frozen rules
    _jobs/later/129_rules_g3-evidence-1.json are an experiment artifact, not another handoff.
    They embed the original frozen v8 text/digest and separately register this population:
    Gemma3 1B Q4_K_M SHA12bf0fff8815d5f73a3c9b586bd8fee8e7b248c935de70dec367679873d0f29d,
    exact regression-pump-b-unit-7 only, context4096, saved AC setup read only, default and
    full variants, 3 alternating-order fresh/reuse blocks each, 12 fresh loads. No chat,
    Llama control, E7, cancellation experiment, tuning, new paths, saves or default change.
    Both variants request the same trace diagnostics. A 10-20min estimate includes hashing;
    it is neither a deadline nor permission. No added cases/blocks/retries if unknown.
    The original default-then-full variant order keeps the reviewed trial plan intact
    while isolating observability changes. Variant order remains a limitation for causal
    interpretation; there is no new counterbalanced or timing study in this batch.
    G3 requires each default load reduced, each full load full from its own size/warning
    evidence and conclusive partial-reuse scoring under both. Results can still leave G3
    unanswered. A conclusive one-pair difference alone does not prove mechanism, generally
    safe reuse, or a serving mitigation. Independent protocol/results review is required.

71. **Freeze the executable inputs and fail closed in the wrapper.**
    Rules bind321 src/script Python files and43 installed engine/library files (not
    in-memory/vendor attestation). The wrapper pins rules SHA and verifies files before
    power waiting, immediately before dispatch, and after execution; then it runs only an
    offline audit. Unknown/battery power refuses; the runner retains per-load AC/cleanup/
    interruption stops. It checks this run's ID, real flag, version/rules digest and audit
    source hash; an exit0 without a new bound audit cannot succeed. Even incomplete work
    can be audited without starting another model. Wrapper success explicitly says only
    operational observations complete, prints G3 interpretable and requires review. There
    is no bypass-power switch. Python/Root/power-query injection exist for executable
    tests with fake programs; the prepared owner invocation uses defaults. The ignored
    impl_g3_capture_freeze.py produces the rules BEFORE review; no post-data re-freezing is
    permitted. Future rule/input changes require explicit review, with originals preserved.

72. **Keep the scientific history and scope intact.**
    Original job127/job128 artifacts, job128 frozen wrapper/rules and old repair packages
    remain byte-identical. Recompute accepted job128 summaries without editing raw inputs
    to check compatibility; do not rejudge or rehabilitate excluded answers. Fingerprint
    maps and mapped libraries are additive evidence for future work, not retroactive proof.
    Source changes are limited to evaluation capture, readonly backend log metadata, the
    new offline audit and tests. No planner, coordinator, path-interaction policy, backend
    lifecycle admission/release, production serving/default, kernel or threshold changes.
    The old global-optimality/semantic/hardware coverage limits and unexplained access
    violation remain open. Final checks/artifact hashes for this batch follow below.


### Final review / reproduction guide for this software batch

Keep using THIS handoff. New review artifacts belong under _jobs/out; do not create a
replacement handoff. Job129 is prepared only: do not execute its real wrapper during
software review or mistake software acceptance for hardware approval. Its frozen rules
SHA256 is 3d5cb1cc2ed2943b2645000c25ea9889e0824965cfcec64f29277c86fc9506a0.
Rules bind321 Python source/script files and43 local engine/library files. Inputs were
frozen before any job129 hardware result; no such result exists. The maintained handoff
is not itself the immutable experiment rules. Audit the frozen JSON and wrapper pins.

Review _jobs/out/impl_g3_capture.patch, impl_g3_capture_sources.zip and
impl_g3_capture_checks.json once sealed. New tracked files are reuse_evidence.py,
audit_prompt_reuse_evidence.py, test_reuse_evidence.py and test_g3_job.py. Existing changes
are evaluate_prompt_reuse.py, the two backend modules, Reading and ChatReading. No other
tracked file is changed. Source/function AST scope and identical old-release routine
checks are retained in impl_g3_capture_ast_scope.json and
impl_g3_capture_cleanup_equivalence.json. Existing scientific functions in prompt_reuse
and reuse_correctness have identical ASTs; their only changes are optional reading fields.
The same backend release implementation moved into _stop_backend with an identical AST
apart from its method name. Capture wraps this owner; no second owner was added.

Software-only reproduction (use FRESH artifact/basetemp names, preserve originals):

```powershell
.venv\Scripts\python.exe -B -m pytest tests/test_reuse_evidence.py tests/test_g3_job.py -o addopts= -q
.venv\Scripts\python.exe -B -m pytest tests --ignore=tests/test_model_integration.py --ignore=tests/test_profiling_integration.py --ignore=tests/test_reasoning_integration.py --deselect=tests/test_experiment_integration.py::test_real_candidate_applies_to_real_backend -o addopts= -q
.venv\Scripts\python.exe -B -m mypy --platform win32 src tests scripts/evaluate_prompt_reuse.py scripts/reanalyse_prompt_reuse.py scripts/audit_prompt_reuse_evidence.py
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py record . _jobs/out/REVIEW_g3_practical.json
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py compare _jobs/out/impl_job128_v8_final_practical.json _jobs/out/REVIEW_g3_practical.json
.venv\Scripts\python.exe -B scripts/unbounded_reference.py record . _jobs/out/REVIEW_g3_unbounded.json.gz
.venv\Scripts\python.exe -B scripts/unbounded_reference.py compare _jobs/out/impl_project_full_unbounded_bound_before.json.gz _jobs/out/REVIEW_g3_unbounded.json.gz
.venv\Scripts\python.exe -B scripts/evaluate_prompt_reuse.py --simulate --study correctness --swa-full-variant --chat-exposure --blocks 3 --out _jobs/out/REVIEW_g3_full_SIMULATED.json
.venv\Scripts\python.exe -B scripts/evaluate_prompt_reuse.py --simulate --study correctness --cases correctness/regression-pump-b-unit-7 --swa-full-variant --capture-load-evidence --blocks 3 --out _jobs/out/REVIEW_g3_focused_SIMULATED.json
```

Practical reference/population/exclusions are the same accepted231 scenarios. Unbounded
uses the same accepted328-scenario reference with its previously reviewed synthetic
model-path binding repair; the original mismatch remains preserved. No comparator or
reference was refreshed for this batch. Simulations are not hardware evidence. The new
focused simulation deliberately has no fake process snapshots or data maps; the offline
audit returns2 with observations_complete=False and g3_interpretable=False. Its record
and audit are retained separately. Compare core stored summaries on original job128 using
impl_job128_audit.py with new output names; both originals remain byte-identical.

The broad gate was restarted after the final enumeration/fresh-process safeguards so
its completed result represents the sealed source. Earlier iterative failures/logs are
kept, including the Windows stat/fstat ctime reproduction and an Unbounded comparison
attempt made before the recorder finished (FileNotFoundError). The final comparison was
run after recorder completion, passed, and did not alter references or exclusions.
All implementation/test choices and their reasons are in decisions64-72; validation
counts and sealed artifact details are appended below after completion.


### Sealed results (20 Oct 2026, 23:01 IST)

- FINAL Windows broad gate: **3318 passed, 3 skipped, 1 deselected**, 742.57s.
  Log/XML: impl_g3_capture_final_broad.txt/.xml. Real-model integration modules and
  the same real-backend case remain excluded; the same POSIX/link skips remain.
- Final new focused tests: **73 passed**, 22.51s, including executable fake-program
  PowerShell job129 cases. Log/XML: impl_g3_capture_final3_new.txt/.xml. These cover
  path/descriptor hashing and mutation, Windows ctime discrepancy, real mapping-shaped
  images and PID replacement/denials, truncation/reader failure/generation changes,
  capture opt-in, native/chat bindings, diagnostics errors/interruption/cleanup, exact
  twelve-load ownership and fresh-process uniqueness, map retention/change/error/interrupt,
  inaccessible-directory/link refusals, malicious/missing/mismatched audit evidence,
  unknown cache states, source/rules/output protection, power, stale run IDs, changed
  source, incomplete/false audit exits and no engine dispatch after a stop.
- Mypy: **465 source files clean** with --platform win32, src/tests and evaluation,
  re-analysis and new audit scripts. Log: impl_g3_capture_mypy_sealed.txt.
- Practical: **231/231 identical** against the accepted Windows reference, with only
  the existing named volatile fields. Unbounded: **328 scenarios / 323916 events /
  zero differences** against the same accepted bound reference. No new allowances,
  numeric exclusions, reference refresh or population change. Before recordings remain
  at the exact reference paths in the commands above; new after recordings are
  impl_g3_capture_practical.json and impl_g3_capture_unbounded.json.gz. Compare logs:
  impl_g3_capture_practical_compare.txt and impl_g3_capture_unbounded_compare_final.txt.
- Sealed-source simulations: full108 native trials +18chat blocks/54loads, and focused12
  native trials/nochat, both done. Files: impl_g3_capture_sealed_full_simulation.json and
  impl_g3_capture_sealed_focused_simulation.json. Focused capture remains simulated with
  an empty observation list and explicit gaps. Its separate simulation_audit.json returns
  exit2, observations_complete=False, g3_interpretable=False. No fake real attestation.
- Accepted job128: both native and chat summaries recomputed identically using the
  unchanged judge; all original exclusions remain. Derived files:
  impl_g3_capture_job128_gemma_audit.json / impl_g3_capture_job128_llama_audit.json.
- All **513** current Python files match the final-gate source snapshot. The original
  509-file entry snapshot is preserved; only9 Python files differ (5 edited,4 new).
  Both unchanged scientific function ASTs and the identical relocated release routine
  are verified separately. git diff --check passes. HEAD remains3314c86, index untouched.
- Preservation rechecked:28 job128/independent-review artifacts,41 prior package artifacts
  and311 older artifacts (overlapping groups, not a unique380-file claim). All original
  checksums match. README, job128 frozen wrapper/rules, earlier reference recordings and
  original mismatch artifacts remain intact. No owner data, setup, history, production
  default, model, tool binary, queue entry, Git history or remote was changed.

Delivery: _jobs/out/impl_g3_capture_checks.json is the check/hash/command manifest;
impl_g3_capture_sources.zip holds all513 Python inputs, THIS updated handoff, README,
job128 immutable rules/wrapper and job129 frozen rules/wrapper; impl_g3_capture.patch is
an entry-to-final diff including all4 new tracked files. The final check manifest records
these hashes and the prepared job129 artifact hashes. Earlier iterations and diagnostics
are preserved, labelled by their filenames; only the final gates above are completion
claims. No new handoff, commit, push, model/engine load or hardware run occurred.

**Next: independent software/protocol review of job129.** It is not queued or run, and
hardware approval is separate. G3 stays unanswered for accepted job128. No mitigation,
production/default change, E7/slot-routing answer or global-optimality claim follows.
The earlier unexplained access violation remains a limitation; these passing standard
runs do not identify its cause. Loaded-file snapshots are not in-memory attestation;
file maps are not filesystem transactions; frozen first-answer scoring is not full
semantic proof. Do not retroactively change accepted results or their frozen grammar.


## Job129 preflight correction: decisions73-77 (20 Oct 2026)

Independent review finding P2 is accepted. The first audit prevented acceptance of a
wrong-model result but ran too late to prevent the workload. Its original synthetic Qwen
reproduction completed12 fake loads under the Gemma pin. Do not treat the earlier sealed
software results as authorization: the initial v1 protocol remains rejected for dispatch.
Entry state is preserved in impl_g3_preflight_before.zip / impl_g3_preflight_entry.json;
all513 Python hashes, the same handoff and the original active wrapper/rules are archived.
The standalone wrapper copy is impl_g3_preflight_wrapper_g3-evidence-1.ps1. The95 entry
preservation entries cover prior capture/check artifacts and the independent review;
older nested preservation groups are still checked through their original manifests.

73. **Enforce the frozen content identity before constructing any engine.**
    Structured JSON registration must be an object with the actual current study_version
    and a valid64-hex model_sha256. A JSON filename, object or array is parsed as structured
    rules, so malformed/missing pins and array layouts cannot fall back to an unpinned
    text registration. Historical job128 text rules stay readable. JSON2 G3 rules also
    require require_saved_setup=True. The real runner hashes the model before setup or
    metadata preparation, records the computed identity and expected pin, and refuses a
    mismatch with exit4/status refused. No RealReuseEngine, backend or engine start is
    constructed/dispatched. The failure report remains owned by the normal runner; the
    data-folder maps show no store/history write. Shared reuse_evidence.file_identity now
    supplies the stable descriptor/path hash for model and launcher identities too,
    retaining the same output keys and the accepted Windows ctime treatment.

74. **Verify the selected saved setup by content, not by its pathname/mtime.**
    Evaluation-only _setup accepts the already computed identity to avoid hashing the
    large model twice. It checks selected/current paths, saved size and full saved SHA
    against current bytes. An absent or contradictory saved hash refuses even when size
    and date match. Same content with a changed modification date is permitted. This
    deliberately refuses unverifiable legacy development setups; it does not synthesize
    an identity or edit them. The production SetupStore, same_model_file and start/tune
    policies are unchanged. Stale saved evidence never falls through to --layers; the
    frozen G3 require_saved_setup flag also refuses a missing saved setup even when an
    ad-hoc caller supplies --layers. Ordinary unregistered studies can still explicitly
    use --layers when there is no saved entry. The saved setup/context validation stays
    read only. Model bytes and saved-setup identity are now both checked, because either
    one alone would leave the reviewer's bypass possible.

75. **Bind preparation and subsequent loads to the checked file generation.**
    Existing model_file_signature (resolved path, size, mtime, inode) brackets hashing,
    setup selection and the production GGUF parser. A changed generation refuses before
    RealReuseEngine construction. The engine interface receives that checked generation
    and checks it before every load, before backend construction/admission and before any
    request/pair. A changed file sets input_problem and dispatch stops through the existing
    owners. No probe, retry, extra measurement or cut to a permitted pair is added. This
    catches ordinary writes/replacements; it is not an OS handle lock or attestation
    against hostile preservation/restoration of all file metadata. The residual interval
    between a check and the engine's own path open remains a bounded-observation limit.
    Error/interrupt and backend ownership contracts stay unchanged.

76. **Keep wrapper enforcement and an auditable preflight receipt.**
    Confirm-Inputs now verifies model_file/model_sha256 as well as Python/engine inputs,
    before power waiting, after that wait immediately before dispatch, and after the run.
    Missing/unreadable/replaced models refuse before Python evaluation. The runner makes
    its own independent hash check; invoking it directly cannot bypass the wrapper gate.
    The new model_preflight receipt records the expected pin, pin verification and required
    saved-setup verification. It does not claim general attestation. The v2 offline audit
    additionally requires those flags; offline checks remain a second defence, not the
    dispatch owner. Its exit meanings and overall G3 AND gate are unchanged. Extra model
    hashing is outside measurements and can warm storage/cache; no speed claim follows.

77. **Revise the experiment artifact without rewriting the reviewed v1 evidence.**
    New _jobs/later/129_rules_g3-evidence-2.json supersedes only the preflight/input binding
    with protocol2. It records the prior rules SHA, the actual model relative path and the
    required saved-setup policy, and refreshes declared Python hashes for the revised
    software. The old129_rules_g3-evidence-1.json stays at its original path and checksum;
    its reviewed wrapper is copied byte-for-byte into out and the entry zip. No reference
    comparator, population or existing scientific result is refreshed. The v8 judge,
    regression pair, default-then-full order, context4096, trace level4, 12loads, AC/cleanup
    stops, G3 interpretation and all previous limits remain unchanged. No hardware data
    exists for either job129 revision. The old v1 audit implementation remains available
    in the preserved source package; the active public audit is now explicitly v2.

Regression evidence before final broad gates:

- Production _setup and GGUF metadata parser, with only the engine/power faked, cover
  wrong pin, stale hash with identical size/date, missing saved hash, inconsistent size,
  missing saved entry plus --layers, missing/malformed pins, wrong required-saved flag,
  preparation-time model replacement, wrong structured study version and array rules.
  Every negative case must construct/start ZERO engines. Identical bytes with a changed
  saved date and fully matching identities are positive controls (12 fake loads), with
  real Qwen metadata parsing. No real model/engine is loaded by those tests.
- The original independent caller reproduction was copied/adapted only to a fresh work/
  output path, safe missing-field reporting and the reversed defect assertions. It now
  returns exit4/refused, ZERO starts/stops and no profile reaching the engine factory.
  Original script/result remain unchanged. New artifacts:
  impl_g3_preflight_real_callers.py / .json / .txt, plus its separate fixture folder.
- The read-only owner check confirms the actual Gemma pin and saved setup setup-0e54fdd01e
  pass the new identity checks at context4096. It constructs no engine and parses/loads no
  model through an engine. Result: impl_g3_preflight_owner_readonly.json. Owner setup/data
  are untouched; this is a compatibility check, not another hardware study.
- New wrapper tests use a tiny fake model and require zero Python dispatch for a missing
  or changed model. A generation-change test requires zero backend construction. New v2
  rules receipt/identity gates are included in the ordinary audit cases.

The final software results, exact commands and preserved-artifact hashes follow below
when sealed. Review this amendment and the v2 frozen JSON before approving the software;
job129 remains in later and requires separate owner hardware approval after re-review.

### Final preflight-repair verification and review package

All final checks below ran on Windows against the same 513 Python input hashes. HEAD
remained 3314c863c8c8eb37ba7cc0a120dc4833555bbf83, with an empty Git index. No engine or
hardware workload was invoked, and no saved setup, runtime default or queue state changed.

| Check | Result | Artifact under _jobs/out/ |
| --- | --- | --- |
| Focused evidence, wrapper and job-script tests | 178 passed | impl_g3_preflight_focused.txt / .xml |
| Broad suite with the existing integration exclusions | 3,334 passed, 3 skipped, 1 deselected | impl_g3_preflight_broad.txt / .xml |
| Mypy, including all three evaluation/audit scripts | 465 files clean | impl_g3_preflight_mypy_final.txt |
| New refusal cases against preserved entry implementation | All 11 fail, no test errors | impl_g3_preflight_before3_tests.txt / .xml |
| Practical replay | 231/231 identical under existing normalization | impl_g3_preflight_practical.json / impl_g3_preflight_practical_compare.txt |
| Unbounded replay | 328 scenarios, 323,916 events, zero differences | impl_g3_preflight_unbounded.json.gz / impl_g3_preflight_unbounded_compare.txt |
| Original independent caller reproduction, adapted to fresh paths | Refused, exit 4; zero engine constructions, starts or stops | impl_g3_preflight_real_callers.py / .json / .txt |
| Full correctness simulation | Done: 108 native trials, 18 chat blocks / 54 chat loads | impl_g3_preflight_full_simulation.json |
| Focused simulation using frozen v2 registration | Done: 12 native trials, no chat | impl_g3_preflight_focused_simulation.json |
| Offline audit of simulated capture | Exit 2, observations incomplete, G3 not interpretable | impl_g3_preflight_simulation_audit.json |
| Accepted job128 summaries recomputed | Identical to both recorded summaries | impl_g3_preflight_job128_gemma_audit.json / impl_g3_preflight_job128_llama_audit.json |

The broad suite's three skips remain the POSIX-terminal test and two restricted Windows
link tests. The three real-model integration modules remain excluded, and the existing
real-backend integration case remains deselected. Their behavior is not covered by this
software-only repair. The earlier unexplained access violation remains unresolved.

The preserved replay references are impl_job128_v8_final_practical.json and
impl_project_full_unbounded_bound_before.json.gz. The latter retains the previously
independently reviewed synthetic model-path fixture binding; the original mismatch and
original reference are still preserved. No comparator exclusion, scenario population or
reference was changed for this repair. Practical's existing set-aside fields are listed
in its comparison log; replay equality does not prove hardware performance or global
search optimality.

Exact final commands from the repository root follow. Logs were redirected to the matching
prefix above. Choose fresh output and temporary paths when repeating them: the evaluation,
audit and packaging tools deliberately refuse to overwrite prior evidence.

```powershell
$env:PSExecutionPolicyPreference = 'Bypass'
$env:TEMP = Join-Path (Get-Location) '_jobs\out\tmp'
$env:TMP = $env:TEMP
.venv\Scripts\python.exe -B -m pytest tests/test_reuse_evidence.py tests/test_g3_job.py tests/test_job_scripts.py --basetemp=_jobs/out/impl_g3_preflight_focused_tmp --junitxml=_jobs/out/impl_g3_preflight_focused.xml -o addopts= -q
.venv\Scripts\python.exe -B -m pytest tests --ignore=tests/test_model_integration.py --ignore=tests/test_profiling_integration.py --ignore=tests/test_reasoning_integration.py --deselect=tests/test_experiment_integration.py::test_real_candidate_applies_to_real_backend --basetemp=_jobs/out/impl_g3_preflight_broad_tmp --junitxml=_jobs/out/impl_g3_preflight_broad.xml -o addopts= -q
.venv\Scripts\python.exe -B -m mypy --platform win32 src tests scripts/evaluate_prompt_reuse.py scripts/reanalyse_prompt_reuse.py scripts/audit_prompt_reuse_evidence.py
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py record . _jobs/out/impl_g3_preflight_practical.json
.venv\Scripts\python.exe -B scripts/practical_fingerprint.py compare _jobs/out/impl_job128_v8_final_practical.json _jobs/out/impl_g3_preflight_practical.json
.venv\Scripts\python.exe -B scripts/unbounded_reference.py record . _jobs/out/impl_g3_preflight_unbounded.json.gz
.venv\Scripts\python.exe -B scripts/unbounded_reference.py compare _jobs/out/impl_project_full_unbounded_bound_before.json.gz _jobs/out/impl_g3_preflight_unbounded.json.gz
.venv\Scripts\python.exe -B _jobs/out/impl_g3_preflight_real_callers.py
.venv\Scripts\python.exe -B scripts/evaluate_prompt_reuse.py --simulate --study correctness --swa-full-variant --chat-exposure --blocks 3 --out _jobs/out/impl_g3_preflight_full_simulation.json
.venv\Scripts\python.exe -B scripts/evaluate_prompt_reuse.py --simulate --study correctness --cases correctness/regression-pump-b-unit-7 --swa-full-variant --capture-load-evidence --blocks 3 --preregistration _jobs/later/129_rules_g3-evidence-2.json --preregistration-sha256 17feb7d76046ba4036f99606ef2bc20db9299e2f31ea320749a7ba8d534ba94f --out _jobs/out/impl_g3_preflight_focused_simulation.json
.venv\Scripts\python.exe -B scripts/audit_prompt_reuse_evidence.py _jobs/out/impl_g3_preflight_focused_simulation.json --rules _jobs/later/129_rules_g3-evidence-2.json --rules-sha256 17feb7d76046ba4036f99606ef2bc20db9299e2f31ea320749a7ba8d534ba94f --out _jobs/out/impl_g3_preflight_simulation_audit.json
.venv\Scripts\python.exe -B _jobs/out/impl_job128_audit.py _jobs/out/128_correctness_gemma1b_20261020_195201_79da9758.json _jobs/out/impl_g3_preflight_job128_gemma_audit.json
.venv\Scripts\python.exe -B _jobs/out/impl_job128_audit.py _jobs/out/128_correctness_llama3b_20261020_195201_79da9758.json _jobs/out/impl_g3_preflight_job128_llama_audit.json
```

For the before/after regression, the preserved entry zip was extracted into
impl_g3_preflight_before_root. Only the revised test file was copied into that isolated
test tree; the archived entry implementation and its original zip remain intact. The
following command runs the old evaluator with the real setup lookup/GGUF parser and is
expected to exit 1 with all 11 defect assertions failing:

```powershell
.venv\Scripts\python.exe -B -m pytest _jobs/out/impl_g3_preflight_before_root/tests/test_reuse_evidence.py -k test_frozen_preflight_refuses_before_engine_construction --basetemp=_jobs/out/impl_g3_preflight_before3_tmp --junitxml=_jobs/out/impl_g3_preflight_before3_tests.xml -o addopts= -q
```

The original independent caller script/results are untouched. The adapted script changes
only work/output paths, safe reporting of fields absent after refusal and the reversed
defect assertions. Its production setup lookup and metadata parser remain unpatched;
the wrong pin now refuses before either reaches dispatch. Initial implementation/test
diagnostics are retained separately rather than being represented as passing gates.

The package script impl_g3_preflight_package.py verifies the entry's 95 preserved hashes,
the previous capture package, and the older preservation manifests before exclusive
publication. It seals:

- impl_g3_preflight.patch: the four Python files changed in this correction, relative
  to the preserved entry batch; no src/ implementation changed in this round.
- impl_g3_preflight_from_head.patch: the full nine-file Python batch over owner HEAD.
- impl_g3_preflight_sources.zip: all 513 Python inputs, this same handoff, the old/new
  rules, preserved v1 wrapper and active v2 wrapper, plus the unchanged job128 inputs.
- impl_g3_preflight_checks.json: gate counts, probes, reference qualifications, file
  hashes and preservation manifests. This is the re-review entry point.

The frozen v2 rule SHA is
17feb7d76046ba4036f99606ef2bc20db9299e2f31ea320749a7ba8d534ba94f.
The preserved v1 rule SHA remains
3d5cb1cc2ed2943b2645000c25ea9889e0824965cfcec64f29277c86fc9506a0.
The package/check record carries the source and handoff hashes; no self-referential hash
is inserted into this handoff. Both frozen rules and the original independent evidence
remain available for review.

Status: the reported dispatch gap is repaired in software and the owner file/setup are
read-only compatible with it. Independent re-review is still required. Job129 remains
in later, unrun and awaiting separate owner authorization after software acceptance.
No G3 answer, mitigation, default change or performance claim follows from these tests.
