"""Enumerations shared across InferenceOS contracts."""

from __future__ import annotations

from enum import Enum


class StrEnum(str, Enum):
    """String-valued enum that serializes/compares as its value."""

    def __str__(self) -> str:  # pragma: no cover - trivial
        return str(self.value)


class GPUVendor(StrEnum):
    AMD = "amd"
    NVIDIA = "nvidia"
    INTEL = "intel"
    APPLE = "apple"
    UNKNOWN = "unknown"


class GPUDeviceType(StrEnum):
    DISCRETE = "discrete"
    INTEGRATED = "integrated"
    VIRTUAL = "virtual"
    CPU = "cpu"
    UNKNOWN = "unknown"


class BackendType(StrEnum):
    VULKAN = "vulkan"
    CUDA = "cuda"
    ROCM = "rocm"
    METAL = "metal"
    OPENCL = "opencl"
    SYCL = "sycl"
    CPU = "cpu"


class QuantizationType(StrEnum):
    F32 = "f32"
    F16 = "f16"
    BF16 = "bf16"
    Q8_0 = "q8_0"
    Q6_K = "q6_k"
    Q5_K_M = "q5_k_m"
    Q5_K_S = "q5_k_s"
    Q5_0 = "q5_0"
    Q5_1 = "q5_1"
    Q4_K_M = "q4_k_m"
    Q4_K_S = "q4_k_s"
    Q4_0 = "q4_0"
    Q4_1 = "q4_1"
    Q3_K_M = "q3_k_m"
    Q3_K_S = "q3_k_s"
    Q3_K_L = "q3_k_l"
    Q2_K = "q2_k"
    IQ4_XS = "iq4_xs"
    IQ4_NL = "iq4_nl"
    IQ3_M = "iq3_m"
    IQ2_M = "iq2_m"
    UNKNOWN = "unknown"


class AttentionType(StrEnum):
    MHA = "mha"
    GQA = "gqa"
    MQA = "mqa"
    UNKNOWN = "unknown"


class StorageMediaType(StrEnum):
    SSD = "ssd"
    HDD = "hdd"
    UNKNOWN = "unknown"


class WorkloadKind(StrEnum):
    SHORT = "short"
    LONG = "long"
    CODE = "code"
    PROSE = "prose"
    CHAT = "chat"
    MIXED = "mixed"
    UNKNOWN = "unknown"


class MeasurementMode(StrEnum):
    COLD = "cold"
    WARM = "warm"


class ObservationSource(StrEnum):
    HARNESS = "harness"
    CONTINUOUS_MONITOR = "continuous_monitor"
    DIAGNOSTIC = "diagnostic"
    MANUAL = "manual"


class MetricQuality(StrEnum):
    """Availability/provenance of a single measurement.

    ``MEASURED``   — observed directly from the real system/backend.
    ``DERIVED``    — computed deterministically from other measured values.
    ``UNAVAILABLE`` — the subsystem could not provide it (explicitly ``None``).
    ``NOT_APPLICABLE`` — the metric does not apply to this run.
    """

    MEASURED = "measured"
    DERIVED = "derived"
    UNAVAILABLE = "unavailable"
    NOT_APPLICABLE = "not_applicable"


class BottleneckKind(StrEnum):
    """Extensible deterministic bottleneck vocabulary (Phase 4).

    ``NONE`` and ``INSUFFICIENT_EVIDENCE`` are first-class terminal outcomes: a
    resource being heavily used is not itself a bottleneck.
    """

    CPU = "cpu"
    GPU_UNDERUTILIZATION = "gpu_underutilization"
    GPU_MEMORY_LIMIT = "gpu_memory_limit"
    COMPUTE_BOUND = "compute_bound"
    MEMORY_PRESSURE = "memory_pressure"
    MODEL_FOOTPRINT = "model_footprint"
    PAGING = "paging"
    STORAGE = "storage"
    IO_BOUND = "io_bound"
    LATENCY = "latency"
    EXTERNAL_PROCESS = "external_process"
    AMBIGUOUS = "ambiguous"
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"
    NONE = "none"


class InferenceStage(StrEnum):
    """Which phase of an inference run a finding applies to."""

    LOAD = "load"
    PREFILL = "prefill"
    TTFT = "ttft"
    DECODE = "decode"
    END_TO_END = "end_to_end"


class EvidenceStrength(StrEnum):
    """Explainable, evidence-derived confidence category (not a probability)."""

    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class EvidencePolarity(StrEnum):
    """Whether an evidence item supports or contradicts a candidate finding."""

    SUPPORTING = "supporting"
    CONTRADICTING = "contradicting"
    NEUTRAL = "neutral"


class CandidateKind(StrEnum):
    THREADS = "threads"
    BATCH_SIZE = "batch_size"
    UBATCH_SIZE = "ubatch_size"
    GPU_OFFLOAD_LAYERS = "gpu_offload_layers"
    MMAP = "mmap"
    CONTEXT_LENGTH = "context_length"
    KV_CACHE_DTYPE = "kv_cache_dtype"
    FLASH_ATTENTION = "flash_attention"
    OTHER = "other"


class CandidateStatus(StrEnum):
    PROPOSED = "proposed"
    DISCARDED = "discarded"
    SELECTED = "selected"
    APPLIED = "applied"
    KEPT = "kept"
    REVERTED = "reverted"


class Decision(StrEnum):
    KEEP = "keep"
    REVERT = "revert"
    NO_OP = "no_op"
    PENDING = "pending"


class ReasoningEngineKind(StrEnum):
    DETERMINISTIC = "deterministic"
    LLM = "llm"
    STUB = "stub"


class ReasoningTaskType(StrEnum):
    """What the reasoning engine is being asked to do."""

    ROOT_CAUSE_DIAGNOSIS = "root_cause_diagnosis"
    AMBIGUITY_RESOLUTION = "ambiguity_resolution"


class ReasoningStatus(StrEnum):
    OK = "ok"
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"
    FAILED = "failed"


# --------------------------------------------------------------------------- #
# Phase 6 — candidate generation & controlled optimization                      #
# --------------------------------------------------------------------------- #
class OptimizationSurface(StrEnum):
    """The kind of optimization surface an action operates on."""

    RUNTIME_PARAMS = "runtime_params"
    CONTEXT_MANAGEMENT = "context_management"
    GPU_OFFLOAD = "gpu_offload"
    MEMORY_MANAGEMENT = "memory_management"
    EXTERNAL_PROCESS = "external_process"
    SYSTEM_CONFIGURATION = "system_configuration"
    MODEL_REPRESENTATION = "model_representation"


class ParameterType(StrEnum):
    INTEGER = "integer"
    FLOAT = "float"
    BOOLEAN = "boolean"
    STRING = "string"


class RiskLevel(StrEnum):
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class Reversibility(StrEnum):
    """Conceptual reversibility of an intervention (Phase 8 owns rollback execution)."""

    REVERSIBLE = "reversible"
    REVERSIBLE_WITH_RESTART = "reversible_with_restart"
    NON_REVERSIBLE = "non_reversible"


class OptimizationScope(StrEnum):
    """How wide the blast radius of an intervention is."""

    TARGET_MODEL_RUNTIME = "target_model_runtime"
    TARGET_INFERENCE_PROCESS = "target_inference_process"
    CURRENT_WORKLOAD = "current_workload"
    USER_PROCESS = "user_process"
    EXTERNAL_PROCESS = "external_process"
    SYSTEM_WIDE = "system_wide"


class PrivilegeRequirement(StrEnum):
    STANDARD_USER = "standard_user"
    ELEVATION_REQUIRED = "elevation_required"
    UNKNOWN = "unknown"


class ApprovalRequirement(StrEnum):
    NOT_REQUIRED = "not_required"
    REQUIRED = "required"


class CandidateEligibility(StrEnum):
    ELIGIBLE = "eligible"
    GATED = "gated"
    REJECTED = "rejected"
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"


class PreconditionKind(StrEnum):
    """Category of a precondition; drives deterministic eligibility policy."""

    CAPABILITY = "capability"
    APPLICABILITY = "applicability"
    EVIDENCE = "evidence"
    PARAMETER = "parameter"
    SAFETY = "safety"
    PRIVILEGE = "privilege"


class CandidatePlanOutcome(StrEnum):
    """Terminal outcome of one candidate-generation run."""

    CANDIDATES_GENERATED = "candidates_generated"
    NO_OPPORTUNITY = "no_opportunity"
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"
    NO_VIABLE_CANDIDATES = "no_viable_candidates"


# --------------------------------------------------------------------------- #
# Phase 7 — experiment execution & quality validation                         #
# --------------------------------------------------------------------------- #
class ExperimentStage(StrEnum):
    """Observable experiment-lifecycle transitions (audit trail)."""

    REQUESTED = "experiment_requested"
    PRECONDITIONS_REVALIDATED = "preconditions_revalidated"
    BASELINE_CAPTURED = "baseline_captured"
    CANDIDATE_APPLIED = "candidate_applied"
    MEASUREMENT_STARTED = "measurement_started"
    MEASUREMENT_COMPLETED = "measurement_completed"
    QUALITY_VALIDATED = "quality_validation_completed"
    COMPARISON_COMPLETED = "comparison_completed"
    DECISION_MADE = "decision_made"
    RESTORATION_STARTED = "restoration_started"
    RESTORATION_COMPLETED = "restoration_completed"
    FAILED = "experiment_failed"


class ExperimentDecisionKind(StrEnum):
    """Terminal classification of an experiment (never forced into pass/fail)."""

    IMPROVED = "improved"
    NO_MEANINGFUL_IMPROVEMENT = "no_meaningful_improvement"
    REGRESSION = "regression"
    QUALITY_REGRESSION = "quality_regression"
    INVALID = "experiment_invalid"
    PRECONDITION_FAILURE = "precondition_failure"
    APPLICATION_FAILURE = "application_failure"
    MEASUREMENT_FAILURE = "measurement_failure"
    RESTORATION_FAILURE = "restoration_failure"
    UNSAFE = "unsafe_to_continue"
    REJECTED = "candidate_rejected"


class QualityStatus(StrEnum):
    """Outcome of output quality/correctness validation."""

    OK = "ok"
    ACCEPTABLE_VARIATION = "acceptable_variation"
    QUALITY_REGRESSION = "quality_regression"
    EXECUTION_FAILURE = "execution_failure"
    STRUCTURAL_FAILURE = "structural_failure"
    UNKNOWN = "unknown"


class RestorationStatus(StrEnum):
    """Whether the protected baseline configuration was restored."""

    NOT_REQUIRED = "not_required"
    PENDING = "pending"
    RESTORED = "restored"
    FAILED = "failed"


# --------------------------------------------------------------------------- #
# Phase 8 — persistent knowledge & rollback                                    #
# --------------------------------------------------------------------------- #
class OptimizationOutcome(StrEnum):
    """Contextual outcome of a persisted optimization event (never a Boolean)."""

    IMPROVED = "improved"
    NO_MEANINGFUL_IMPROVEMENT = "no_meaningful_improvement"
    REGRESSION = "regression"
    QUALITY_REGRESSION = "quality_regression"
    INVALID = "invalid"
    FAILED = "failed"
    REVERTED = "reverted"
    BLOCKED = "blocked"
    #: Measured better, but not worth keeping under the chosen modes (it failed the
    #: smallest-worthwhile-gain or payback check). Remembered with its numbers and
    #: never counted as a bad result.
    NOT_WORTH_IT = "not_worth_it"


class ApplicabilityClass(StrEnum):
    """Explainable classification of whether historical evidence applies now."""

    DIRECTLY_APPLICABLE = "directly_applicable"
    CONDITIONALLY_APPLICABLE = "conditionally_applicable"
    REQUIRES_REVALIDATION = "requires_revalidation"
    NOT_APPLICABLE = "not_applicable"
    INSUFFICIENT_CONTEXT = "insufficient_context"


class DimensionStatus(StrEnum):
    """Per-dimension comparison of a historical context against the current one."""

    MATCH = "match"
    DIFFER = "differ"
    UNKNOWN = "unknown"
    CONFLICT = "conflict"


class RevalidationTrigger(StrEnum):
    """Explicit reason historical evidence must be re-validated before reuse."""

    HARDWARE_CHANGE = "hardware_change"
    BACKEND_CHANGE = "backend_change"
    MODEL_CHANGE = "model_change"
    MODEL_VERSION_CHANGE = "model_version_change"
    QUANTIZATION_CHANGE = "quantization_change"
    WORKLOAD_CHANGE = "workload_change"
    RUNTIME_CHANGE = "runtime_change"
    SYSTEM_CONDITIONS_CHANGE = "system_conditions_change"
    DIAGNOSIS_CHANGE = "diagnosis_change"
    STALE = "stale"
    ACTION_UNREGISTERED = "action_unregistered"
    NONE = "none"


class KnowledgeWriteStatus(StrEnum):
    """Outcome of a persistence write (distinguishes persisted/duplicate/failure)."""

    PERSISTED = "persisted"
    DUPLICATE = "duplicate"
    CONFLICT = "conflict"
    FAILED = "failed"
    UNAVAILABLE = "unavailable"


class KnowledgeEventType(StrEnum):
    """Append-only knowledge lifecycle events."""

    RECORDED = "recorded"
    REVALIDATION_MARKED = "revalidation_marked"
    ROLLBACK_LINKED = "rollback_linked"
    REVERTED = "reverted"
    CORRECTION = "correction"
    # Phase 8R: real rollback execution lifecycle.
    ROLLBACK_REQUESTED = "rollback_requested"
    ROLLBACK_CHECKPOINT = "rollback_checkpoint"
    ROLLBACK_REJECTED = "rollback_rejected"
    ROLLBACK_EXECUTED = "rollback_executed"
    ROLLBACK_FAILED = "rollback_failed"


class KnowledgeHealthStatus(StrEnum):
    """Health of the persistent knowledge store."""

    OK = "ok"
    DEGRADED = "degraded"
    UNAVAILABLE = "unavailable"
    CORRUPT = "corrupt"


# --------------------------------------------------------------------------- #
# Phase 8R — real rollback execution                                            #
# --------------------------------------------------------------------------- #
class RollbackApplicabilityClass(StrEnum):
    """Whether a persisted rollback record may be executed against a target now."""

    APPLICABLE = "applicable"
    ALREADY_RESTORED = "already_restored"
    INCOMPATIBLE_MODEL = "incompatible_model"
    INCOMPATIBLE_BACKEND = "incompatible_backend"
    INCOMPATIBLE_TARGET = "incompatible_target"
    STALE = "stale"
    INTEGRITY_FAILURE = "integrity_failure"
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"


class RollbackExecutionStatus(StrEnum):
    """Terminal outcome of one real rollback attempt (never a bare boolean)."""

    APPLIED_VERIFIED = "applied_verified"
    ALREADY_RESTORED = "already_restored"
    REJECTED_INTEGRITY = "rejected_integrity"
    REJECTED_INAPPLICABLE = "rejected_inapplicable"
    FAILED_RESTORED = "failed_restored"
    FAILED_UNRECOVERED = "failed_unrecovered"


# --------------------------------------------------------------------------- #
# Phase 9 — pre-deployment autonomous optimization loop                        #
# --------------------------------------------------------------------------- #
class LoopState(StrEnum):
    """Explicit, auditable transitions of the pre-deployment optimization loop."""

    INITIALIZED = "initialized"
    OBSERVING = "observing"
    DIAGNOSING = "diagnosing"
    DEEP_DIAGNOSING = "deep_diagnosing"
    GENERATING = "generating"
    KNOWLEDGE_QUERY = "knowledge_query"
    SELECTING = "selecting"
    CHECKPOINTING = "checkpointing"
    EXPERIMENTING = "experimenting"
    DECIDING = "deciding"
    RESTORING = "restoring"
    PERSISTING = "persisting"
    RE_OBSERVING = "re_observing"
    TERMINATED = "terminated"


class LoopTerminationReason(StrEnum):
    """Why the autonomous loop stopped. A clean no-op is a success."""

    NO_MEANINGFUL_OPPORTUNITY = "no_meaningful_opportunity"
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"
    NO_ELIGIBLE_CANDIDATES = "no_eligible_candidates"
    ALL_CANDIDATES_REJECTED = "all_candidates_rejected"
    OPTIMIZATION_BUDGET_EXHAUSTED = "optimization_budget_exhausted"
    EXPERIMENT_BUDGET_EXHAUSTED = "experiment_budget_exhausted"
    TIME_BUDGET_EXHAUSTED = "time_budget_exhausted"
    OVERHEAD_BUDGET_EXHAUSTED = "overhead_budget_exhausted"
    DEEP_DIAGNOSIS_BUDGET_EXHAUSTED = "deep_diagnosis_budget_exhausted"
    QUALITY_SAFETY_STOP = "quality_safety_stop"
    RESTORATION_FAILURE = "restoration_failure"
    REASONING_UNAVAILABLE = "reasoning_unavailable"
    EXECUTION_FAILURE = "execution_failure"
    KNOWLEDGE_UNAVAILABLE = "knowledge_unavailable"
    OPERATOR_REQUIRED = "operator_required"
    COMPLETED = "completed"


class LoopIterationOutcome(StrEnum):
    """Terminal classification of one optimization iteration."""

    CANDIDATE_KEPT = "candidate_kept"
    CANDIDATE_REVERTED = "candidate_reverted"
    CANDIDATE_REJECTED = "candidate_rejected"
    NO_CANDIDATE = "no_candidate"
    EXECUTION_ERROR = "execution_error"
    RESTORATION_FAILURE = "restoration_failure"
    SAFETY_STOP = "safety_stop"


class LoopDecisionKind(StrEnum):
    """What the orchestrator decides to do next in an iteration."""

    PROCEED = "proceed"
    REJECT = "reject"
    TERMINATE = "terminate"


class KnowledgeSelectionEffect(StrEnum):
    """Explainable influence of historical evidence on candidate handling."""

    PREFERRED = "preferred"
    NEUTRAL = "neutral"
    REVALIDATION_REQUIRED = "requires_revalidation"
    DEPRIORITIZED = "deprioritized"
    REJECTED = "rejected"
    UNAVAILABLE = "unavailable"


class KnowledgeAvailability(StrEnum):
    """Whether the durable knowledge store could be consulted."""

    OK = "ok"
    UNAVAILABLE = "unavailable"


class CheckpointStatus(StrEnum):
    """Lifecycle of the protected pre-experiment checkpoint."""

    CAPTURED = "captured"
    RESTORED = "restored"
    FAILED = "failed"
    NOT_REQUIRED = "not_required"


# --------------------------------------------------------------------------- #
# Phase 10 — runtime adaptive monitoring (conservative mode)                    #
# --------------------------------------------------------------------------- #
class RuntimeState(StrEnum):
    """Explicit, auditable states of the active-runtime monitor."""

    INITIALIZING = "initializing"
    MONITORING = "monitoring"
    OPPORTUNITY_SUSPECTED = "opportunity_suspected"
    DIAGNOSING = "diagnosing"
    DEEP_ANALYSIS_RECOMMENDED = "deep_analysis_recommended"
    AWAITING_USER_APPROVAL = "awaiting_user_approval"
    CHECKPOINTING = "checkpointing"
    PAUSING = "pausing"
    INTERVENING = "intervening"
    VALIDATING = "validating"
    RESUMING = "resuming"
    # Explicit GPU-search resume lifecycle: the search is a long, target-paused
    # operation, so resume readiness is verified as its own bounded phase rather than
    # being conflated with the search duration.
    OPTIMIZATION_SEARCH_ACTIVE = "optimization_search_active"
    RESUME_REQUESTED = "resume_requested"
    RESUME_VERIFYING = "resume_verifying"
    COOLDOWN = "cooldown"
    # B2: bounded resident-target loss/recovery lifecycle states.
    TARGET_LOST = "target_lost"
    TARGET_RECOVERED = "target_recovered"
    TARGET_UNRECOVERABLE = "target_unrecoverable"
    TERMINAL_SAFE = "terminal_safe"
    ERROR_SAFE = "error_safe"


class WorkloadState(StrEnum):
    """Lifecycle of the controlled active workload."""

    RUNNING = "running"
    DRAINING = "draining"
    PAUSED = "paused"
    STOPPED = "stopped"
    TERMINATED_EXTERNALLY = "terminated_externally"
    UNKNOWN = "unknown"


class AnomalyClass(StrEnum):
    """Temporal qualification of an observed deviation from baseline."""

    NONE = "none"
    TRANSIENT = "transient"
    PERSISTENT = "persistent"
    RECOVERED = "recovered"
    REPEATED = "repeated"


class InterventionClass(StrEnum):
    """How disruptive an intervention is, and whether it may run automatically."""

    NONE = "none"
    NON_DISRUPTIVE_MONITORING = "non_disruptive_monitoring"
    NON_DISRUPTIVE_ADAPTATION = "non_disruptive_adaptation"
    DISRUPTIVE_ADAPTATION = "disruptive_adaptation"
    EXTERNAL_SYSTEM_WIDE = "external_system_wide"
    BLOCKED = "blocked"


class ApprovalOutcome(StrEnum):
    """Outcome of an approval request (never silently assumed)."""

    NOT_REQUIRED = "not_required"
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    TIMEOUT = "timeout"
    STALE = "stale"


class RuntimeTerminationReason(StrEnum):
    """Why the runtime monitor stopped (explicit; never a hidden exception)."""

    DURATION_REACHED = "duration_reached"
    MONITORING_BUDGET_EXHAUSTED = "monitoring_budget_exhausted"
    INTERVENTION_LIMIT_REACHED = "intervention_limit_reached"
    TARGET_EXITED = "target_exited"
    EXTERNAL_TERMINATION = "external_termination"
    OPERATOR_REQUIRED = "operator_required"
    SAFETY_TERMINAL = "safety_terminal"
    ERROR = "error"


class MonitoringMode(StrEnum):
    """Adaptive monitoring *intensity* (a dimension separate from the lifecycle state).

    The monitor's lifetime is tied to the target runtime, not to this intensity. Mode
    controls how often expensive observations are taken; cheap observations (target
    liveness/identity/RSS/CPU, workload metrics, memory/CPU/power) always run.
    """

    ACTIVE = "active"
    NORMAL = "normal"
    LOW_COST = "low_cost"
    DORMANT = "dormant"


# --------------------------------------------------------------------------- #
# Phase 11 — external process recommendations (staged, minimal)                 #
# --------------------------------------------------------------------------- #
class ExternalResource(StrEnum):
    """A system resource an external process may contend for."""

    MEMORY = "memory"
    CPU = "cpu"
    STORAGE_IO = "storage_io"
    COMMIT = "commit"
    PAGE_FAULTS = "page_faults"
    SYSTEM = "system"


class ExternalScope(StrEnum):
    """Blast radius of an external observation/recommendation."""

    TARGET_PROCESS = "target_process"
    EXTERNAL_PROCESS = "external_process"
    USER_SESSION = "user_session"
    MACHINE_SYSTEM = "machine_system"


class AttributionEvidenceCategory(StrEnum):
    """Explainable evidence category for external resource attribution."""

    DIRECT_OBSERVATION = "direct_observation"
    TEMPORAL_ALIGNMENT = "temporal_alignment"
    RESOURCE_PRESSURE = "resource_pressure"
    TARGET_DEGRADATION = "target_degradation"
    CONTROLLED_COMPARISON = "controlled_comparison"
    HISTORICAL_KNOWLEDGE = "historical_knowledge"
    CORRELATION_ONLY = "correlation_only"
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"


class ExternalRecommendationClass(StrEnum):
    """How far a recommendation may go (never collapsed with execution)."""

    INFORMATIONAL = "informational"
    USER_ACTION = "user_action"
    APPROVAL_GATED_ACTION = "approval_gated_action"
    UNSUPPORTED_ACTION = "unsupported_action"


class ExternalRecommendationStatus(StrEnum):
    """Lifecycle of an external recommendation (a decision is not an execution)."""

    GENERATED = "generated"
    PRESENTED = "presented"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    DISMISSED = "dismissed"
    EXPIRED = "expired"
    STALE = "stale"
    NO_RECOMMENDATION = "no_recommendation"


class ExternalActionSafetyClass(StrEnum):
    """Safety classification of a registered external action."""

    RECOMMENDATION_ONLY = "recommendation_only"
    SAFE_REVERSIBLE = "safe_reversible"
    REVERSIBLE_WITH_RISK = "reversible_with_risk"
    UNSUPPORTED = "unsupported"


class ExternalProcessAccess(StrEnum):
    """How much of a process's observable state is accessible (honest)."""

    READABLE = "readable"
    PARTIAL = "partial"
    DENIED = "denied"


class PowerState(StrEnum):
    """Observed external power source (B1 measurement-validity signal).

    ``UNKNOWN`` means the platform API was unavailable or returned an indeterminate
    value; it is never treated as ``AC``.
    """

    AC = "ac"
    BATTERY = "battery"
    UNKNOWN = "unknown"


class MeasurementValidity(StrEnum):
    """Whether a measurement can be trusted for optimization (B1).

    ``DEGRADED`` means a materially confounded power/performance state was observed;
    ``UNKNOWN`` means the required telemetry was unavailable (never silently healthy).
    """

    VALID = "valid"
    DEGRADED = "degraded"
    UNKNOWN = "unknown"


class ExternalRunTerminationReason(StrEnum):
    """Explicit terminal reason for an external recommendation run."""

    DURATION_REACHED = "duration_reached"
    NO_RECOMMENDATION = "no_recommendation"
    NO_MEANINGFUL_BOTTLENECK = "no_meaningful_bottleneck"
    APPROVAL_DECLINED = "approval_declined"
    RECOMMENDATION_ACCEPTED = "recommendation_accepted"
    ACTION_COMPLETED = "action_completed"
    ACTION_UNSUPPORTED = "action_unsupported"
    STALE_PROCESS = "stale_process"
    STALE_PROVENANCE = "stale_provenance"
    VERIFICATION_FAILURE = "verification_failure"
    RECOMMENDATION_LIMIT_REACHED = "recommendation_limit_reached"
    SAFETY_TERMINAL = "safety_terminal"
    OPERATOR_REQUIRED = "operator_required"
    ERROR = "error"


class CandidateEvaluationStatus(StrEnum):
    """Validity/safety classification of one empirically evaluated candidate point.

    ``OK``       - the candidate was applied, measured with enough valid samples, and
                   did not breach any resource envelope.
    ``OOM``      - the runtime reported an out-of-memory / allocation failure.
    ``VRAM_EXCEEDED`` - measured VRAM exceeded the pre-computed safe envelope.
    ``PAGING``   - the candidate introduced paging/thrashing beyond tolerance.
    ``INVALID``  - insufficient valid measurements (variance/errors) to judge.
    ``TIMEOUT``  - the candidate measurement exceeded its time budget.
    """

    OK = "ok"
    OOM = "oom"
    VRAM_EXCEEDED = "vram_exceeded"
    PAGING = "paging"
    INVALID = "measurement_invalid"
    TIMEOUT = "timeout"


class SearchSelectionKind(StrEnum):
    """Terminal outcome of a multi-candidate optimization search.

    ``SELECT``    - one candidate was demonstrably safe and worthwhile; exactly one
                    value is recommended.
    ``NO_CHANGE`` - no candidate provided sufficient, evidence-backed improvement, or
                    the safe feasible range contained no higher configuration. This is
                    a valid, successful outcome.
    """

    SELECT = "select"
    NO_CHANGE = "no_change"


# --------------------------------------------------------------------------- #
# Optimization preference / adaptive economics (user-controlled policy)         #
# --------------------------------------------------------------------------- #
class OptimizationMode(StrEnum):
    """How aggressively InferenceOS spends time searching for improvements.

    The mode only changes *economics* (how much improvement is worth a given search
    cost) and the *search budget*. It never overrides a hard safety gate
    (OOM/VRAM/paging/quality/health/rollback/restore).
    """

    BALANCED = "balanced"
    PERFORMANCE_FIRST = "performance_first"
    MINIMIZE_OPTIMIZATION_COST = "minimize_optimization_cost"
    CUSTOM = "custom"


class GoalMode(StrEnum):
    """What counts as *better* (the effort mode only sets cost and time).

    ``computer_stays_usable``, ``quiet_and_cool`` and ``save_battery`` are added in
    step 6, together with the readings they need.
    """

    BALANCED = "balanced"
    FASTEST_ANSWERS = "fastest_answers"
    CUSTOM = "custom"


class Situation(StrEnum):
    """When a change is judged: before the model loads, or while it runs."""

    BEFORE_LOADING = "before_loading"
    WHILE_RUNNING = "while_running"


class PerformanceState(StrEnum):
    """Observed target-performance state relative to its measured baseline.

    Derived from existing baseline/workload metrics; ``UNKNOWN`` means there is not
    enough baseline evidence to classify, so the selected user policy is used without
    guessing.
    """

    NORMAL = "normal"
    DEGRADED = "degraded"
    SEVERELY_DEGRADED = "severely_degraded"
    UNKNOWN = "unknown"


class DegradedPerformancePolicy(StrEnum):
    """Whether degraded performance lowers the required improvement (adaptive urgency)."""

    LOWER_REQUIREMENT = "lower_requirement"
    STRICT = "strict"


class ResumeVerificationOutcome(StrEnum):
    """Outcome of a bounded post-search/post-intervention resume verification."""

    VERIFIED = "verified"
    RETRYABLE = "retryable"
    TERMINAL = "terminal"
    NOT_REQUIRED = "not_required"
